#ifndef CBS_INTEGERS_H
#define CBS_INTEGERS_H

#include <confd_lib.h>

int register_all_callbacks(struct confd_daemon_ctx *dctx);

#endif