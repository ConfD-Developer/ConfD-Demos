/*********************************************************************
 * Introduction example for pushing data to the CDB oper datastore.  *
 * Java version.                                                     *
 *                                                                   *
 * (C) 2018 Tail-f Systems                                           *
 * Permission to use this code as a starting point hereby granted    *
 *                                                                   *
 * See the README file for more information                          *
 *********************************************************************/

import com.tailf.conf.*;
import com.tailf.maapi.Maapi;
import com.tailf.maapi.MaapiUserSessionFlag;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class ArpStat {
    private static final Logger log = LogManager.getLogger(ArpStat.class);

    private final static String CONFD_ADDR = "127.0.0.1";
    private final static int INTERVAL = 5 * 1000;
    private final static int MAX_NOBJS = 100;

    static private List<ConfXMLParam> processArpLine(String line)
            throws ConfException {
        log.debug("==> processArpLine line=" + line);

        List<ConfXMLParam> ret = new ArrayList<ConfXMLParam>();
        String[] toks = line.split(" ");
        log.debug("toks.length=" + toks.length);
        if (toks.length >= 4) {
            String ss = toks[1];
            String ip = ss.substring(1).substring(0, ss.length() - 2);
            String hwaddr = toks[3];
            if (hwaddr.compareTo("<incomplete>") != 0) {
                String ifname = toks[toks.length - 1];
                boolean permanent = false;
                boolean published = false;
                for (int i = 4; i < toks.length; i++) {
                    if (toks[i].compareTo("PERM") == 0)
                        permanent = true;
                    if (toks[i].compareTo("PUB") == 0)
                        published = true;
                }
                ret.add(new ConfXMLParamStart(arpe.hash, arpe.arpe_arpe));
                ret.add(new ConfXMLParamValue(arpe.hash, arpe.arpe_ip,
                        new ConfIPv4(ip)));
                ret.add(new ConfXMLParamValue(arpe.hash, arpe.arpe_ifname,
                        new ConfBuf(ifname)));
                ret.add(new ConfXMLParamValue(arpe.hash, arpe.arpe_hwaddr,
                        new ConfBuf(hwaddr)));
                ret.add(new ConfXMLParamValue(arpe.hash, arpe.arpe_permanent,
                        new ConfBool(permanent)));
                ret.add(new ConfXMLParamValue(arpe.hash, arpe.arpe_published,
                        new ConfBool(published)));
                ret.add(new ConfXMLParamStop(arpe.hash, arpe.arpe_arpe));
            }
        }

        log.debug("<== processArpLine ret.size()=" + ret.size());
        return ret;
    }

    static private void updateArpDataInCdb(Maapi maapi, int tid,
                                           int maxNobjs) throws IOException,
            ConfException {
        log.debug("==> updateArpDataInCdb tid=" + tid + " maxNobjs="
                + maxNobjs);

        String s;
        Process p = Runtime.getRuntime().exec("arp -an");

        maapi.setNamespace(tid, arpe.hash);
        maapi.delete(tid, "/arpentries/arpe");

        BufferedReader stdInput =
                new BufferedReader(new InputStreamReader(p.getInputStream()));

        List<ConfXMLParam> vals = new ArrayList<ConfXMLParam>();
        while ((s = stdInput.readLine()) != null) {
            vals.addAll(processArpLine(s));
            log.debug("vals.size()=" + vals.size());
            if (vals.size() == maxNobjs + 2) {
                log.debug("got " + vals.size() + " objects, writing chunk to "
                        + "CDB");
                maapi.setValues(tid, vals, "/arpentries");
                vals = new ArrayList<ConfXMLParam>();
            }
        }
        if (vals.size() != 0) {
            log.debug("writing objects (size= " + vals.size() + ") to CDB");
            maapi.setValues(tid, vals, "/arpentries");
        }

        log.debug("<== updateArpDataInCdb");
    }

    static private void runArp(int maxNobjs, Maapi maapi) throws IOException,
            ConfException {
        log.debug("==> runArp maxNobjs=" + maxNobjs);

        int tid = maapi.startTrans(Conf.DB_OPERATIONAL, Conf.MODE_READ_WRITE);
        updateArpDataInCdb(maapi, tid, maxNobjs);
        maapi.applyTrans(tid, false);
        maapi.finishTrans(tid);

        log.debug("<== runArp");
    }

    static public void main(String args[]) throws Exception {
        int interval = ArpStat.INTERVAL;
        int maxNobjs = ArpStat.MAX_NOBJS;
        log.info("==> main args.length=" + args.length);

        String user = "admin";
        String context = "system";
        String[] groups = {user};

        boolean wasHelp = false;
        ArrayList argList = new ArrayList<String>(Arrays.asList(args));
        Iterator<String> it = argList.iterator();
        while(it.hasNext()) {
            String arg = it.next();
            if (arg.equals("-h") || arg.equals("-?")) {
                wasHelp = true;
                System.out.println("-h|-? help");
                System.out.println("-i <interval> in ms");
                System.out.println("-m <maxnobjs>");
                break;
            }
            if (arg.equals("-i")) {
                if (it.hasNext()) {
                    interval = Integer.parseInt(it.next());
                }
                continue;
            }
            if (arg.equals("-m")) {
                if (it.hasNext()) {
                    maxNobjs = Integer.parseInt(it.next());
                }
                continue;
            }
        }

        if (!wasHelp) {
            log.info("Using interval=" + interval + " maxNobjs=" + maxNobjs);

           /*
            Create maapi instance and user session  to be used for writing
            to CDB.
            */
            Maapi maapi = new Maapi(new Socket(CONFD_ADDR, Conf.PORT));
            maapi.startUserSession(user, InetAddress.getByName(CONFD_ADDR),
                    context, groups, MaapiUserSessionFlag.PROTO_TCP);

            try {
                while (true) {
                    runArp(maxNobjs, maapi);
                    Thread.sleep(interval);
                }
            } catch (Exception e) {
                System.out.println("ArpStat terminated");
            }
        }

        log.info("<== main");
    }

}
