/*********************************************************************
 * ConfD CDB subscriber getModifications example
 *
 * (C) 2018 Tail-f Systems
 * Permission to use this code as a starting point hereby granted
 *
 * See the README file for more information
 ********************************************************************/

import java.io.IOException;
import java.net.Socket;
import java.util.EnumSet;

import com.tailf.cdb.Cdb;
import com.tailf.cdb.CdbGetModificationFlag;
import com.tailf.cdb.CdbSubscription;
import com.tailf.cdb.CdbSubscriptionSyncType;
import com.tailf.cdb.CdbSubscriptionType;
import com.tailf.conf.Conf;
import com.tailf.conf.ConfException;
import com.tailf.conf.ConfNoExists;
import com.tailf.conf.ConfObject;
import com.tailf.conf.ConfXMLParam;
import com.tailf.conf.ConfXMLParamLeaf;
import com.tailf.conf.ConfXMLParamStart;
import com.tailf.conf.ConfXMLParamStartDel;
import com.tailf.conf.ConfXMLParamStop;
import com.tailf.conf.ConfXMLParamValue;
import java.util.List;

public class ModifSubscriber {

    private static final String DAEMON_NAME = "subscriber-modifications";
    private static final String ROOT_PATH = "/folder-user";

    private static final String CONFD_ADDR = "127.0.0.1";
    private static final int CONFD_PORT = Conf.PORT;

    public static void main(String arg[]) {

        Socket subsSocket = null;
        try {
            subsSocket = new Socket(CONFD_ADDR, CONFD_PORT);
        } catch (IOException e) {
            System.err.println("Could not open subscription socket to ConfD!");
            e.printStackTrace();
            System.exit(1);
        }

        Cdb cdb = null;
        CdbSubscription cdbSubscriber = null;
        int subPoint = -1;
        try {
            cdb = new Cdb(DAEMON_NAME, subsSocket);
            cdbSubscriber = cdb.newSubscription();
            subPoint =
                cdbSubscriber.subscribe(CdbSubscriptionType.SUB_RUNNING, 3,
                                        userFolders.hash, ROOT_PATH);
            cdbSubscriber.subscribeDone();
        } catch (ConfException | IOException e) {
            System.err.println("Could not connect to cdb!\n" + e);
            System.exit(1);
        }

        System.out.println("CDB subscriber initialized!");
        try {
            while (true) {
                try {
                    int[] triggeredSubs = cdbSubscriber.read();

                    if (triggeredSubs[0] != subPoint) {
                        continue;
                    }
                    // get list of all the changes done in triggering commit
                    EnumSet<CdbGetModificationFlag> flags = EnumSet.of(
                            CdbGetModificationFlag.CDB_GET_MODS_INCLUDE_LISTS);
                    List<ConfXMLParam> changes = cdbSubscriber.getModifications(
                            subPoint, flags, null);
                    // pass the changes to a custom "writer" to create
                    // a NETCONF-like content for edit-config message
                    String output = ModificationWriter.writeValues(changes);
                    System.out.println("modifications read by subscriber:\n"
                            + output);

                } finally {
                    cdbSubscriber.sync(CdbSubscriptionSyncType.DONE_PRIORITY);
                }
            }
        } catch (ConfException | IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}

class ModificationWriter {

    private static final String INDENT_STR = "";
    private static final int INDENT_SIZE = 4;

    private static class IndentedValue {
        public String value;
        public int indent;
        public IndentedValue(String value, int indent) {
            this.value = value;
            this.indent = indent;
        }
    }

    private static IndentedValue processValue(ConfXMLParam param, int indent) {
        String tagStr = param.getTag();

        String outStr = "";
        int outIndent = indent;
        int prefixLen = indent;

        // start a container/list entry creation/modification
        if (param instanceof ConfXMLParamStart) {
            outStr = String.format("<%s>", tagStr);
            outIndent += INDENT_SIZE;
        }
        // exit from a processing of container/list entry creation/modification
        else if (param instanceof ConfXMLParamStop) {
            outStr = String.format("</%s>", tagStr);
            outIndent -= INDENT_SIZE;
            prefixLen = outIndent;
        }
        // deletion of a list entry / container
        else if (param instanceof ConfXMLParamStartDel) {
            outStr = String.format("<%s operation=\"delete\">", tagStr);
            outIndent += INDENT_SIZE;
        }
        // type empty leaf creation
        else if (param instanceof ConfXMLParamLeaf) {
            outStr = String.format("<%s/>", tagStr);
        }
        else if (param instanceof ConfXMLParamValue) {
            // deletion of leaf
            ConfObject val = param.getValue();
            if (val instanceof ConfNoExists) {
                outStr = String.format("<%s operation=\"delete\">", tagStr);
            }
            // regular leaf creation/modification
            else {
                outStr = String.format("<%s>%s</%s>", tagStr, val, tagStr);
            }
        }

        String prefix = "";
        if (prefixLen > 0) {
            prefix = String.format("%" + prefixLen + "s", INDENT_STR);
        }
        String suffix = String.format("%n");

        return new IndentedValue(prefix + outStr + suffix, outIndent);
    }

    // Allocate a string containing printout of the tagged value array.
    // Output follows a NETCONF edit-config message format without any headers.
    public static String writeValues(List<ConfXMLParam> values) {
        StringBuilder builder = new StringBuilder();
        int indent = 0;
        for (ConfXMLParam param: values) {
            IndentedValue out = processValue(param, indent);
            builder.append(out.value);
            indent = out.indent;
        }
        return builder.toString();
    }
}
