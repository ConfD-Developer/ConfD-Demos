/*    -*- Java -*-
 *
 *  Copyright 2019 Tail-F Systems AB. All rights reserved.
 *
 *  Permission to use this code as a starting point hereby granted.
 */

import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.*;
import java.util.regex.Pattern;

import com.tailf.conf.*;
import com.tailf.dp.*;

import com.tailf.dp.annotations.*;
import com.tailf.dp.proto.*;
import com.tailf.maapi.Maapi;
import com.tailf.maapi.MaapiCursor;

import org.apache.log4j.Logger;

public class Demo {
    private static Logger Log = Logger.getLogger(Demo.class);

    static public void main(String args[]) throws Exception {
        /* create maapi instance to be used by the  validate callbacks
           so they could use the maapi instance for attaching to
           started transaction by confd
         */
        Maapi maapi = new Maapi(new Socket("localhost", Conf.PORT));

        // create new control socket
        Socket ctrlSocket = new Socket("127.0.0.1", Conf.PORT);

        // init and connect control socket
        Dp dp = new Dp("arpstats", ctrlSocket);

        // register the stats callbacks
        StatsCb callbacks = new StatsCb();
        dp.registerAnnotatedCallbacks(callbacks);
        dp.registerAnnotatedCallbacks(new StatsTrans(callbacks));

        dp.registerDone();
        Log.info("Demo Started");
        // read input from the control socket
        try {
            while (true) dp.read();
        } catch (Exception e) {
            System.out.println("ConfD terminated");
        }

    }

    private static abstract class ArpFilter {
        boolean exact;

        public ArpFilter(boolean exact) {
            this.exact = exact;
        }

        public ArpFilter() {
            this(true);
        }

        public String command() {
            return "arp -an";
        }

        public boolean entryEligible(ArpEntry entry) {
            return true;
        }
    }

    private static class ArpFilterNone extends ArpFilter {
        public ArpFilterNone() {
            super(false);
        }
    }

    private static class ArpFilterIf extends ArpFilter {
        String ifname;

        public ArpFilterIf(String ifname) {
            this.ifname = ifname;
        }

        @Override
        public String command() {
            return "arp -an -i " + ifname;
        }
    }

    private static class ArpFilterHostname extends ArpFilter {
        String hostname;

        public ArpFilterHostname(String hostname) {
            this.hostname = hostname;
        }

        @Override
        public String command () {
            return "arp -an " + hostname;
        }
    }

    private static class ArpFilterField extends ArpFilter {
        String field;
        ConfValue value;

        public ArpFilterField(String field, ConfValue value) {
            this.field = field;
            this.value = value;
        }

        @Override
        public boolean entryEligible(ArpEntry entry) {
            return value.equals(entry.getFieldValue(field));
        }
    }

    public static class StatsCb {

        private Map<Integer, ArpEntry> entryMap = new TreeMap<>();

        public void removeTrans(DpTrans trans) {
            entryMap.remove(trans.getTransaction());
        }

        private ArpFilter buildFilter(DpListFilter filter) {
            ArpFilter arpFilter;

            if (filter == null) {
                return new ArpFilterNone();
            }
            if (filter.type.equals(ListFilterType.CONFD_LF_AND)) {
                // for simplicity, only one branch of the AND
                // expression is used; this means filtering is
                // incomplete
                arpFilter = buildFilter(filter.expr1);
                if (arpFilter instanceof ArpFilterNone) {
                    arpFilter = buildFilter(filter.expr2);
                }
                arpFilter.exact = false;
                return arpFilter;
            } else if (filter.type.equals(ListFilterType.CONFD_LF_CMP)
                       && filter.op.equals(ListFilterExprOp.CONFD_CMP_EQ)) {
                ConfObject value = filter.val;
                assert filter.node[0] instanceof ConfTag;
                switch (((ConfTag)filter.node[0]).getTagHash()) {
                case arpe.arpe_ifname:
                    return new ArpFilterIf(value.toString());
                case arpe.arpe_ip:
                    return new ArpFilterHostname(value.toString());
                case arpe.arpe_hwaddr:
                    return new ArpFilterField("hwaddr", (ConfBuf) value);
                }
            }
            return new ArpFilterNone();
        }

        private boolean populateEntries(DpTrans trans, List<ArpEntry> entries,
                                        DpListFilter filter) {
            try {
                Log.info("filtering with " + filter);
                ArpFilter arpFilter = buildFilter(filter);
                Log.info("using command " + arpFilter.command());
                String s;
                Process p = Runtime.getRuntime().exec(arpFilter.command());

                BufferedReader stdInput = new BufferedReader(
                        new InputStreamReader(p.getInputStream()));

                BufferedReader stdError = new BufferedReader(
                        new InputStreamReader(p.getErrorStream()));

                // read the output from the command

                while ((s = stdInput.readLine()) != null) {
                    if (s.charAt(0) != '?') {
                        // not a ARP line
                        continue;
                    }
                    String[] toks = s.split("[ ,?()]+");
                    if (toks.length < 4)
                        continue;
                    Iterator<String> toksIter = Arrays.asList(toks).iterator();
                    toksIter.next();
                    String ip = toksIter.next();
                    toksIter.next(); // skip "at"
                    String hwaddr = toksIter.next();
                    boolean permanent = false, published = false;
                    if (hwaddr.contains("incomplete")) {
                        hwaddr = null;
                        while (toksIter.hasNext()) {
                            if ("on".equals(toksIter.next())) {
                                break;
                            }
                        }
                    } else {
                        while (toksIter.hasNext()) {
                            String elem = toksIter.next();
                            if ("on".equals(elem)) {
                                break;
                            } else if ("PERM".equals(elem)) {
                                permanent = true;
                            } else if ("PUB".equals(elem)) {
                                published = true;
                            }
                        }
                    }
                    String ifname = toksIter.next();
                    while (toksIter.hasNext()) {
                        // Some OSes have these two fields at the line end
                        String elem = toksIter.next();
                        if ("permanent".equals(elem)) {
                            permanent = true;
                        } else if ("published".equals(elem)) {
                            published = true;
                        }
                    }
                    ArpEntry e = new ArpEntry(ip, hwaddr,
                                              permanent, published,
                                              ifname);
                    if (arpFilter.entryEligible(e)) {
                        entries.add(e);
                    }
                }
                Collections.sort(entries);
                return arpFilter.exact;
            } catch (IOException e) {
                System.out.println("exception happened - here's what I know: ");
                e.printStackTrace();
                return false;
            }
        }

        /**
         * Update the "next entry" object.  It indicates what ARP
         * entry will be used in subsequent get_elem callbacks.  The
         * entry is bound to a transaction handle, so that parallel
         * transactions don't affect each other.
         */
        private ArpEntry moveNextEntry(DpTrans trans, ArpEntry e) {
            entryMap.put(trans.getTransaction(), e);
            return e;
        }

        /**
         * The same as above, but take the entry from the entry
         * iterator.
         */
        private ArpEntry moveNextEntry(DpTrans trans,
                                       Iterator<? extends Object> iterator) {
            return moveNextEntry(trans, (ArpEntry) iterator.next());
        }

        private ConfValue[] valsFromArpEntry(ArpEntry e) {
            Log.trace("==> valsFromArpEntry e=" + e);
            ConfValue[] retVal = new ConfValue[]{
                e.getIPAddress(), e.getIfName(), e.getHWAddress(),
                e.getPermanent(), e.getPublished()};
            Log.trace("<== valsFromArpEntry");
            return retVal;
        }

        private ArpEntry getArpEntryByKeypath(DpTrans trans, ConfObject[] kp) {
            Log.trace("==> getArpEntryByKeypath");
            if (Log.isTraceEnabled()) {
                Log.trace("kp=" + (new ConfPath(kp)).toString());
            }
            ArpEntry retVal = null;
            int keyIndex = 1;
            if (kp[keyIndex] instanceof ConfTag) {
                Log.trace("remapping keyIndex from 1 to 0 (path for full " +
                        "object received from getObject)");
                keyIndex = 0;
            }
            ConfObject ip = ((ConfKey) kp[keyIndex]).elementAt(0);
            ConfObject ifname = ((ConfKey) kp[keyIndex]).elementAt(1);
            Log.trace("ip=" + ip + " ifname=" + ifname);

            ArpEntry nextE = entryMap.get(trans.getTransaction());
            if (nextE != null &&
                nextE.getIPAddress().equals(ip) &&
                nextE.getIfName().equals(ifname)) {
                Log.trace("Reusing next entry");
                return nextE;
            }

            // entry not cached - this means the request came from
            // "outside" of an iteration, e.g. direct get_elem request
            List<ArpEntry> entries = new ArrayList<>();
            populateEntries(trans, entries, null);

            for (int i = 0; i < entries.size(); i++) {
                ArpEntry e = entries.get(i);
                if ((e.getIPAddress().equals(ip)) &&
                        (e.getIfName().equals(ifname))) {
                    Log.trace("Entry found!");
                    retVal = e;
                    break;
                }
            }
            if (retVal == null) {
                Log.trace("Entry not found!");
            }
            Log.trace("<== getArpEntryByKeypath retVal=" + retVal);
            return retVal;
        }

        /**
         * @see DpDataCallback
         */
        @DataCallback(callPoint = arpe.callpoint_arpe,
                callType = DataCBType.ITERATOR)
                public Iterator<? extends Object> iterator(DpTrans trans,
                                                           ConfObject[] kp,
                                                           DpListFilter filter)
                throws DpCallbackException {
            Log.debug("==> iterator");
            List<ArpEntry> entries = new ArrayList<>();
            boolean exact = populateEntries(trans, entries, filter);
            trans.honorFilter(exact);
            Log.debug("<== iterator");
            return entries.iterator();
        }

        @DataCallback(callPoint = arpe.callpoint_arpe,
                callType = DataCBType.GET_NEXT)
        public ConfKey getKey(DpTrans trans, ConfObject[] kp, Object obj)
                throws DpCallbackException {
            Log.debug("==> getKey");
            ArpEntry e = (ArpEntry) obj;
            moveNextEntry(trans, e);
            ConfObject c;
            c = e.getIPAddress();
            ConfKey retVal = new ConfKey(new ConfObject[]{c, e.getIfName()});
            Log.debug("<== getKey");
            return retVal;
        }

        @DataCallback(callPoint = arpe.callpoint_arpe, callType =
                DataCBType.GET_NEXT_OBJECT)
        public ConfValue[] getIteratorObject(DpTrans trans, ConfObject[] kp,
                                             Object obj) throws
                DpCallbackException {
            Log.debug("==> getIteratorObject");
            ArpEntry e = (ArpEntry) obj;
            moveNextEntry(trans, e);
            ConfValue[] retVal = valsFromArpEntry(e);
            Log.debug("<== getIteratorObject");
            return retVal;
        }

        @DataCallback(callPoint = arpe.callpoint_arpe, callType =
                DataCBType.GET_NEXT_OBJECT_LIST)
        public List<ConfValue[]>
        getIteratorObjectList(DpTrans trans,
                              ConfObject[] kp,
                              Object obj,
                              Iterator<? extends Object> iterator)
                throws DpCallbackException {
            Log.debug("==> getIteratorObject");

            // return MAX_ENTRIES, rest will be handled by next call
            final int MAX_ENTRIES = 10;

            NextObjectArrayList<ConfValue[]> retVal;
            retVal = new NextObjectArrayList<ConfValue[]>();
            ArpEntry e = (ArpEntry) obj;
            moveNextEntry(trans, e);
            retVal.add(valsFromArpEntry(e));
            int i = 0;
            while (iterator.hasNext() && i < MAX_ENTRIES - 1) {
                retVal.add(valsFromArpEntry(moveNextEntry(trans, iterator)));
                i++;
            }

            Log.debug("<== getIteratorObject  etVal.size()=" + retVal.size());
            return retVal;
        }

        @DataCallback(callPoint = arpe.callpoint_arpe, callType =
                DataCBType.GET_OBJECT)
        public ConfObject[] getObject(DpTrans trans, ConfObject[] kp)
                throws DpCallbackException {
            Log.debug("==> getObject");
            // (for case we request specific row right after start,
            // e.g. show arp arpe 172.28.70.151 enp0s25)
            ConfObject[] retVal = null;
            ArpEntry e = getArpEntryByKeypath(trans, kp);
            if (e != null) {
                retVal = valsFromArpEntry(e);
            }
            Log.debug("<== getObject");
            return retVal;
        }

        @DataCallback(callPoint = arpe.callpoint_arpe,
                callType = {DataCBType.GET_ELEM})
        public ConfValue getElem(DpTrans trans, ConfObject[] kp) {
            Log.debug("==> getElem");
            // entries map has to be updated
            // (for case we request specific row right after start,
            // e.g. show arp arpe 172.28.70.151 enp0s25)
            ConfValue retVal = null;
            ArpEntry e = getArpEntryByKeypath(trans, kp);
            if (e != null) {
                ConfTag leaf = (ConfTag) kp[0];
                switch (leaf.getTagHash()) {
                    case arpe.arpe_ip:
                        retVal = e.getIPAddress();
                        break;
                    case arpe.arpe_hwaddr:
                        retVal = e.getHWAddress();
                        break;
                    case arpe.arpe_permanent:
                        retVal = e.getPermanent();
                        break;
                    case arpe.arpe_published:
                        retVal = e.getPublished();
                        break;
                    default:
                        break;
                }
            }

            Log.debug("<== getElem");
            return retVal;
        }
    }


    public static class StatsTrans {
        private StatsCb callbacks;

        public StatsTrans(StatsCb callbacks) {
            this.callbacks = callbacks;
        }

        @TransCallback(callType = {TransCBType.INIT})
        public void init(DpTrans trans) {
        }

        @TransCallback(callType = {TransCBType.FINISH})
        public void finish(DpTrans trans) {
            callbacks.removeTrans(trans);
        }
    }
}
