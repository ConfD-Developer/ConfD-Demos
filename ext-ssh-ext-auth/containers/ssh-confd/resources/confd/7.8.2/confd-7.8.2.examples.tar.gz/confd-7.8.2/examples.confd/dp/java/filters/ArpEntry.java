import java.util.Map;
import java.util.TreeMap;

import com.tailf.conf.ConfBool;
import com.tailf.conf.ConfBuf;
import com.tailf.conf.ConfIPv4;
import com.tailf.conf.ConfNoExists;
import com.tailf.conf.ConfValue;
import com.tailf.conf.ConfException;
public class ArpEntry implements Comparable<ArpEntry>{

    private Map<String, ConfValue> fields = new TreeMap<>();

    public ArpEntry(String ip,String hwaddr,boolean permanent,
                    boolean published,String ifname) {
        try{
            ConfValue hwval = hwaddr == null
                ? new ConfNoExists()
                : new ConfBuf(hwaddr);
            fields.put("ip", new ConfIPv4(ip));
            fields.put("ifname", new ConfBuf(ifname));
            fields.put("hwaddr", hwval);
            fields.put("permanent", new ConfBool(permanent));
            fields.put("published", new ConfBool(published));
        } catch(ConfException e) {          }
    }

    public ConfIPv4 getIPAddress() {
        return (ConfIPv4) fields.get("ip");
    }

    public ConfBool getPermanent() {
        return (ConfBool) fields.get("permanent");
    }

    public ConfBool getPublished() {
        return (ConfBool) fields.get("published");
    }

    public ConfValue getHWAddress() {
        return fields.get("hwaddr");
    }

    public ConfBuf getIfName() {
        return (ConfBuf) fields.get("ifname");
    }

    public ConfValue getFieldValue(String field) {
        return fields.get(field);
    }

    public int compareTo(ArpEntry arpe) {
        int cmp = 0;

        if ((cmp = getIPAddress().compareTo(arpe.getIPAddress())) != 0) {
            return cmp;
        } else {
            return getIfName().compareTo(arpe.getIfName());
        }
    }

    public boolean equals(Object obj) {
        if (obj.getClass() != this.getClass()) {
            return false;
        }

        ArpEntry arpEntry = (ArpEntry)obj;

        return getIPAddress().equals(arpEntry.getIPAddress())
        && getIfName().equals(arpEntry.getIfName());

    }

    @Override
    public String toString() {
        return String.format("%s at %s on %s (perm=%b, pub=%b)",
                             fields.get("ip"),
                             fields.get("hwaddr"),
                             fields.get("ifname"),
                             fields.get("permanent"),
                             fields.get("published"));
    }
}
