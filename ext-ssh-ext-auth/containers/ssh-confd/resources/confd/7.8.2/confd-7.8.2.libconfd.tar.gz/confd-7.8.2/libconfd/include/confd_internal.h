#ifndef _CONFD_INTERNAL_H
#define _CONFD_INTERNAL_H 1

#include <stdarg.h>
#include <stdbool.h>

#ifndef HAVE_REGEX_H
#define HAVE_REGEX_H 0
#endif

#include "erl_interface.h"
#include "ei.h"

#ifdef linux
  #include <linux/if.h>
#endif

#if defined(__GNUC__) && __GNUC__ >= 7 || \
    defined(__clang__) && __clang_major__ >= 12
 #define FALL_THROUGH __attribute__ ((fallthrough))
#else
 #define FALL_THROUGH ((void)0)
#endif

#ifdef __GNUC__
#define PRINTF(F,A) __attribute__ ((format (printf, F, A)))
#else
#define PRINTF(F,A)
#endif

enum capi_trace_level {
    CAPI_TRACE_UNSET   = -1,
    CAPI_TRACE_SILENT  = 0,
    CAPI_TRACE_BRIEF   = 1,
    CAPI_TRACE_PROTOCOL = 2,
    CAPI_TRACE_VERBOSE = 3
};

enum capi_dir {
    capi_dir_send = 0,
    capi_dir_recv  = 1
};

enum capi_packet {
    capi_packet_raw = 0,
    capi_packet_opaque  = 1,
    capi_packet_eterm  = 2
};

extern int capi_validate_rawbuf(enum capi_dir direction,
                                enum capi_packet packet,
                                const unsigned char *rawbuf, int rawsize,
                                int cdbop, int thandle,
                                const char *file, int line, const char *fun);

extern void capi_trace(const char *file, int line, const char *fun,
                          int level, const char *fmt, ...) PRINTF(5,6);

#define CAPI_TRACE_DEFAULT "silent"

#ifdef CAPI_NO_DEBUG
#  define CAPI_VALIDATE_RAWBUF(direction, format, rawbuf, rawsize,      \
                               cdbop, thandle)                          \
    CONFD_OK

#  define CAPI_TRACE(level, fmt, ...)        \
    do { } while (0)
#else
#  define CAPI_VALIDATE_RAWBUF(direction, format, rawbuf, rawsize,      \
                               cdbop, thandle)                          \
    capi_validate_rawbuf( (direction), (format),                        \
                          (rawbuf), (rawsize),                          \
                          (cdbop), (thandle),                           \
                          __FILE__, __LINE__, __FUNCTION__)

#  define CAPI_TRACE(level, fmt, ...)                   \
    do {                                                \
        capi_trace(__FILE__, __LINE__, __FUNCTION__,    \
                   level, fmt, ##__VA_ARGS__);          \
    } while (0)
#endif

#define CAPI_SILENT(fmt, ...)                                \
    CAPI_TRACE(CAPI_TRACE_SILENT, fmt, ##__VA_ARGS__)

#define CAPI_BRIEF(fmt, ...)                                 \
    CAPI_TRACE(CAPI_TRACE_BRIEF, fmt, ##__VA_ARGS__)

#define CAPI_PROTOCOL(fmt, ...)                              \
    CAPI_TRACE(CAPI_TRACE_PROTOCOL, fmt, ##__VA_ARGS__)

#define CAPI_VERBOSE(fmt, ...)                               \
    CAPI_TRACE(CAPI_TRACE_VERBOSE, fmt, ##__VA_ARGS__)

#define CAPI_EXTERNAL() do { CAPI_BRIEF("API\n"); } while (0)

#define LASTERR_ORIGINATED()                                            \
    char *lasterr_prefix = "";                                          \
    char *lasterr_origin = "originated at: ";                           \
    char *lasterr_msg = "";                                             \
    if (confd_errno != CONFD_OK) {                                      \
        lasterr_prefix = lasterr_origin;                                \
        lasterr_msg = confd_lasterr();                                  \
    }                                                                   \
    CAPI_BRIEF("error\n");

#define LASTERR_BADTERM()                                               \
    confd_internal_error(                                               \
        "%s:%d: Bad term\nd,%s%s",                                      \
        __FILE__,                                                       \
        __LINE__,                                                       \
        lasterr_prefix,                                                 \
        lasterr_msg)                                                    \

#define BADTERM()                               \
    do {                                        \
        CAPI_BRIEF("badterm\n");                \
        LASTERR_ORIGINATED();                   \
        return LASTERR_BADTERM();               \
    } while (0)

#define BADTERM_IF(expr)                        \
    do {                                        \
        CAPI_VERBOSE("badterm_if\n");           \
        if ( (expr) ) BADTERM();                \
    } while (0)

#define DO_RET()                                \
    do {                                        \
        CAPI_BRIEF("do_ret\n");                 \
        return ret;                             \
    } while (0)

#define DO_RET_IF(expr)                         \
    do {                                        \
        CAPI_VERBOSE("do_ret_if\n");            \
        if ( (expr) ) DO_RET();                 \
    } while (0)

#define SAFE_RET2(label)                        \
    do {                                        \
        CAPI_BRIEF("safe_ret\n");               \
        goto label;                             \
    } while (0)

#define SAFE_RET()                              \
    do { SAFE_RET2(saferet); } while (0)

#define SAFE_RET_IF2(label, expr)               \
    do {                                        \
        CAPI_VERBOSE("safe_ret_if\n");          \
        if (expr) SAFE_RET2(label);             \
    } while (0)

#define SAFE_RET_IF(expr)                               \
    do { SAFE_RET_IF2(saferet, expr); } while (0)

#define SAFE_BADTERM2(label)                    \
    do {                                        \
        CAPI_BRIEF("safe_badterm\n");           \
        LASTERR_ORIGINATED();                   \
        ret = LASTERR_BADTERM();                \
        goto label;                             \
    } while (0)

#define SAFE_BADTERM()                          \
    do { SAFE_BADTERM2(saferet); } while (0)

#define SAFE_BADTERM_IF2(label, expr)           \
    do {                                        \
        CAPI_VERBOSE("safe_badterm_if\n");      \
        if ( (expr) ) SAFE_BADTERM2(label);     \
    } while (0)

#define SAFE_BADTERM_IF(expr)                           \
    do { SAFE_BADTERM_IF2(saferet, expr); } while (0)

#define EI_TO_CONFD(status) ((status) == 0 ? CONFD_OK : CONFD_ERR);

#define IS_INTEGER_EXT(type)                    \
    (type == ERL_SMALL_INTEGER_EXT ||           \
     type == ERL_INTEGER_EXT       ||           \
     type == ERL_SMALL_BIG_EXT     ||           \
     type == ERL_LARGE_BIG_EXT)

/* for confd_do_connect() */
#define CLIENT_CAPI         3
#define CLIENT_CDB          5
#define CLIENT_MAAPI        7
#define CLIENT_STREAM       8
#define CLIENT_EVENT_MGR   11
#define CLIENT_HA          17

#define IPC_PROTO_OK                      0
#define IPC_PROTO_BAD_VSN                 1
#define IPC_PROTO_BAD_SIZES               2
#define IPC_PROTO_WANT_CHALLENGE   (1 << 7)  // ORed with CLIENT_XXX


/* Used internally by confd_lib.c */
#define CONFD_TRANS_REPLY_OK               101
#define CONFD_TRANS_REPLY_ERROR            102
#define CONFD_DATA_REPLY_VALUE            103
#define CONFD_DATA_REPLY_OK               104
#define CONFD_DATA_REPLY_ERROR            105

#define get_int16(s) ((((unsigned char *)  (s))[0] << 8) | \
                      (((unsigned char *)  (s))[1]))


#define put_int16(i, s) {((unsigned char *)(s))[0] = ((i) >> 8) & 0xff; \
                        ((unsigned char *)(s))[1] = (i)         & 0xff;}



#define get_int32(s) ((((unsigned char *) (s))[0] << 24) | \
                      (((unsigned char *) (s))[1] << 16) | \
                      (((unsigned char *) (s))[2] << 8)  | \
                      (((unsigned char *) (s))[3]))

#define put_int32(i, s) {((char *)(s))[0] = (char)((i) >> 24) & 0xff; \
                         ((char *)(s))[1] = (char)((i) >> 16) & 0xff; \
                         ((char *)(s))[2] = (char)((i) >> 8)  & 0xff; \
                         ((char *)(s))[3] = (char)((i)        & 0xff);}



/* avoid warnings when passing u_int32_t to void * on 64-bit */
#define INT2VOID(i) ((void *)((uintptr_t)(i)))

#ifdef DISABLE_THREADS
#define PTHREAD_KEY_T                       void*
#define PTHREAD_MUTEX_T                     void*
#define PTHREAD_MUTEX_INITIALIZER           NULL
#define PTHREAD_KEY_CREATE(key, destructor)
#define PTHREAD_SETSPECIFIC(key, value)     ((key) = (value))
#define PTHREAD_GETSPECIFIC(key)            (key)
#define PTHREAD_MUTEX_INIT(mutex, attr)
#define PTHREAD_MUTEX_LOCK(mutex)           (*((char *)(mutex)) = 0)
#define PTHREAD_MUTEX_UNLOCK(mutex)
#define PTHREAD_MUTEX_DESTROY(mutex)
#define PTHREAD_SELF()                      0
#else
#include <pthread.h>
#define PTHREAD_KEY_T                       pthread_key_t
#define PTHREAD_MUTEX_T                     pthread_mutex_t
#define PTHREAD_KEY_CREATE                  pthread_key_create
#define PTHREAD_SETSPECIFIC                 pthread_setspecific
#define PTHREAD_GETSPECIFIC                 pthread_getspecific
#define PTHREAD_MUTEX_INIT                  pthread_mutex_init
#define PTHREAD_MUTEX_LOCK                  pthread_mutex_lock
#define PTHREAD_MUTEX_UNLOCK                pthread_mutex_unlock
#define PTHREAD_MUTEX_DESTROY               pthread_mutex_destroy
#define PTHREAD_SELF                        pthread_self
#endif  /* DISABLE_THREADS */


/* we can send the following ha orders to confd */
enum confd_ha_order_type {
    CONFD_HA_ORDER_BEMASTER   = 1,
    CONFD_HA_ORDER_BESLAVE    = 2,
    CONFD_HA_ORDER_BENONE     = 3,  /* back to initial state */
    CONFD_HA_ORDER_GETSTATUS  = 4,
    CONFD_HA_ORDER_SLAVE_DEAD = 5,
    CONFD_HA_ORDER_BERELAY    = 6
};

struct named_type {
    char *name;
    struct confd_type *type;
};

struct schema {
    u_int32_t nshash;
    const char *uri;
    const char *prefix;
    const char *revision;
    const char *module;
    struct confd_cs_node *root;
    int loaded;
    struct named_type *types;
    int num_types;
};

typedef struct xml_tag mount_id_t;

#define ROOT_MOUNT_ID ((mount_id_t){0, 0})

struct mns_map {
    mount_id_t mount_id;
    struct hashtable *nshash2prefix;
    struct hashtable *prefix2nshash;
};

extern int skip_n_terms_ei(const char *ebuf, int *eindex, int n);
extern void confd_printf(int syslogprio, const char *fmt, ...) PRINTF(2,3);
extern void confd_trace_printf(const char *fmt, ...) PRINTF(1,2);
extern char *format_path(int isrel, const ETERM *path);
extern char *format_path_ei(int isrel, const char *ebuf, const int *eindex);
extern void init_pkeys(void);
extern int ret_errno_err(const char *fmt, ...) PRINTF(1,2);
extern void *ret_null(const char *fmt, ...) PRINTF(1,2);
extern int ret_err(int ecode, const char *fmt, ...) PRINTF(2,3);
extern int ret_confd_errno_err(int ecode, const char *fmt, ...) PRINTF(2,3);
extern int read_fill(int fd, unsigned char *buf, int len);
extern int confd_write(int socket, const unsigned char *buf, int len);
extern void term_to_ip4(struct in_addr *ip, const ETERM *term);
extern int term_to_ip4_ei(struct in_addr *ip, const char *ebuf, int *eindex);
extern ETERM *ip4_to_term(const struct in_addr *ip);
extern int ip4_to_term_ei(ei_x_buff *exbuf, const struct in_addr *ip);
extern void term_to_ip6(struct in6_addr *ip6, const ETERM *term);
extern int term_to_ip6_ei(struct in6_addr *ip6, const char *ebuf, int *eindex);
extern ETERM *ip6_to_term(const struct in6_addr *ip6);
extern int ip6_to_term_ei(ei_x_buff *exbuf, const struct in6_addr *ip6);
extern confd_value_t *eterm_to_val(const ETERM *term, confd_value_t *v);
extern int eterm_to_val_ei(const char *ebuf, int *eindex, confd_value_t *v);
extern confd_tag_value_t *eterm_to_tag_val(const ETERM *term,
                                           confd_tag_value_t *tv,
                                           int allow_unqualified);
extern int eterm_to_tag_val_ei(const char *ebuf, int *eindex,
                               confd_tag_value_t *tv,
                               int allow_unqualified,
                               confd_tag_value_t ** val);
extern int etermlist_to_vals(ETERM *list, confd_value_t *vp, int n);
extern int etermlist_to_tag_vals(ETERM *list, confd_tag_value_t *tvp, int n);
extern int etermlist_to_tag_vals_ei(const char *ebuf, int *eindex,
                                    confd_tag_value_t *tvp,
                                    int nexpected,
                                    int *nvals);
extern void confd_free_eterm_val(confd_value_t *v);
extern void confd_free_eterm_keypath(confd_hkeypath_t *kp);
extern void confd_trace(enum confd_debug_level level,
                        const char *fmt, ...) PRINTF(2,3);
extern void v_config_trace(enum confd_debug_level level,const char *fmt,
                           va_list args);

extern void *ret_errno_err_null(const char *fmt, ...) PRINTF(1,2);
extern int op_write(int socket, int cdbop, int thandle);
extern int op_write_buf(int socket, int cdbop, const char *xbuf,
                        int xlen,int thandle);
extern int term_write(int socket, const ETERM *term,
                      int cdbop, int thandle);
extern int term_write_ei(int socket, const char *ebuf, int esize,
                         int cdbop, int thandle);
extern ETERM *term_read(int socket, int *ret, int cdbop);
extern int term_read_ei(int socket, char **ybuf, int *yindex,
                        int cdbop);
extern ETERM *confd_call(int socket, const ETERM *term, int *status);
extern int confd_call_ei(int socket, const char *qbuf, int qsize,
                         char **ybuf, int *yindex);

extern unsigned char *confd_memdup(const unsigned char *p, int n);
extern void *confd_malloc(size_t sz);
extern void confd_set_errno(int ecode);
extern void confd_set_lasterr(const char *fmt, ...) PRINTF(1,2);
extern void confd_vset_lasterr(const char *fmt, va_list args);
extern void clr_confd_err(void);
extern confd_value_t *confd_value_dup_to_mallf(const confd_value_t *v,
                                               confd_value_t *newv,
                                               void *(*mallf)(size_t size),
                                               void (*freef)(void *ptr));

extern int confd_fpp_kpath(FILE *stream, const confd_hkeypath_t *hkeypath);
extern void confd_register_schemas(struct schema *new, int num_new,
                                   int num_loaded, struct mns_map *new_mns_maps,
                                   int num_new_gms, int mmapped);
extern int confd_check_init(void);

extern int decode_binary_ei(const char *ebuf, int *eindex,
                            char **bin, long *sz);
extern int decode_atom_ei(const char *ebuf, int *eindex,
                          char **bin, long *sz);
extern int decode_binary_to_buf_ei(const char *ebuf, int *eindex,
                            char *buf, long *sz, int buf_size);
extern int decode_binary_or_atom_ei(char *ybuf, int *yindex,
                                    char **bin, long *sz);

/* Note there is zero count on these */
#define TE(_r,_p) ERL_TUPLE_ELEMENT((_r), (_p))
#define TUINT(_res, _pos) ERL_INT_UVALUE(ERL_TUPLE_ELEMENT((_res), (_pos)))
#define TINT(_res, _pos) ERL_INT_VALUE(ERL_TUPLE_ELEMENT((_res), (_pos)))
#define TZONE(_res, _pos) ERL_IS_NIL(TE(_res,_pos)) ? \
                             CONFD_TIMEZONE_UNDEF : TINT(_res, _pos)

#define IS_INTEGER_OR_UNSIGNED_INTEGER(term) \
    (ERL_IS_INTEGER(term) || ERL_IS_UNSIGNED_INTEGER(term))

extern FILE *confd_debug_stream;
extern enum confd_debug_level confd_debug_level;
extern char confd_daemon_name[64];
extern int confd_version;

/* thread-safe maapi_load_schemas() - initialized by confd_init() */
extern PTHREAD_MUTEX_T maapi_load_schemas_lock;

/* populated by maapi_load_schemas(), accessed by confd_lib */
extern struct hashtable *hash2str_tab;
extern struct hashtable *str2hash_tab;
extern int confd_hashtables_mmapped;

/* for IPC access check - initialized by confd_init() */
extern unsigned char *confd_ipc_access_secret;

/* needed by load_schemas with shm */
enum confd_vtype_extra {
    CE_INET_ADDRESS = C_MAXTYPE + 1,
    CE_INET_ADDRESS_IP,
    CE_IPPREFIX,
    CE_IP_AND_PLEN,
    CE_SIZE,
    CE_HEX_LIST,
    CE_OCTET_LIST,
    CE_BASE64_BINARY,
    CE_NORMALIZED_STRING,
    CE_TOKEN,
    CE_LANGUAGE,
    CE_NMTOKEN,
    CE_NAME,
    CE_NCNAME,
    CE_NMTOKEN_LIST,
    CE_NMTOKENS,
    CE_IDREF_LIST,
    CE_IDREFS,
    CE_NON_POSITIVE_INTEGER,
    CE_NEGATIVE_INTEGER,
    CE_NON_NEGATIVE_INTEGER,
    CE_POSITIVE_INTEGER,
    CE_NO_TYPE,
    CE_MAXTYPE
};
extern struct confd_type confd_types[CE_MAXTYPE];

typedef enum confd_iter_ret (confd_diff_iter_function_t)(confd_hkeypath_t *kp,
                                                         enum confd_iter_op op,
                                                         confd_value_t *oldv,
                                                         confd_value_t *newv,
                                                         void *state);

typedef enum confd_iter_ret (confd_iter_function_t)(
    confd_hkeypath_t *kp,
    confd_value_t *v,
    confd_attr_value_t *attr_vals,
    int num_attr_vals,
    void *state);

/* functions used by both CDB and maapi */

#define op_request_term(sock, op, thandle, isrel, arg, status)          \
    op_request_term2((sock), (op), (thandle), (isrel), (arg), (status), 1)

extern ETERM *op_request_term2(int sock, int op, int thandle, int isrel,
                                const ETERM *arg, int *status, int clr_err);

extern ETERM *op_request_term2_ei(int sock, int op, int thandle, int isrel,
                                  const char *ebuf, int esize,
                                  int *status, int clr_err);

extern int op_request_term2_ei_ei(int sock, int op, int thandle, bool isrel,
                                  const char *qbuf, int qsize,
                                  char **ybuf, int *yindex, int clr_err);

extern int request_int(int sock, unsigned int op, int thandle,
                       const char *fmt, va_list args);


extern void request_v(int sock, unsigned int op, int thandle,
                      int *status, confd_value_t *v, const char *fmt,
                      va_list args);

extern int fmt_request(int sock, unsigned int op, int thandle,
                       const char *fmt, va_list args);

extern void arg_request(int sock, unsigned int op, int thandle, int *status,
                        int isrel, confd_value_t *v, const ETERM *arg);

extern int pp_keyval(char *buf, int n, const confd_value_t *v, int ns);
extern int substitute_percent(const char *src, char *dst, int dstsz,
                              va_list args, int skip_keys);
extern ETERM *parse_path(int *isrel, const char *fmt, va_list args);
extern ETERM *parse_path_old(int *isrel, const char *fmt, va_list args);
extern int parse_path_ei(ei_x_buff *exbuf, bool *isrel,
                         const char *fmt, va_list args);
extern ETERM *mk_tag_elem2(const char *tagstr);
extern ETERM *_confd_parse_choice_path(const char *path);
extern ETERM *val_to_term(const confd_value_t *v);
extern int val_to_term_ei(ei_x_buff *exbuf, const confd_value_t *v);
extern ETERM *vals_to_termlist(const confd_value_t *vp, int n, int ret_tup);
extern ETERM *tag_vals_to_termlist(const confd_tag_value_t *vp, int n,
                                   int ret_tup);
extern int bin_copy(char *buf, int n, const ETERM *b);
extern int bin_eq(const ETERM *b, char *s2);
extern char *bin_dup(const ETERM *b);
extern int erl_is_initialized;
extern int check_vsn_reply(int);
extern int populate_keypath(const ETERM *kp, confd_hkeypath_t *args);
extern int populate_keypath_ei(const char *ebuf, int *eindex,
                               confd_hkeypath_t *args);
extern int confd_dup_value(confd_value_t *v);
extern void confd_fprintf(int syslogprio, FILE *stream,
                          const char *fmt, ...) PRINTF(3,4);
extern void confd_report_err(enum confd_debug_level level,
                             const char *fmt, ...) PRINTF(2,3);
extern void confd_fatal_log(const char *fmt, ...) PRINTF(1,2);
extern int confd_internal_error(const char *fmt, ...) PRINTF(1,2);

extern int _confd_iterate_send_reply(int sock, enum confd_iter_ret uret);
extern int _confd_iterate(int sock, void *iter_function, void *initstate);
extern int _confd_iterate_resume(int sock, enum confd_iter_ret reply,
                                 void *iter_function, void *resumestate,
                                 char *trace);

extern ETERM *hkeypath_to_eterm(confd_hkeypath_t *hkp);
extern int hkeypath_to_eterm_ei(ei_x_buff *exbuf, confd_hkeypath_t *hkp);
extern int confd_val_num_cmp(const confd_value_t *v1, const confd_value_t *v2);
extern void confd_clear_hkeypath(confd_hkeypath_t *hkp);

extern int _confd_vset_error(
    struct confd_error *error,
    enum confd_errcode code,
    u_int32_t apptag_ns, u_int32_t apptag_tag,
    const confd_tag_value_t *error_info, int n, int flags,
    const char *fmt, va_list args);
extern ETERM *_confd_make_error(struct confd_error *error);

extern char *_confd_op2str(int op);

extern void _confd_mk_uinfo(const ETERM *utup, struct confd_user_info *uinfo);

extern int _confd_mk_uinfo_ei(const char *ubuf, int *uindex,
                              struct confd_user_info *uinfo);

extern struct confd_cs_node *_confd_cs_node_do_cd(
    const struct confd_cs_node *start, char *dst);

extern char *_confd_mns_nshash2prefix(mount_id_t *mount_ids, int n,
                                      u_int32_t nshash);

extern u_int32_t _confd_mns_prefix2nshash(mount_id_t *mount_ids, int n,
                                          const char *prefix);

#undef PRINTF

#endif
