/*
 * Copyright 2005-2007 Tail-F Systems AB
 */

#ifndef CAPI_NO_DEBUG
/* BUGBUG: Needed for logging program name on Linux */
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdbool.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/tcp.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>
#include <assert.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <syslog.h>
#include <inttypes.h>
#include <time.h>
#include <sys/time.h>

#include "erl_interface.h"
#include "ei.h"
#include "confd_lib.h"
#include "confd_internal.h"
#include "confd_util.h"
#include "confd_cdb.h"
#include "confd_type.h"
#include "confd_proto.h"
#include "maapi_proto.h"
#include "cdb_proto.h"
#include "confd_ipc_access.h"
#include "hash/hashtable.h"

/* capi trace includes */
#include <fcntl.h>
#include <sys/stat.h>

struct hashtable *hash2str_tab = NULL;
struct hashtable *str2hash_tab = NULL;
int confd_hashtables_mmapped = 0;

FILE *confd_debug_stream = NULL;
enum confd_debug_level confd_debug_level = CONFD_DEBUG;
char confd_daemon_name[64];
int confd_version;
int confd_maxdepth;
int confd_maxkeylen;
unsigned char *confd_ipc_access_secret = NULL;
static char *month2string[] = {
    /* tm_mon in struct tm is 0..11 */
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
};

// #define VERBOSE_PTHREAD_DEBUG true

#ifdef DISABLE_THREADS
#undef VERBOSE_PTHREAD_DEBUG
#endif

#ifndef VERBOSE_PTHREAD_DEBUG

#define VERBOSE_PTHREAD_MUTEX_LOCK(mutex)   PTHREAD_MUTEX_LOCK(mutex)
#define VERBOSE_PTHREAD_MUTEX_UNLOCK(mutex) PTHREAD_MUTEX_UNLOCK(mutex)

#else

#define PTHREAD_MUTEX_TRYLOCK pthread_mutex_trylock

#define VERBOSE_PTHREAD_MUTEX_LOCK(mutex)               \
    do {                                                \
        if (PTHREAD_MUTEX_TRYLOCK(mutex) == 0) {        \
            printf("\nPTHREAD GOT LOCK %d %s\n",        \
                   __LINE__, __FUNCTION__);             \
        } else {                                        \
            printf("\nPTHREAD TRY LOCK %d %s <=====\n", \
                   __LINE__, __FUNCTION__);             \
            PTHREAD_MUTEX_LOCK(mutex);                  \
            printf("\nPTHREAD HAV LOCK %d %s <=====\n", \
                   __LINE__, __FUNCTION__);             \
        }                                               \
    } while (0)

#define VERBOSE_PTHREAD_MUTEX_UNLOCK(mutex)     \
    do {                                        \
        printf("\nPTHREAD UN  LOCK %d %s\n",    \
               __LINE__, __FUNCTION__);         \
        PTHREAD_MUTEX_UNLOCK(mutex);            \
    } while (0)

#endif  /* DISABLE_THREADS */

#define BADTERM_RET()                                                   \
    do {                                                                \
        int v;                                                          \
        if (confd_debug_level > 0 && confd_debug_stream) {              \
            fprintf(confd_debug_stream, "BADTERM: ");                   \
            ei_decode_version(ebuf, &orig_index, &v);                   \
            confd_print_term(confd_debug_stream, ebuf, &orig_index);    \
            fprintf(confd_debug_stream, "\n");                          \
        }                                                               \
        BADTERM();                                                      \
    } while (0)

#define BADTERM_TEST(expr)                      \
    CAPI_VERBOSE( "capi_test\n");               \
    do { if (expr) BADTERM_RET(); } while(0)

#define BADTERM_FREE_TEST(ptr, expr)            \
    do {                                        \
        CAPI_VERBOSE("capi_free_test\n");       \
        if (expr) {                             \
            free(ptr);                          \
            BADTERM_RET();                      \
        }                                       \
    } while(0)

#define BADHKP_TEST(expr)                                               \
    do {                                                                \
        CAPI_VERBOSE("badhkp_test\n");                                  \
        if (expr) {                                                     \
            int v;                                                      \
            if (confd_debug_level > 0 && confd_debug_stream) {          \
                fprintf(confd_debug_stream, "ERM: ");                   \
                ei_decode_version(ebuf, &orig_index, &v);               \
                confd_print_term(confd_debug_stream, ebuf, &orig_index); \
                fprintf(confd_debug_stream, "\n");                      \
            }                                                           \
            BADTERM();                                                  \
        }                                                               \
    } while(0)

#define INVALID_TERM_RET()                                      \
    do {                                                        \
        LASTERR_ORIGINATED();                                   \
        return confd_internal_error(                            \
            "%s(%d): Invalid term to format_path()\n%s%s",      \
            __FILE__,                                           \
            __LINE__,                                           \
            lasterr_prefix,                                     \
            lasterr_msg);                                       \
    } while (0)

#define INVALID_TERM_TEST(expr)                         \
    CAPI_VERBOSE("invalid_term_test\n");             \
    do { if (expr) INVALID_TERM_RET(); } while(0)

static PTHREAD_MUTEX_T capi_mutex = PTHREAD_MUTEX_INITIALIZER;
static enum capi_trace_level capi_level = CAPI_TRACE_UNSET;
static FILE *capi_fd = NULL;
static int capi_validate = -1;

#define UNSAFE_CAPI_TRACE(fmt, ...)                             \
    do {                                                        \
        unsafe_capi_trace(__FILE__, __LINE__, __FUNCTION__,     \
                          fmt, ##__VA_ARGS__);                  \
    } while (0)

static void unsafe_capi_vtrace(const char *file, int line, const char *fun,
                                  const char *fmt, va_list args)
{
    char newfmt[BUFSIZ];

    snprintf(newfmt, sizeof(newfmt), "%s:%d: %s - %s", file, line, fun, fmt);
    vfprintf(capi_fd, newfmt, args);
    fflush(capi_fd);
}

static void unsafe_capi_trace(const char *file, int line, const char *fun,
                                 const char *fmt, ...)
{
    va_list args;

    va_start(args, fmt);
    unsafe_capi_vtrace(file, line, fun, fmt, args);
    va_end(args);
}

static void capi_trace_close(void)
{
    VERBOSE_PTHREAD_MUTEX_LOCK(&capi_mutex);

    if (capi_fd != NULL) {
        UNSAFE_CAPI_TRACE("atexit\n");

        fclose(capi_fd);
        capi_fd = NULL;
        capi_level = CAPI_TRACE_SILENT;
    }

    VERBOSE_PTHREAD_MUTEX_UNLOCK(&capi_mutex);
}

static FILE* capi_trace_open(void)
{
    FILE *fd = NULL;
    char *tracefile = NULL;
    char *dyndir = NULL;
    char *logdir = getenv("LUX_EXTRA_LOGS");
    int pid = (int)getpid();
    char *fmt = "%s/capi.%d.log";
    int len;

    if (logdir) {
        mkdir(logdir, 0755);
    } else {
        dyndir = getcwd(NULL, 0);
        logdir = dyndir;
    }

    len = strlen(fmt) + strlen(logdir) + 20;

    /* Cannot use asprintf as it is from GNU and not included in POSIX/C99 */
    tracefile = confd_malloc(len);
    if (tracefile == NULL) goto saferet;

    confd_snprintf(tracefile, len, fmt, logdir, pid);

    fd = fopen(tracefile, "w");
    if (fd == NULL) {
      perror("open capi.*.log");
    } else {
      setvbuf(fd, (char *)NULL, _IONBF, 0); /* unbuffered i/o */
    }

saferet:
    free(tracefile);
    free(dyndir);
    return fd;
}

__attribute__((constructor)) void capi_init(void)
{
    if (capi_level != CAPI_TRACE_UNSET) {
        /* Already initiated */
        return;
    }

    char *user_level = getenv("CAPI_TRACE_LEVEL");
    if (!user_level) user_level = CAPI_TRACE_DEFAULT;

    VERBOSE_PTHREAD_MUTEX_LOCK(&capi_mutex);

    if (capi_level != CAPI_TRACE_UNSET) {
        /* Initiated by someone else while we were waiting */
        VERBOSE_PTHREAD_MUTEX_UNLOCK(&capi_mutex);
        return;
    }

    char c = user_level[0];
    switch (c) {
    case 's': {
        capi_level = CAPI_TRACE_SILENT;
        capi_validate = 0;
        break;
    }
    case 'b': {
        capi_level = CAPI_TRACE_BRIEF;
        capi_validate = 0;
        break;
    }
    case 'p': {
        capi_level = CAPI_TRACE_PROTOCOL;
        capi_validate = 0;
        break;
    }
    case 'v': {
        capi_level = CAPI_TRACE_VERBOSE;
        capi_validate = 0;
        break;
    }
    case 'S': {
        capi_level = CAPI_TRACE_SILENT;
        capi_validate = 1;
        break;
    }
    case 'B': {
        capi_level = CAPI_TRACE_BRIEF;
        capi_validate = 1;
        break;
    }
    case 'P': {
        capi_level = CAPI_TRACE_PROTOCOL;
        capi_validate = 1;
        break;
    }
    case 'V': {
        capi_level = CAPI_TRACE_VERBOSE;
        capi_validate = 1;
        break;
    }
    default: {
        /* Minimal system impact */
        capi_level = CAPI_TRACE_SILENT;
        capi_validate = 0;
    }
    }

    if (capi_level > CAPI_TRACE_SILENT) {
        capi_fd = capi_trace_open();

        if (capi_fd == NULL) {
            capi_level = CAPI_TRACE_SILENT;
        } else {
            atexit(capi_trace_close);

#define BADTERM_FMT "progname is %s\n"

#if defined(__APPLE__) || defined(__FreeBSD__)
            if (getprogname() == NULL) {
                UNSAFE_CAPI_TRACE(BADTERM_FMT, "unknown");
            } else {
                UNSAFE_CAPI_TRACE(BADTERM_FMT, getprogname());
            }
#elif defined(_GNU_SOURCE)
            UNSAFE_CAPI_TRACE(BADTERM_FMT, program_invocation_name);
#else
            UNSAFE_CAPI_TRACE(BADTERM_FMT, "unknown");
#endif

#undef BADTERM_FMT
        }
    }
    VERBOSE_PTHREAD_MUTEX_UNLOCK(&capi_mutex);
}

void capi_trace(const char *file, int line, const char *fun,
                   int level, const char *fmt, ...)
{
#ifdef VERBOSE_PTHREAD_DEBUG
    printf("\nPTHREAD TRACE    %d %s (%s)\n", line, fun, file);
#endif

    capi_init();

    if (capi_level >= level) {
        va_list args;

        VERBOSE_PTHREAD_MUTEX_LOCK(&capi_mutex);

        va_start(args, fmt);
        unsafe_capi_vtrace(file, line, fun, fmt, args);
        va_end(args);

        VERBOSE_PTHREAD_MUTEX_UNLOCK(&capi_mutex);
    }
}

static int capi_validate_ebuf(const char *context, const char *ebuf, int esize,
                         const char *file, int line,  const char *fun)
{
    int eversion = -1;
    int pindex;
    int vindex;
    int etype = -1;
    int elen = -1;
    int ret = CONFD_OK;

    capi_init();

    if (!capi_validate) return CONFD_OK;
    if (ebuf == NULL)      SAFE_BADTERM();
    if (esize <= 0)        SAFE_BADTERM();

    pindex = 0;
    if (ei_decode_version(ebuf, &pindex, &eversion) != 0) {
        eversion = -1;
        SAFE_BADTERM();
    }
    vindex = pindex;
    if (ei_get_type(ebuf, &vindex, &etype, &elen) != 0) {
        etype = -1;
        elen = -1;
        SAFE_BADTERM();
    }

    vindex = pindex;
    if (ei_skip_term(ebuf, &vindex) != 0) {
        vindex = pindex;
        SAFE_BADTERM();
    }

    if (vindex != esize) {
        CAPI_BRIEF("BAD term size: expected=%d actual=%d\n", esize, vindex);
        if (vindex < esize) {
            if (ei_get_type(ebuf, &vindex, &etype, &elen) == 0) {
                CAPI_BRIEF("BAD trailing term: type=%c (%d) len=%d\n",
                              etype, etype, elen);
            } else {
                CAPI_BRIEF("BAD term: trailing garbage after term\n");
            }
        } else {
            CAPI_BRIEF("BAD term: term bigger than buffer\n");
        }
        SAFE_BADTERM();
    }
    ret = CONFD_OK;

saferet:
    if (ret != CONFD_OK) {
        CAPI_BRIEF(
            "Invoked from file %s at line %d in function %s -\
 eversion=%d etype=%c (%d) elen=%d\n",
            file, line, fun, eversion, etype, etype, elen);
    }
    return ret;
}

int capi_validate_rawbuf(enum capi_dir direction, enum capi_packet packet,
                         const unsigned char *rawbuf, int rawsize,
                         int cdbop, int thandle,
                         const char *file, int line, const char *fun)
{
    char *context = "MISSING CONTEXT";
    int bufop = -1;
    /* int bufthandle = -1; */
    char *ebuf = (char *)rawbuf; /* read only */
    int esize = rawsize;
    int ret = CONFD_ERR;;
    int is_send = (direction == capi_dir_send) ? 1 : 0;
    int is_opaque = (packet != capi_packet_eterm) ? 1 : 0;
    int is_raw = (packet == capi_packet_raw) ? 1 : 0;
    char *raw_tag = "";
    char *cdbop_tag = "";
    char *thandle_tag = "";
    char *opaque_tag = "";
    char *errcode_tag = "";

    capi_init();

    if (!capi_validate)         return CONFD_OK;
    if (rawbuf == NULL)            SAFE_BADTERM();
    if (rawsize < 0)               SAFE_BADTERM();
    if (!is_send && thandle != -1) SAFE_BADTERM();
    if (is_raw && ((cdbop != -1) || (thandle != -1))) SAFE_BADTERM();

    if (cdbop != -1) {
        bufop = get_int32(rawbuf);
        ebuf += 4;
        esize -= 4;
    }
    if (thandle != -1) {
        /* bufthandle = get_int32(rawbuf); */
        ebuf += 4;
        esize -= 4;
    }

    if (is_send) {
        /* CLIENT SEND with cdbop and thandle given
         *
         * len - 4 bytes
         * blob - len bytes
         *     if cdbop != -1 =>  CDB or MAAPI
         *       bufop - 4 bytes
         *     if thandle != -1 =>
         *        thandle 4 bytes
         *     ETERM
         */

        context = "SEND";
        if (is_raw) {
            raw_tag = "<RAW/>";
        } else {
            if (cdbop != -1)   cdbop_tag   = "<CDBOP/>";
            if (thandle != -1) thandle_tag = "<THANDLE/>";
            if (is_opaque)     opaque_tag  = "<OPAQUE/>";
        }
    } else {
        /* CLIENT RECEIVE with cdbop given
         *
         * len - 4 bytes
         * blob - len bytes
         *     if cdbop == -1 => EXTDB
         *         ETERM
         *     if cdbop != -1 =>  CDB or MAAPI
         *       bufop - 4 bytes
         *           if bufop == cdbop =>
         *               if len == 4 =>
         *                   NULL - no ETERM
         *               if len != 4 =>
         *                   ETERM
         *           if bufop != cdbop =>
         *               if CDB_REPLY_IS_ERROR(bufop) &&
         *                  CDB_OP(bufop) == cdbop =>
         *                   errcode - 4 bytes
         *                   if len == 8 =>
         *                       NULL - no ETERM
         *                   if len != 8 =>
         *                       ETERM
         */

        context = "RECV";

        if (is_raw) {
            raw_tag = "<RAW/>";
        } else {
            if (cdbop == -1) {
                if (is_opaque) opaque_tag = "<OPAQUE/>";
            } else {
                cdbop_tag = "<CDBOP/>";
                if (bufop == cdbop) {
                    if (rawsize == 4) {
                        is_opaque = 1;
                        opaque_tag = "<OPAQUE/>";
                        /* NULL - no ETERM */
                    } else {
                        if (is_opaque) opaque_tag = "<OPAQUE/>";
                    }
                } else {
                    if (CDB_REPLY_IS_ERROR(bufop) && CDB_OP(bufop) == cdbop) {
                        errcode_tag = "<ERRCODE/>";
                        ebuf += 4;
                        esize -= 4;
                        if (rawsize == 8) {
                            is_opaque = 1;
                            opaque_tag = "<OPAQUE/>";
                            /* NULL - no ETERM */
                        } else {
                            if (is_opaque) opaque_tag = "<OPAQUE/>";
                        }
                    }
                }
            }
        }
    }

    if (capi_level >= CAPI_TRACE_PROTOCOL) {
        int bufsize = rawsize + 200;
        char buf[bufsize];
        int pos = 0;

        snprintf(buf, bufsize, "<BIN%s>%s%s%s%s%s",
                 context,
                 raw_tag, cdbop_tag, thandle_tag, opaque_tag, errcode_tag);
        pos = strlen(buf);

        memcpy(buf+pos, rawbuf, rawsize);
        pos += rawsize;

        snprintf(&buf[pos], bufsize-pos, "</BIN%s>\n", context);
        pos += strlen(buf+pos);

        VERBOSE_PTHREAD_MUTEX_LOCK(&capi_mutex);

        fwrite(buf, pos, 1, capi_fd);
        fflush(capi_fd);

        VERBOSE_PTHREAD_MUTEX_UNLOCK(&capi_mutex);
    }

    if (is_opaque) {
        ret = CONFD_OK;
    } else {
        ret = capi_validate_ebuf(context, ebuf, esize, file, line, fun);
    }

saferet:
    if (ret != CONFD_OK) {
        CAPI_BRIEF(
            "Invoked from %s(%d) - %s: op=%d thandle=%d rawsize=%d esize=%d\n",
            file, line, fun, cdbop, thandle, rawsize, esize);
    }
    return ret;
}

void *confd_malloc(size_t sz)
{
    void *r;
    if (sz == 0) {
        /* alloc a dummy byte to keep Electric Fence happy */
        sz = 1;
    }
    if ((r = malloc(sz)) == NULL)  {
        confd_report_err(CONFD_DEBUG,
                         "libconfd failed to malloc %" PRIuMAX " bytes\n",
                         (uintmax_t)sz);
        confd_set_errno(CONFD_ERR_MALLOC);
    }
    return r;
}

/* 8-Aug-2014::11:15:53.818 13851/7fa7f4653700/42 SEND
   date        time         pid   thread       fd op
   timestamp format as per ConfD/NCS log files
   (a pthread_t can be anything, but the assumption of "pointer or
   integer with size <= pointer" below covers all cases we've seen) */
static void print_proto_start(FILE *fp, char *prefix, int fd, char *op)
{
    struct timeval tv;
    struct tm tm;

    gettimeofday(&tv, NULL);
    /* cast needed for old FreeBSD where tv_sec is a long */
    localtime_r((time_t *)&tv.tv_sec, &tm);
    fprintf(fp, "%s %d-%s-%d::%.2d:%.2d:%.2d.%.3d %lu/%" PRIxPTR "/%d %s ",
            prefix,
            tm.tm_mday, month2string[tm.tm_mon], 1900 + tm.tm_year,
            tm.tm_hour, tm.tm_min, tm.tm_sec, (int)(tv.tv_usec / 1000),
            (unsigned long)getpid(), (uintptr_t)PTHREAD_SELF(), fd,
            op);
}

void term_to_ip4(struct in_addr *ip, const ETERM *term)
{
    ip->s_addr = htonl(
        (ERL_INT_UVALUE(ERL_TUPLE_ELEMENT(term, 0)) << 24) |
        (ERL_INT_UVALUE(ERL_TUPLE_ELEMENT(term, 1)) << 16) |
        (ERL_INT_UVALUE(ERL_TUPLE_ELEMENT(term, 2)) <<  8) |
        (ERL_INT_UVALUE(ERL_TUPLE_ELEMENT(term, 3))));
}

int term_to_ip4_ei(struct in_addr *ip, const char *ebuf, int *eindex)
{
    int arity;
    unsigned long ul;
    unsigned long ipa = 0;
    int i;

    BADTERM_IF(ei_decode_tuple_header(ebuf, eindex, &arity) != 0);
    BADTERM_IF(arity != 4);
    for (i = 0; i < 4; i++) {
        BADTERM_IF(ei_decode_ulong(ebuf, eindex, &ul) != 0);
        ipa = (ipa << 8) | ul;
    }

    ip->s_addr = htonl(ipa);
    return CONFD_OK;
}

ETERM *ip4_to_term(const struct in_addr *ip)
{
    uint32_t iv = ntohl(ip->s_addr);
    ETERM *tup[4];

    tup[0] = erl_mk_uint((iv >> 24) & 0xff);
    tup[1] = erl_mk_uint((iv >> 16) & 0xff);
    tup[2] = erl_mk_uint((iv >> 8)  & 0xff);
    tup[3] = erl_mk_uint((iv)       & 0xff);
    return erl_mk_tuple(tup, 4);
}

int ip4_to_term_ei(ei_x_buff *exbuf, const struct in_addr *ip)
{
    uint32_t iv = ntohl(ip->s_addr);

    BADTERM_IF(ei_x_encode_tuple_header(exbuf, 4) != 0);
    BADTERM_IF(ei_x_encode_ulong(exbuf, (iv >> 24) & 0xff) != 0);
    BADTERM_IF(ei_x_encode_ulong(exbuf, (iv >> 16) & 0xff) != 0);
    BADTERM_IF(ei_x_encode_ulong(exbuf, (iv >> 8)  & 0xff) != 0);
    BADTERM_IF(ei_x_encode_ulong(exbuf, (iv)       & 0xff) != 0);
    return CONFD_OK;
}

void term_to_ip6(struct in6_addr *ip6, const ETERM *term)
{
    int i;
    for (i=0; i<8; i++) {
        unsigned int tmp = ERL_INT_UVALUE(ERL_TUPLE_ELEMENT(term, i));
        ip6->s6_addr[(2*i) + 1] = tmp & 0xff;
        ip6->s6_addr[(2*i)] = (tmp >> 8) & 0xff;
    }
}

int term_to_ip6_ei(struct in6_addr *ip6, const char *ebuf, int *eindex)
{
    int arity;
    int i;

    BADTERM_IF(ei_decode_tuple_header(ebuf, eindex, &arity) != 0);
    BADTERM_IF(arity != 8);
    for (i=0; i<8; i++) {
        unsigned long ul;
        BADTERM_IF(ei_decode_ulong(ebuf, eindex, &ul) != 0);
        ip6->s6_addr[(2*i) + 1] = ul & 0xff;
        ip6->s6_addr[(2*i)] = (ul >> 8) & 0xff;
    }
    return CONFD_OK;
}

ETERM *ip6_to_term(const struct in6_addr *ip6)
{
    int i;
    ETERM *tup[8];

    for (i=0; i<8; i++) {
        tup[i] = erl_mk_uint(ip6->s6_addr[(2*i)+1] |
                             ((ip6->s6_addr[2*i]) << 8));
    }
    return erl_mk_tuple(tup, 8);
}


int ip6_to_term_ei(ei_x_buff *exbuf, const struct in6_addr *ip6)
{
    int i;

    BADTERM_IF(ei_x_encode_tuple_header(exbuf, 8) != 0);
    for (i=0; i<8; i++) {
        BADTERM_IF(ei_x_encode_ulong(exbuf,
                                        ip6->s6_addr[(2*i)+1] |
                                        ((ip6->s6_addr[2*i]) << 8)) != 0);
    }
    return CONFD_OK;
}

/* Take a value term {TypeEnum, Value} and fill */
/* in a confd_value_t pointer                   */
/* Return NULL on failure                       */
confd_value_t *eterm_to_val(const ETERM *term, confd_value_t *v)
{
    if (ERL_IS_INTEGER(term)) {
        v->type = C_INT32;
        v->val.i32 = (int32_t) ERL_INT_VALUE(term);
    }
    else if (ERL_IS_BINARY(term)) {
        v->type = C_BUF;
        v->val.buf.size = ERL_BIN_SIZE(term);
        v->val.buf.ptr = ERL_BIN_PTR(term);
    }
    else if (ERL_IS_ATOM(term)) {
        if (bin_eq(term, "true")) {
            v->type = C_BOOL;
            v->val.boolean = 1;
        }
        else if (bin_eq(term, "false")) {
            v->type = C_BOOL;
            v->val.boolean = 0;
        }
        else if (bin_eq(term, "not_found")) {
            v->type = C_NOEXISTS;
        }
        else if (bin_eq(term, "default")) {
            v->type = C_DEFAULT;
        }
        else {
            v->type = C_BUF;
            v->val.buf.size = ERL_ATOM_SIZE(term);
            v->val.buf.ptr = (unsigned char *)ERL_ATOM_PTR(term);
        }
    }
    else if (ERL_IS_TUPLE(term)) {
        switch (ERL_TUPLE_SIZE(term)) {
        case 2:  {
            int tag = ERL_INT_VALUE(ERL_TUPLE_ELEMENT(term, 0));
            ETERM *vtup = ERL_TUPLE_ELEMENT(term, 1);

            v->type = 0;
            switch((enum confd_vtype)tag) {
            case C_INT8:
                v->type = tag;
                v->val.i8 = (int8_t) ERL_INT_VALUE(vtup);
                break;
            case C_INT16:
                v->type = tag;
                v->val.i16 = (int16_t)  ERL_INT_VALUE(vtup);
                break;
            case C_INT32:
                v->type = tag;
                v->val.i32 = (int32_t)  ERL_INT_VALUE(vtup);
                break;
            case C_INT64:
                v->type = tag;
                switch (ERL_TYPE(vtup)) {
                case ERL_INTEGER:
                    v->val.i64 = (int64_t) ERL_INT_VALUE(vtup);
                    break;
                case ERL_U_INTEGER:
                    v->val.i64 = (int64_t) ERL_INT_UVALUE(vtup);
                    break;
                case ERL_LONGLONG:
                    /* Note: ERL_U_LONGLONG is too big to fit in int64_t,
                    ** hence it is a capi in this case */
                    v->val.i64 = (int64_t)  ERL_LL_VALUE(vtup);
                    break;
                default:
                    goto badterm;
                }
                break;
            case C_UINT8:
                v->type = tag;
                v->val.u8 = (u_int8_t)  ERL_INT_UVALUE(vtup);
                break;
            case C_UINT16:
                v->type = tag;
                v->val.u16 = (u_int16_t) ERL_INT_UVALUE(vtup);
                break;
            case C_UINT32:
                v->type = tag;
                v->val.u32 = (u_int32_t)  ERL_INT_UVALUE(vtup);
                break;
            case C_UINT64:
            case C_BIT64:
                v->type = tag;
                switch (ERL_TYPE(vtup)) {
                case ERL_INTEGER:
                    v->val.u64 = (u_int64_t) ERL_INT_VALUE(vtup);
                    break;
                case ERL_U_INTEGER:
                    v->val.u64 = (u_int64_t) ERL_INT_UVALUE(vtup);
                    break;
                case ERL_LONGLONG:
                    v->val.u64 = (u_int64_t)  ERL_LL_VALUE(vtup);
                    break;
                case ERL_U_LONGLONG:
                    v->val.u64 = (u_int64_t)  ERL_LL_UVALUE(vtup);
                    break;
                default:
                    goto badterm;
                }
                break;
            case C_QNAME: {
                ETERM *prefix = ERL_TUPLE_ELEMENT(vtup, 0);
                ETERM *name   = ERL_TUPLE_ELEMENT(vtup, 1);
                int plen = ERL_ATOM_SIZE(prefix);
                int nlen = ERL_ATOM_SIZE(name);

                v->type = tag;
                if (bin_eq(prefix, "undefined")) {
                    v->val.qname.prefix.ptr  = NULL;
                    v->val.qname.prefix.size = 0;
                } else {
                    v->val.qname.prefix.ptr  =
                        (unsigned char *)ERL_ATOM_PTR(prefix);
                    v->val.qname.prefix.size = plen;
                }
                v->val.qname.name.ptr  = (unsigned char *)ERL_ATOM_PTR(name);
                v->val.qname.name.size = nlen;
                break;
            }
            case C_DATETIME:
                v->type = tag;
                v->val.datetime.year = TINT(vtup,0);
                v->val.datetime.month = TUINT(vtup,1);
                v->val.datetime.day = TUINT(vtup,2);
                v->val.datetime.hour = TUINT(vtup,3);
                v->val.datetime.min = TUINT(vtup,4);
                v->val.datetime.sec = TUINT(vtup,5);
                v->val.datetime.micro = TUINT(vtup,6);
                v->val.datetime.timezone = TZONE(vtup,7);
                v->val.datetime.timezone_minutes = TUINT(vtup,8);
                break;
            case C_DATE:
                v->type = tag;
                v->val.date.year = TINT(vtup,0);
                v->val.date.month = TUINT(vtup,1);
                v->val.date.day = TUINT(vtup,2);
                v->val.date.timezone = TZONE(vtup,3);
                v->val.date.timezone_minutes = TUINT(vtup,4);
                break;
            case C_TIME:
                v->type = tag;
                v->val.time.hour = TUINT(vtup,0);
                v->val.time.min = TUINT(vtup,1);
                v->val.time.sec = TUINT(vtup,2);
                v->val.time.micro = TUINT(vtup,3);
                v->val.time.timezone = TZONE(vtup,4);
                v->val.time.timezone_minutes = TUINT(vtup,5);
                break;
            case C_DURATION:
                v->type = tag;
                v->val.duration.years = TUINT(vtup,0);
                v->val.duration.months = TUINT(vtup,1);
                v->val.duration.days = TUINT(vtup,2);
                v->val.duration.hours = TUINT(vtup,3);
                v->val.duration.mins = TUINT(vtup,4);
                v->val.duration.secs = TUINT(vtup,5);
                v->val.duration.micros = TUINT(vtup,6);
                break;
            case C_ENUM_HASH:
                v->type = tag;
                v->val.enumhash = (int32_t) ERL_INT_VALUE(vtup);
                break;
            case C_BIT32:
                v->type = tag;
                v->val.b32 = (u_int32_t) ERL_INT_VALUE(vtup);
                break;
            case C_OBJECTREF:
                v->type = tag;
                if ((v->val.hkp=confd_malloc(sizeof (confd_hkeypath_t)))==NULL)
                    return NULL;
                if (!populate_keypath(vtup, v->val.hkp))
                    return NULL;
                break;
            case C_OID: {
                unsigned char *ptr = ERL_BIN_PTR(vtup);
                int i;

                v->type = tag;
                if ((v->val.oidp =
                     confd_malloc(sizeof(struct confd_snmp_oid))) == NULL)
                    return NULL;
                v->val.oidp->len = ERL_BIN_SIZE(vtup) / 4;
                for (i = 0; i < v->val.oidp->len; i++)
                    v->val.oidp->oid[i] = get_int32(&ptr[4*i]);
                break;
            }
            case C_BINARY:
            case C_HEXSTR:
            case C_BITBIG:
                v->type = tag;
                v->val.buf.size = ERL_BIN_SIZE(vtup);
                v->val.buf.ptr = ERL_BIN_PTR(vtup);
                break;
            case C_IPV4PREFIX:
                v->type = tag;
                term_to_ip4(&v->val.ipv4prefix.ip, ERL_TUPLE_ELEMENT(vtup, 0));
                v->val.ipv4prefix.len =
                    (u_int8_t) ERL_INT_VALUE(ERL_TUPLE_ELEMENT(vtup, 1));
                break;
            case C_IPV6PREFIX:
                v->type = tag;
                term_to_ip6(&v->val.ipv6prefix.ip6, ERL_TUPLE_ELEMENT(vtup, 0));
                v->val.ipv6prefix.len =
                    (u_int8_t) ERL_INT_VALUE(ERL_TUPLE_ELEMENT(vtup, 1));
                break;
            case C_DECIMAL64: {
                ETERM *val = ERL_TUPLE_ELEMENT(vtup, 0);
                ETERM *fd  = ERL_TUPLE_ELEMENT(vtup, 1);

                v->type = tag;
                switch (ERL_TYPE(val)) {
                case ERL_INTEGER:
                    v->val.d64.value = (int64_t) ERL_INT_VALUE(val);
                    break;
                case ERL_U_INTEGER:
                    v->val.d64.value = (int64_t) ERL_INT_UVALUE(val);
                    break;
                case ERL_LONGLONG:
                    /* Note: ERL_U_LONGLONG is too big to fit in int64_t,
                    ** hence it is a capi in this case */
                    v->val.d64.value = (int64_t)  ERL_LL_VALUE(val);
                    break;
                default:
                    goto badterm;
                }
                v->val.d64.fraction_digits = (u_int8_t) ERL_INT_UVALUE(fd);
                break;
            }
            case C_IDENTITYREF:
                v->type = tag;
                v->val.idref.ns = TUINT(vtup,0);
                v->val.idref.id = TUINT(vtup,1);
                break;
            case C_IPV4_AND_PLEN:
                v->type = tag;
                term_to_ip4(&v->val.ipv4prefix.ip, ERL_TUPLE_ELEMENT(vtup, 0));
                v->val.ipv4prefix.len =
                    (u_int8_t) ERL_INT_VALUE(ERL_TUPLE_ELEMENT(vtup, 1));
                break;
            case C_IPV6_AND_PLEN:
                v->type = tag;
                term_to_ip6(&v->val.ipv6prefix.ip6, ERL_TUPLE_ELEMENT(vtup, 0));
                v->val.ipv6prefix.len =
                    (u_int8_t) ERL_INT_VALUE(ERL_TUPLE_ELEMENT(vtup, 1));
                break;
            case C_DQUAD:
                v->type = tag;
                memcpy(v->val.dquad.quad, ERL_BIN_PTR(vtup), 4);
                break;
            case C_NOEXISTS:
            case C_XMLTAG:
            case C_SYMBOL:
            case C_STR:
            case C_BUF:
            case C_DOUBLE:
            case C_IPV4:
            case C_IPV6:
            case C_BOOL:
            case C_LIST:
            case C_XMLBEGIN:
            case C_XMLEND:
            case C_UNION:
            case C_PTR:
            case C_CDBBEGIN:
            case C_XMLBEGINDEL:
            case C_MAXTYPE:
            case C_DEFAULT:
            case C_XMLMOVEFIRST:
            case C_XMLMOVEAFTER:
                goto badterm;
            }
            if (v->type == 0)
                goto badterm;
            break;
        }
        case 4:  /* implicit IP v4 address */
            v->type = C_IPV4;
            term_to_ip4(&v->val.ip, term);
            break;
        case 8:  /* implicit ip V6 addr */
            v->type = C_IPV6;
            term_to_ip6(&v->val.ip6, term);
            break;
        default:
            goto badterm;
        }
    }
    else if (ERL_IS_FLOAT(term)) {
        v->type = C_DOUBLE;
        v->val.d = ERL_FLOAT_VALUE(term);
    }
    else if (ERL_IS_CONS(term) &&
             IS_INTEGER_OR_UNSIGNED_INTEGER(ERL_CONS_TAIL(term))) {
        v->type = C_XMLTAG;
        v->val.xmltag.ns = ERL_INT_UVALUE(ERL_CONS_HEAD(term));
        v->val.xmltag.tag = ERL_INT_UVALUE(ERL_CONS_TAIL(term));
    }
    else if (ERL_IS_LIST(term)) {
        int i=0;
        const ETERM *hd, *tl;
        v->type = C_LIST;
        v->val.list.ptr = confd_malloc(sizeof(confd_value_t)*erl_length(term));
        if (v->val.list.ptr == NULL) return NULL;
        v->val.list.size = 0;
        tl = term;
        while (! ERL_IS_EMPTY_LIST(tl)) {
            /* prepare for next loop */
            hd = ERL_CONS_HEAD(tl);
            tl = ERL_CONS_TAIL(tl);
            if (eterm_to_val(hd, &v->val.list.ptr[i++]) == NULL)
                return NULL;
            v->val.list.size++;
        }
    }
    else {
        goto badterm;
    }
    return v;

badterm:
    if (confd_debug_level > 0 && confd_debug_stream) {
        fprintf(confd_debug_stream, "BADTERM: ");
        erl_print_term(confd_debug_stream, term);
        fprintf(confd_debug_stream, "\n");
    }
    confd_internal_error("%s(%d): Internal error, Bad term value",
                         __FILE__, __LINE__);
    return NULL;
}

/* Take a value term {TypeEnum, Value} and fill */
/* in a confd_value_t pointer                   */
/* Return NULL on failure                       */
/* Upon failure, the changes to eindex and v are undefined.  eindex
 * will point to undefined location in ebuf and v might be partially
 * filled. */
int eterm_to_val_ei(const char *ebuf,
                    int *eindex,
                    confd_value_t *v)
{
    int orig_index = *eindex;
    int etype;
    int elen;

    BADTERM_TEST(ebuf == NULL);
    BADTERM_TEST(ei_get_type(ebuf, eindex, &etype, &elen) != 0);

    if (IS_INTEGER_EXT(etype)) {
        long i;

        BADTERM_TEST(ei_decode_long(ebuf, eindex, &i)
                   || i > INT32_MAX
                   || i < INT32_MIN);
        v->type = C_INT32;
        v->val.i32 = (int32_t)i;
    }
    else if (etype == ERL_BINARY_EXT) {
        char *bin = NULL;
        long sz = 0;

        if ((bin = confd_malloc(elen)) == NULL) return CONFD_ERR;
        BADTERM_FREE_TEST(bin, ei_decode_binary(ebuf, eindex, bin, &sz) != 0);
        v->type = C_BUF;
        v->val.buf.size = sz;
        v->val.buf.ptr = (unsigned char *)bin;
    }
    else if (etype == ERL_ATOM_EXT) {
        char *ptr;

        if ((ptr = confd_malloc(elen+1)) == NULL) return CONFD_ERR;
        BADTERM_FREE_TEST(ptr, ei_decode_atom(ebuf, eindex, ptr) != 0);
        if (elen == 4 && strncmp("true", ptr, elen) == 0) {
            v->type = C_BOOL;
            v->val.boolean = 1;
            free(ptr);
        }
        else if (elen == 5 && strncmp("false", ptr, elen) == 0) {
            v->type = C_BOOL;
            v->val.boolean = 0;
            free(ptr);
        }
        else if (elen == 9 && strncmp("not_found", ptr, elen) == 0) {
            v->type = C_NOEXISTS;
            free(ptr);
        }
        else if (elen == 7 && strncmp("default", ptr, elen) == 0) {
            v->type = C_DEFAULT;
            free(ptr);
        }
        else {
            v->type = C_BUF;
            v->val.buf.size = elen;
            v->val.buf.ptr = (unsigned char *)ptr;
        }
    }
    else if (etype == ERL_SMALL_TUPLE_EXT || etype == ERL_LARGE_TUPLE_EXT) {
        int arity;

        BADTERM_TEST(ei_decode_tuple_header(ebuf, eindex, &arity) != 0);

        switch (arity) {
        case 2:  {
            long tag;

            BADTERM_TEST(ei_decode_long(ebuf, eindex, &tag) != 0);
            BADTERM_TEST(ei_get_type(ebuf, eindex, &etype, &elen) != 0);

            v->type = 0;
            switch ((enum confd_vtype)tag) {
            case C_INT8: {
                long l;
                BADTERM_TEST(ei_decode_long(ebuf, eindex, &l) != 0);
                BADTERM_TEST(l < INT8_MIN || l > INT8_MAX);
                v->type = tag;
                v->val.i8 = (int8_t) l;
                break;
            }
            case C_INT16: {
                long l;
                BADTERM_TEST(ei_decode_long(ebuf, eindex, &l) != 0);
                BADTERM_TEST(l < INT16_MIN || l > INT16_MAX);
                v->type = tag;
                v->val.i16 = (int16_t) l;
                break;
            }
            case C_INT32: {
                long l;
                BADTERM_TEST(ei_decode_long(ebuf, eindex, &l) != 0);
                BADTERM_TEST(l < INT32_MIN || l > INT32_MAX);
                v->type = tag;
                v->val.i32 = (int32_t) l;
                break;
            }
            case C_INT64: {
                long long ll;
                BADTERM_TEST(ei_decode_longlong(ebuf, eindex, &ll) != 0);
                /* No additional check needed, as longlong is 64bit */
                v->type = tag;
                v->val.i64 = (int64_t) ll;
                break;
            }
            case C_UINT8: {
                unsigned long ul;
                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0);
                BADTERM_TEST(ul > UINT8_MAX);
                v->type = tag;
                v->val.u8 = (u_int8_t) ul;
                break;
            }
            case C_UINT16: {
                unsigned long ul;
                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0);
                BADTERM_TEST(ul > UINT16_MAX);
                v->type = tag;
                v->val.u16 = (u_int16_t) ul;
                break;
            }
            case C_UINT32: {
                unsigned long ul;
                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0);
                BADTERM_TEST(ul > UINT32_MAX);
                v->type = tag;
                v->val.u32 = (u_int32_t) ul;
                break;
            }
            case C_UINT64:
            case C_BIT64: {
                unsigned long long ull;
                BADTERM_TEST(ei_decode_ulonglong(ebuf, eindex, &ull) != 0);
                /* No additional check needed as ulonglong is 64bit */
                v->type = tag;
                v->val.u64 = (u_int64_t) ull;
                break;
            }
            case C_QNAME: {
                int arity;
                char *prefix;
                char *name;
                int plen;
                int nlen;
                BADTERM_TEST(ei_decode_tuple_header(ebuf, eindex, &arity) != 0);
                BADTERM_TEST(arity != 2);
                BADTERM_TEST(ei_get_type(ebuf, eindex, &etype, &plen) != 0);
                if ((prefix = confd_malloc(plen+1)) == NULL)
                    return CONFD_ERR;
                BADTERM_FREE_TEST(prefix,
                                ei_decode_atom(ebuf, eindex, prefix) != 0);
                BADTERM_TEST(ei_get_type(ebuf, eindex, &etype, &nlen) != 0);
                if ((name = confd_malloc(nlen+1)) == NULL) return CONFD_ERR;
                BADTERM_FREE_TEST(name,
                                  ei_decode_atom(ebuf, eindex, name) != 0);

                v->type = tag;
                if (strncmp("undefined", prefix, 9) == 0) {
                    v->val.qname.prefix.ptr  = NULL;
                    v->val.qname.prefix.size = 0;
                }
                else {
                    v->val.qname.prefix.ptr  = (unsigned char *)prefix;
                    v->val.qname.prefix.size = plen;
                }
                v->val.qname.name.ptr  = (unsigned char *)name;
                v->val.qname.name.size = nlen;
                break;
            }
            case C_DATETIME: {
                int arity;
                long l;
                unsigned long ul;
                BADTERM_TEST(ei_decode_tuple_header(ebuf, eindex, &arity) != 0);
                BADTERM_TEST(arity != 9);
                v->type = tag;

                BADTERM_TEST(ei_decode_long(ebuf, eindex, &l) != 0
                           || l < INT16_MIN
                           || l > INT16_MAX);
                v->val.datetime.year = l;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT8_MAX);
                v->val.datetime.month = ul;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT8_MAX);
                v->val.datetime.day = ul;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT8_MAX);
                v->val.datetime.hour = ul;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT8_MAX);
                v->val.datetime.min = ul;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT8_MAX);
                v->val.datetime.sec = ul;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT32_MAX);
                v->val.datetime.micro = ul;

                if (ei_decode_long(ebuf, eindex, &l) == 0) {
                    BADTERM_TEST(l < INT8_MIN || l > INT8_MAX);
                    v->val.datetime.timezone = l;
                }
                else {
                    BADTERM_TEST(ei_decode_list_header(ebuf, eindex,
                                                     &arity) != 0);
                    BADTERM_TEST(arity != 0);
                    v->val.datetime.timezone = CONFD_TIMEZONE_UNDEF;
                }

                BADTERM_TEST(ei_decode_long(ebuf, eindex, &l) != 0
                           || l < INT8_MIN
                           || l > INT8_MAX);
                v->val.datetime.timezone_minutes = l;
                break;
            }
            case C_DATE: {
                int arity;
                long l;
                unsigned long ul;
                BADTERM_TEST(ei_decode_tuple_header(ebuf, eindex, &arity) != 0);
                BADTERM_TEST(arity != 5);
                v->type = tag;

                BADTERM_TEST(ei_decode_long(ebuf, eindex, &l) != 0
                           || l < INT16_MIN
                           || l > INT16_MAX);
                v->val.date.year = l;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT8_MAX);
                v->val.date.month = ul;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT8_MAX);
                v->val.date.day = ul;

                if (ei_decode_long(ebuf, eindex, &l) == 0) {
                    BADTERM_TEST(l < INT8_MIN || l > INT8_MAX);
                    v->val.date.timezone = l;
                }
                else {
                    BADTERM_TEST(ei_decode_list_header(ebuf, eindex,
                                                     &arity) != 0);
                    BADTERM_TEST(arity != 0);
                    v->val.date.timezone = CONFD_TIMEZONE_UNDEF;
                }

                BADTERM_TEST(ei_decode_long(ebuf, eindex, &l) != 0
                           || l < INT8_MIN
                           || l > INT8_MAX);
                v->val.date.timezone_minutes = l;
                break;
            }
            case C_TIME: {
                int arity;
                long l;
                unsigned long ul;
                BADTERM_TEST(ei_decode_tuple_header(ebuf, eindex, &arity) != 0);
                BADTERM_TEST(arity != 6);
                v->type = tag;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT8_MAX);
                v->val.time.hour = ul;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT8_MAX);
                v->val.time.min = ul;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT8_MAX);
                v->val.time.sec = ul;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT32_MAX);
                v->val.time.micro = ul;

                if (ei_decode_long(ebuf, eindex, &l) == 0) {
                    /* FIXME Should we enforce inclusive bounds of
                     * -14,14]? */
                    BADTERM_TEST(l < INT8_MIN || l > INT8_MAX);
                    v->val.time.timezone = l;
                } else {
                    BADTERM_TEST(ei_decode_list_header(ebuf, eindex,
                                                     &arity) != 0);
                    BADTERM_TEST(arity != 0);
                    v->val.time.timezone = CONFD_TIMEZONE_UNDEF;
                }

                /* FIXME I would argue that the old code is wrong
                 * with respect to the documentation, since we allow
                 * and have semantics for negative timezone_minutes. */
                BADTERM_TEST(ei_decode_long(ebuf, eindex, &l) != 0
                           /* FIXME Should we enforce stricter bounds
                            * since we are dealing with minutes? */
                           || l < INT8_MIN
                           || l > INT8_MAX);
                v->val.time.timezone_minutes = l;
                break;
            }
            case C_DURATION: {
                int arity;
                unsigned long ul;
                BADTERM_TEST(ei_decode_tuple_header(ebuf, eindex, &arity) != 0);
                BADTERM_TEST(arity != 7);
                v->type = tag;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT32_MAX);
                v->val.duration.years = ul;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT32_MAX);
                v->val.duration.months = ul;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT32_MAX);
                v->val.duration.days = ul;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT32_MAX);
                v->val.duration.hours = ul;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT32_MAX);
                v->val.duration.mins = ul;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT32_MAX);
                v->val.duration.secs = ul;

                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0
                           || ul > UINT32_MAX);
                v->val.duration.micros = ul;
                break;
            }
            case C_ENUM_HASH: {
                unsigned long l;
                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &l) != 0);
                BADTERM_TEST(l > UINT32_MAX);
                v->type = tag;
                v->val.enumhash = (u_int32_t) l;
                break;
            }
            case C_BIT32: {
                unsigned long ul;
                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0);
                BADTERM_TEST(ul > UINT32_MAX);
                v->type = tag;
                v->val.b32 = (u_int32_t) ul;
                break;
            }
            case C_OBJECTREF: {
                confd_hkeypath_t *hkp;
                if ((hkp = (confd_hkeypath_t *)
                     confd_malloc(sizeof (confd_hkeypath_t))) == NULL)
                    return CONFD_ERR;
                BADTERM_FREE_TEST(hkp,
                                populate_keypath_ei(ebuf, eindex, hkp)
                                != CONFD_OK);
                v->type = tag;
                v->val.hkp = hkp;
                break;
            }
            case C_OID: {
                char *bin = NULL;
                long sz = 0;
                int i;
                if ((bin = confd_malloc(elen)) == NULL) return CONFD_ERR;
                BADTERM_FREE_TEST(bin,
                                ei_decode_binary(ebuf, eindex, bin, &sz) != 0);
                v->type = tag;
                if ((v->val.oidp = (struct confd_snmp_oid *)
                     confd_malloc(sizeof(struct confd_snmp_oid))) == NULL)
                    return CONFD_ERR;
                v->val.oidp->len = sz / 4;
                for (i = 0; i < v->val.oidp->len; i++) {
                    v->val.oidp->oid[i] = get_int32(&bin[4*i]);
                }
                break;
            }
            case C_BINARY:
            case C_HEXSTR:
            case C_BITBIG: {
                char *bin = NULL;
                long sz = 0;
                BADTERM_TEST(etype != ERL_BINARY_EXT);
                if ((bin = confd_malloc(elen)) == NULL) return CONFD_ERR;
                BADTERM_FREE_TEST(bin,
                                ei_decode_binary(ebuf, eindex, bin, &sz) != 0);
                /* FIXME Should we be really picky here and fail if we
                 * have a C_BITBIG that is 64 bits or less?  */
                v->type = tag;
                v->val.buf.size = sz;
                v->val.buf.ptr = (unsigned char *)bin;
                break;
            }
            case C_IPV4PREFIX: {
                int arity;
                long l;
                BADTERM_TEST(ei_decode_tuple_header(ebuf, eindex, &arity) != 0);
                BADTERM_TEST(arity != 2);
                v->type = tag;
                BADTERM_TEST(term_to_ip4_ei(&v->val.ipv4prefix.ip,
                                          ebuf, eindex) != CONFD_OK);
                BADTERM_TEST(ei_decode_long(ebuf, eindex, &l) != 0);
                v->val.ipv4prefix.len = (u_int8_t) l;
                break;
            }
            case C_IPV6PREFIX: {
                int arity;
                long l;
                BADTERM_TEST(ei_decode_tuple_header(ebuf, eindex, &arity) != 0);
                BADTERM_TEST(arity != 2);

                v->type = tag;
                BADTERM_TEST(term_to_ip6_ei(&v->val.ipv6prefix.ip6,
                                          ebuf, eindex) != CONFD_OK);
                BADTERM_TEST(ei_decode_long(ebuf, eindex, &l) != 0);
                v->val.ipv6prefix.len = (u_int8_t) l;
                break;
            }
            case C_DECIMAL64: {
                int arity;
                unsigned long ul;
                long long ll;
                BADTERM_TEST(ei_decode_tuple_header(ebuf, eindex, &arity) != 0);
                BADTERM_TEST(arity != 2);
                v->type = tag;
                BADTERM_TEST(ei_decode_longlong(ebuf, eindex, &ll) != 0);
                v->val.d64.value = (int64_t) ll;
                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0);
                BADTERM_TEST(ul > 18);
                v->val.d64.fraction_digits = (u_int8_t) ul;
                break;
            }
            case C_IDENTITYREF: {
                int arity;
                unsigned long ns;
                unsigned long id;
                BADTERM_TEST(ei_decode_tuple_header(ebuf, eindex, &arity) != 0);
                BADTERM_TEST(arity != 2);
                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &ns) != 0);
                BADTERM_TEST(ns > UINT32_MAX);
                BADTERM_TEST(ei_decode_ulong(ebuf, eindex, &id) != 0);
                BADTERM_TEST(id > UINT32_MAX);
                v->type = tag;
                v->val.idref.ns = ns;
                v->val.idref.id = id;
                break;
            }
            case C_IPV4_AND_PLEN: {
                /* NOTE Same decoding as C_IPV4PREFIX */
                int arity;
                long l;
                BADTERM_TEST(ei_decode_tuple_header(ebuf, eindex, &arity) != 0);
                BADTERM_TEST(arity != 2);
                v->type = tag;
                BADTERM_TEST(term_to_ip4_ei(&v->val.ipv4prefix.ip,
                                          ebuf, eindex) != CONFD_OK);
                BADTERM_TEST(ei_decode_long(ebuf, eindex, &l) != 0);
                v->val.ipv4prefix.len = (u_int8_t) l;
                break;
            }
            case C_IPV6_AND_PLEN: {
                /* NOTE Same decoding as C_IPV6PREFIX */
                int arity;
                long l;
                BADTERM_TEST(ei_decode_tuple_header(ebuf, eindex, &arity) != 0);
                BADTERM_TEST(arity != 2);
                v->type = tag;
                BADTERM_TEST(term_to_ip6_ei(&v->val.ipv6prefix.ip6,
                                          ebuf, eindex) != CONFD_OK);
                BADTERM_TEST(ei_decode_long(ebuf, eindex, &l) != 0);
                v->val.ipv6prefix.len = (u_int8_t) l;
                break;
            }
            case C_DQUAD: {
                char *bin = NULL;
                long sz = 0;
                BADTERM_TEST(elen != 4);
                if ((bin = confd_malloc(elen)) == NULL) return CONFD_ERR;
                BADTERM_FREE_TEST(bin,
                                ei_decode_binary(ebuf, eindex, bin, &sz) != 0);
                v->type = tag;
                memcpy(v->val.dquad.quad, bin, 4);
                break;
            }
                /* FIXME None if the below are implemented in the
                 * original eterm_to_val() -- are they not needed? */
            case C_NOEXISTS:
            case C_XMLTAG:
            case C_SYMBOL:
            case C_STR:
            case C_BUF:
                BADTERM_RET();
                break;
            case C_DOUBLE: {
                /* FIXME This maybe not needed.  See above. */
                double d;
                BADTERM_TEST(ei_decode_double(ebuf, eindex, &d) != 0);
                v->type = tag;
                v->val.d = d;
                break;
            }
            case C_IPV4:
            case C_IPV6:
                BADTERM_RET();
                break;
            case C_BOOL: {
                /* FIXME This maybe not needed.  See above. */
                int b;
                BADTERM_TEST(ei_decode_boolean(ebuf, eindex, &b) != 0);
                v->type = tag;
                v->val.boolean = b;
                break;
            }
            case C_LIST:
            case C_XMLBEGIN:
            case C_XMLEND:
            case C_UNION:
            case C_PTR:
            case C_CDBBEGIN:
            case C_XMLBEGINDEL:
            case C_MAXTYPE:
            case C_DEFAULT:
            case C_XMLMOVEFIRST:
            case C_XMLMOVEAFTER:
                BADTERM_RET();
            }
            BADTERM_TEST(v->type == 0);
            break;
        }
        case 4:  /* implicit IP v4 address */
            /* FIXME Is these still needed? */
            v->type = C_IPV4;
            BADTERM_TEST(term_to_ip4_ei(&v->val.ip, ebuf, eindex) != CONFD_OK);
            break;
        case 8:  /* implicit ip V6 addr */
            /* FIXME Is these still needed? */
            v->type = C_IPV6;
            BADTERM_TEST(term_to_ip6_ei(&v->val.ip6, ebuf, eindex) != CONFD_OK);
            break;
        default:
            BADTERM_RET();
        }
    }
    else if (etype == ERL_FLOAT_EXT) {
        v->type = C_DOUBLE;
        BADTERM_TEST(ei_decode_double(ebuf, eindex, &v->val.d) != 0);
    }
    else if (etype == ERL_NIL_EXT) {
        v->type = C_LIST;
        v->val.list.size = 0;
        v->val.list.ptr = NULL; /* BUGBUG: Correct? */
    }
    else if (etype == ERL_LIST_EXT) {
        int arity;
        int i;
        int list_top;
        unsigned long ul1;
        unsigned long ul2;
        BADTERM_TEST(ei_decode_list_header(ebuf, eindex, &arity) != 0);
        list_top = *eindex;
        /* Recognise a single cons cell, with two ints, i.e., an xmltag
           with a hashed namespace and value */
        if ((arity == 1)
            && (ei_decode_ulong(ebuf, eindex, &ul1) == 0)
            && (ei_decode_ulong(ebuf, eindex, &ul2) == 0)) {
            v->type = C_XMLTAG;
            v->val.xmltag.ns = ul1;
            v->val.xmltag.tag = ul2;
        }
        else {
            *eindex = list_top;
            if ((v->val.list.ptr = (struct confd_value *)
                 confd_malloc(sizeof(confd_value_t)*arity)) == NULL)
                return CONFD_ERR;
            v->type = C_LIST;
            v->val.list.size = 0;
            for (i=0; i < arity; i++) {
                BADTERM_TEST(eterm_to_val_ei(ebuf, eindex,
                                           &v->val.list.ptr[i]) != CONFD_OK);
                v->val.list.size++;
            }
        }
    }
    else {
        BADTERM_RET();
    }
    return CONFD_OK;
}

/* return total # of elems or CONFD_ERR on malloc error */
int etermlist_to_vals(ETERM *list, confd_value_t *vp, int n)
{
    int i;

    for (i = 0; !ERL_IS_NIL(list); i++) {
        if (!ERL_IS_CONS(list))
            return confd_internal_error(
                "%s(%d): Internal error, bad value list\n",
                __FILE__, __LINE__);
        if (i < n) {
            if (eterm_to_val(ERL_CONS_HEAD(list), &vp[i]) == NULL)
                return CONFD_ERR;
        }
        list = ERL_CONS_TAIL(list);
    }
    return i;
}


confd_tag_value_t *eterm_to_tag_val(const ETERM *term, confd_tag_value_t *tv,
                                    int allow_unqualified)
{
    ETERM *tag = ERL_TUPLE_ELEMENT(term, 0);
    ETERM *value = ERL_TUPLE_ELEMENT(term, 1);

    if (ERL_IS_LIST(tag)) {
        tv->tag.ns = ERL_INT_UVALUE(ERL_CONS_HEAD(tag));
        tv->tag.tag = ERL_INT_UVALUE(ERL_CONS_TAIL(tag));
    } else if (allow_unqualified && IS_INTEGER_OR_UNSIGNED_INTEGER(tag)) {
        tv->tag.ns = 0;
        tv->tag.tag = ERL_INT_UVALUE(tag);
    } else {
        confd_internal_error("%s(%d): Internal error, bad tag element\n",
                             __FILE__, __LINE__);
        return NULL;
    }
    if (ERL_IS_ATOM(value)) {
        if (bin_eq(value, "start")) {
            tv->v.type = C_XMLBEGIN;
            tv->v.val.xmltag = tv->tag;
        } else if (bin_eq(value, "delete")) {
            tv->v.type = C_XMLBEGINDEL;
            tv->v.val.xmltag = tv->tag;
        } else if (bin_eq(value, "stop")) {
            tv->v.type = C_XMLEND;
            tv->v.val.xmltag = tv->tag;
        } else if (bin_eq(value, "leaf")) {
            tv->v.type = C_XMLTAG;
            tv->v.val.xmltag = tv->tag;
        } else if (bin_eq(value, "move_first")) {
          tv->v.type = C_XMLMOVEFIRST;
          tv->v.val.xmltag = tv->tag;
        } else if (bin_eq(value, "move_after")) {
          tv->v.type = C_XMLMOVEAFTER;
          tv->v.val.xmltag = tv->tag;
        } else if (eterm_to_val(value, &tv->v) == NULL) {
            return NULL;
        }
    } else if (eterm_to_val(value, &tv->v) == NULL) {
        return NULL;
    }
    return tv;
}

/* return total # of elems or CONFD_ERR on malloc error */
int etermlist_to_tag_vals(ETERM *list, confd_tag_value_t *tvp, int n)
{
    int i;

    for (i = 0; !ERL_IS_NIL(list); i++) {
        if (!ERL_IS_CONS(list)) {
            confd_internal_error(
                "%s(%d): Internal error, bad tag value list\n",
                __FILE__, __LINE__);
            return -1;
        }
        if (i < n) {
            if (eterm_to_tag_val(ERL_CONS_HEAD(list), &tvp[i], 0) == NULL)
                return CONFD_ERR;
        }
        list = ERL_CONS_TAIL(list);
    }
    return i;
}

int eterm_to_tag_val_ei(const char *ebuf, int *eindex,
                        confd_tag_value_t *tv,
                        int allow_unqualified,
                        confd_tag_value_t ** val)
{
    int earity;
    int etype;
    int elen;
    unsigned long ul;
    char *bin = NULL;
    int ret = CONFD_OK;

    BADTERM_IF(ei_decode_tuple_header(ebuf, eindex, &earity) != 0);
    BADTERM_IF(earity != 2);

    /* 0 - tag */
    BADTERM_IF(ei_get_type(ebuf, eindex, &etype, &elen) != 0);
    if (etype == ERL_LIST_EXT) {
        BADTERM_IF(elen != 2);
        BADTERM_IF(ei_decode_ulong(ebuf, eindex, &ul) != 0);
        tv->tag.ns = (unsigned int)ul;
        BADTERM_IF(ei_decode_ulong(ebuf, eindex, &ul) != 0);
        tv->tag.tag = (unsigned int)ul;
    } else if (allow_unqualified && ei_decode_ulong(ebuf, eindex, &ul) == 0) {
        tv->tag.ns = 0;
        tv->tag.tag = (unsigned int)ul;
    } else {
        return confd_internal_error("Internal error, bad tag element\n");
    }

    /* 1 - value */
    BADTERM_IF(ei_get_type(ebuf, eindex, &etype, &elen) != 0);
    if (etype == ERL_ATOM_EXT) {
        long sz;
        int pindex = *eindex;

        BADTERM_IF(decode_atom_ei(ebuf, eindex, &bin, &sz) != CONFD_OK);
        if (strncmp("start", bin, 5) == 0) {
            tv->v.type = C_XMLBEGIN;
            tv->v.val.xmltag = tv->tag;
        } else if (strncmp("delete", bin, 6) == 0) {
            tv->v.type = C_XMLBEGINDEL;
            tv->v.val.xmltag = tv->tag;
        } else if (strncmp("stop", bin, 4) == 0) {
            tv->v.type = C_XMLEND;
            tv->v.val.xmltag = tv->tag;
        } else if (strncmp("leaf", bin, 4) == 0) {
            tv->v.type = C_XMLTAG;
            tv->v.val.xmltag = tv->tag;
        } else if (strncmp("move_first", bin, 10) == 0) {
            tv->v.type = C_XMLMOVEFIRST;
            tv->v.val.xmltag = tv->tag;
        } else if (strncmp("move_after", bin, 10) == 0) {
            tv->v.type = C_XMLMOVEAFTER;
            tv->v.val.xmltag = tv->tag;
        } else if (eterm_to_val_ei(ebuf, &pindex, &tv->v) != CONFD_OK) {
            ret = CONFD_ERR;
            SAFE_RET();
        }
    } else if (eterm_to_val_ei(ebuf, eindex, &tv->v) != CONFD_OK) {
        ret = CONFD_ERR;
        SAFE_RET();
    }
    *val = tv;
    ret = CONFD_OK;

saferet:
    free(bin);
    return ret;
}

/* return total # of elems or CONFD_ERR on malloc error */
int etermlist_to_tag_vals_ei(const char *ebuf, int *eindex,
                             confd_tag_value_t *tvp,
                             int nexpected,
                             int *nvals)
{
    int i;
    int len;
    confd_tag_value_t **val = NULL;
    int ret = CONFD_OK;

    BADTERM_IF(ei_decode_list_header(ebuf, eindex, &len) != 0);
    for (i = 0; i < len; i++) {
        if (i < nexpected) {
            ret = eterm_to_tag_val_ei(ebuf, eindex, &tvp[i], 0, val);
            if (ret != CONFD_OK) return ret;
        }
    }
    *nvals = i;
    return ret;
}

/* Use this function to free "internal" allocation in value
   from  eterm_to_val(), i.e. w/o any dup function applied */
/* (C_BUF, C_BINARY, C_HEXSTR, C_BITBIG, and C_QNAME
   point into the Erlang term) */
void confd_free_eterm_val(confd_value_t *v)
{
    switch (v->type) {
    case C_LIST: {
        int i;
        /* We can have a list of C_OID... */
        for (i = 0; i < v->val.list.size; i++)
            confd_free_eterm_val(&v->val.list.ptr[i]);
        free(v->val.list.ptr);
        break;
    }
    case C_OBJECTREF:
        /* We can have C_OID keys... */
        confd_free_eterm_keypath(v->val.hkp);
        free(v->val.hkp);
        break;
    case C_OID:
        free(v->val.oidp);
        break;
    default:
        break;
    }
}

/* As above for keypaths - C_OID keys need it */
void confd_free_eterm_keypath(confd_hkeypath_t *kp)
{
    int i, j;

    for (i = 0; i < kp->len; i++) {
        if (kp->v[i][0].type != C_XMLTAG) {
            for (j = 0; kp->v[i][j].type != C_NOEXISTS; j++)
                confd_free_eterm_val(&kp->v[i][j]);
        }
    }
}


/* Take [Tag1, {K}, Tag2, Tag3, {K2,3} ..] and populate args
 * TagN = uint32
 */
int populate_keypath(const ETERM *kp, confd_hkeypath_t *args)
{
    const ETERM *hd, *tl;
    int i, j, last_marker;

    last_marker = 0;
    j = 0;
    tl = kp;
    while (! ERL_IS_EMPTY_LIST(tl)) {
        int sz;
        i = 0;
        /* prepare for next loop */
        hd = ERL_CONS_HEAD(tl);
        tl = ERL_CONS_TAIL(tl);

        if (ERL_IS_LIST(hd)) {
            /* we have a namespace marked xmltag        */
            /* patch all previous C_XMLTAG items        */

            ETERM *ns, *tag;
            int n;
            ns = ERL_CONS_HEAD(hd);
            tag = ERL_CONS_TAIL(hd);
            args->v[j][0].type = C_XMLTAG;
            args->v[j][0].val.xmltag.tag = ERL_INT_UVALUE(tag);
            args->v[j][1].type = C_NOEXISTS;
            for (n=last_marker; n < (j+1); n++) {
                if (args->v[n][0].type == C_XMLTAG) {
                    args->v[n][0].val.xmltag.ns = ERL_INT_UVALUE(ns);
                }
            }
            last_marker = ++j;
        }
        else if (IS_INTEGER_OR_UNSIGNED_INTEGER(hd)) {
            /* this is an xmltag, we don't yet know the */
            /* namespace, it will come later */
            args->v[j][0].type = C_XMLTAG;
            args->v[j][0].val.xmltag.tag = ERL_INT_UVALUE(hd);
            args->v[j][1].type = C_NOEXISTS;
            j++;
        }
        else if (ERL_IS_TUPLE(hd)) {
            /* this is a key element */

            sz = ERL_TUPLE_SIZE(hd);
            for (i=0; i<sz; i++) {
                confd_value_t *vptr;
                if (i == MAXKEYLEN) {
                    confd_internal_error(
                        "%s(%d): Max num keys (%d) of config tree overrun\n",
                        __FILE__, __LINE__, MAXKEYLEN);
                    return 0;
                }
                vptr = &args->v[j][i];
                if (eterm_to_val(ERL_TUPLE_ELEMENT(hd,i), vptr) == NULL) {
                    return 0;
                }
            }
            args->v[j][i].type = C_NOEXISTS;  /* end marker */
            j++;
        }
        else {
            confd_internal_error("Bad keypath value\n");
            return 0;
        }
        if (j == MAXDEPTH) {
            confd_internal_error(
                "%s(%d): Maxdepth (%d) of config tree overrun\n",
                __FILE__, __LINE__, MAXDEPTH);
            return 0;
        }
    }
    args->v[j][0].type = C_NOEXISTS;
    args->len  = j;
    return 1;
}

/* Take [Tag1, {K}, Tag2, Tag3, {K2,3} ..] and populate args
 * TagN = uint32
 */
int populate_keypath_ei(const char *ebuf, int *eindex, confd_hkeypath_t *args)
{
    int arity;
    int etype;
    int elen;
    int loop;
    int orig_index = *eindex;

    int i;
    int j;
    int last_marker;

    BADHKP_TEST(ei_decode_list_header(ebuf, eindex, &arity) != 0);

    last_marker = 0;
    j = 0;
    for (loop=0; loop < arity; loop++) {
        BADHKP_TEST(ei_get_type(ebuf, eindex, &etype, &elen) != 0);
        switch (etype) {
        case ERL_LIST_EXT: {
            /* we have a namespace marked xmltag        */
            /* patch all previous C_XMLTAG items        */
            int xml_arity;
            unsigned long ns;
            unsigned long tag;
            int n;
            BADHKP_TEST(ei_decode_list_header(ebuf, eindex, &xml_arity) != 0);
            BADHKP_TEST(xml_arity != 1);
            BADHKP_TEST(ei_decode_ulong(ebuf, eindex, &ns) != 0);
            BADHKP_TEST(ei_decode_ulong(ebuf, eindex, &tag) != 0);
            args->v[j][0].type = C_XMLTAG;
            args->v[j][0].val.xmltag.tag = tag;
            args->v[j][1].type = C_NOEXISTS;
            for (n=last_marker; n < (j+1); n++) {
                if (args->v[n][0].type == C_XMLTAG) {
                    args->v[n][0].val.xmltag.ns = ns;
                }
            }
            last_marker = ++j;
            break;
        }
        case ERL_SMALL_INTEGER_EXT:
        case ERL_INTEGER_EXT:
        case ERL_SMALL_BIG_EXT:
        case ERL_LARGE_BIG_EXT: {
            /* this is an xmltag, we don't yet know the */
            /* namespace, it will come later            */
            unsigned long ul;
            BADHKP_TEST(ei_decode_ulong(ebuf, eindex, &ul) != 0);
            args->v[j][0].type = C_XMLTAG;
            args->v[j][0].val.xmltag.tag = ul;
            args->v[j][1].type = C_NOEXISTS;
            j++;
            break;
        }
        case ERL_SMALL_TUPLE_EXT:
        case ERL_LARGE_TUPLE_EXT: {
            /* this is a key element */

            BADHKP_TEST(ei_decode_tuple_header(ebuf, eindex, &arity) != 0);
            for (i=0; i < arity; i++) {
                confd_value_t *vptr;
                if (i == MAXKEYLEN) {
                    confd_internal_error(
                        "%s(%d): Max num keys (%d) of config tree overrun",
                        __FILE__, __LINE__, MAXKEYLEN);
                    return CONFD_ERR;
                }
                vptr = &args->v[j][i];
                if (eterm_to_val_ei(ebuf, eindex, vptr) != CONFD_OK) {
                    return CONFD_ERR;
                }
            }
            args->v[j][i].type = C_NOEXISTS;  /* end marker */
            j++;
            break;
        }
        default:
            confd_internal_error("%s(%d): Bad keypath value\n",
                                 __FILE__, __LINE__);
        }
        if (j == MAXDEPTH) {
            confd_internal_error("%s(%d): Maxdepth (%d) of config tree overrun",
                                 __FILE__, __LINE__, MAXDEPTH);
            return CONFD_ERR;
        }
    }
    /* Decode "last" element only if list was non empty, and if so
       we now expect an empty list. */
    if (arity > 0) {
        BADHKP_TEST(ei_decode_list_header(ebuf, eindex, &arity) != 0);
        BADHKP_TEST(arity != 0);
    }
    args->v[j][0].type = C_NOEXISTS;
    args->len  = j;
    return CONFD_OK;
}

void v_confd_trace(int syslogprio, enum confd_debug_level level,
                   const char  *fmt, va_list args)
{
    char buf[BUFSIZ];
    char *bufptr = &buf[0];
    int buflen = sizeof(buf);
    char *s, *e;
    char *mbuf = NULL;
    int len, elen, printlen, mlen;
    va_list args2;

    if (level <= confd_debug_level) {
        s = "TRACE "; e = "";
        if (level == CONFD_DEBUG) {
            s = "DEBUG ";
            e = "\n";
        }
        len = strlen(s);
        elen = strlen(e);

        va_copy(args2, args);
        snprintf(bufptr, buflen, "%s ", s);
        printlen = vsnprintf(&bufptr[len], buflen - len, fmt, args);
        if (printlen + elen >= buflen - len) {
            mlen = len + printlen + elen + 1;
            if ((mbuf = malloc(mlen)) != NULL) { /* otherwise truncate */
                bufptr = mbuf;
                buflen = mlen;
                snprintf(bufptr, buflen, "%s ",s);
                vsnprintf(&bufptr[len], buflen - len, fmt, args2);
            }
        }
        len = strlen(bufptr);
        snprintf(&bufptr[len], buflen - len, "%s", e);
        confd_printf(syslogprio, "%s", bufptr);
        if (mbuf != NULL)
            free(mbuf);
    }
}

extern PTHREAD_KEY_T confd_syslog_buf_key;

void confd_vprintf(int syslogprio, const char  *fmt, va_list args)
{
    va_list args2;

    if(confd_debug_stream != NULL)  {
        va_copy(args2, args);
        vfprintf(confd_debug_stream, fmt, args2);
    }
    if (confd_lib_use_syslog != 0) {
        char *sbuf;
        int sofar;
        int written;

        if ((sbuf = (char *)PTHREAD_GETSPECIFIC(confd_syslog_buf_key))
            == NULL) {
            sbuf = malloc(1024);
            sbuf[0] = 0;
            PTHREAD_SETSPECIFIC(confd_syslog_buf_key, (void*) sbuf);
        }
        sofar = strlen(sbuf);
        va_copy(args2, args);
        written = vsnprintf(&sbuf[sofar], 1024-sofar, fmt, args2);
        if (((written + sofar) >= 1024) ||
            (sbuf[sofar+written-1] == '\n'))  {
            syslog(syslogprio, "%s", sbuf);
            sbuf[0] = 0;
        }
    }
    if (confd_user_log_hook != NULL) {
        va_copy(args2, args);
        confd_user_log_hook(syslogprio, fmt, args2);
    }
}

void confd_printf(int syslogprio, const char  *fmt, ...)
{
     va_list args;

     va_start(args, fmt);
     confd_vprintf(syslogprio, fmt, args);
     va_end(args);
}

void confd_trace_printf(const char  *fmt, ...)
{
    va_list args;

    va_start(args, fmt);
    confd_vprintf(LOG_DEBUG, fmt, args);
    va_end(args);
}

void confd_trace(enum confd_debug_level level,const char  *fmt, ...)
{
    int syslog_level;
    va_list args;

    va_start(args, fmt);
    if (level == CONFD_TRACE)
        syslog_level = LOG_DEBUG;
    else
        syslog_level = LOG_ERR;
    v_confd_trace(syslog_level, level, fmt, args);
    va_end(args);
}


void confd_report_err(enum confd_debug_level level,const char  *fmt, ...)
{
    va_list args;

    va_start(args, fmt);
    v_confd_trace(LOG_ERR, level, fmt, args);
    va_end(args);
}


static int ret_eof(const char *fmt, ...);

int confd_do_connect(int sock, const struct sockaddr *srv, int srv_sz, int id)
{
    unsigned char buf[10];
    unsigned char reply[10];
    int ret;
    int do_access = confd_ipc_access_secret != NULL;
    int one = 1;

    if (confd_check_init() != CONFD_OK)
        return CONFD_ERR;
    clr_confd_err();
    if ((ret = connect(sock, srv, srv_sz)) < 0)
        return ret_err(CONFD_ERR_OS, "Failed to connect to ConfD: %s",
                       strerror(errno));
    if ((srv->sa_family == AF_INET || srv->sa_family == AF_INET6) &&
        id != CLIENT_STREAM)
        (void)setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
    buf[0] = id;
    if (do_access)
        buf[0] |= IPC_PROTO_WANT_CHALLENGE;
    put_int16(CONFD_LIB_PROTO_VSN, &buf[1]);
    put_int32(CONFD_LIB_VSN, &buf[3]);
    buf[7] = MAXDEPTH;
    buf[8] = MAXKEYLEN;

    BADTERM_IF(CAPI_VALIDATE_RAWBUF(capi_dir_send, capi_packet_raw,
                                    buf, 9,
                                    -1, -1) != CONFD_OK);

    if ((ret = confd_write(sock, buf, 9)) != CONFD_OK)
        return ret;
    if (do_access) {
        switch (confd_ipc_access_check(sock, confd_ipc_access_secret)) {
        case 1:  /* success */
            break;
        case 0:
            return ret_err(CONFD_ERR_PROTOUSAGE, "Access denied");
        default:
            return ret_err(CONFD_ERR_PROTOUSAGE, "Access check failed");
        }
    }
    if ((ret = read_fill(sock, reply, 9)) != 9) {
        return ret;
    }

    CAPI_VERBOSE("Read %d bytes\n", ret);

    BADTERM_IF(CAPI_VALIDATE_RAWBUF(capi_dir_recv, capi_packet_raw,
                                    reply, 9,
                                    -1, -1) != CONFD_OK);

    switch (reply[0]) {
    case IPC_PROTO_OK:
        confd_version = get_int32(&reply[3]);
        confd_maxdepth = reply[7];
        confd_maxkeylen = reply[8];
        return CONFD_OK;
    case IPC_PROTO_BAD_VSN:
        return ret_err(CONFD_ERR_PROTOUSAGE, "Library protocol version (%d) "
                       "is not compatible with ConfD protocol version (%d)",
                       CONFD_LIB_PROTO_VSN, get_int16(&reply[1]));
    case IPC_PROTO_BAD_SIZES:
        confd_maxdepth = reply[7];
        confd_maxkeylen = reply[8];
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Library MAXDEPTH/MAXKEYLEN %d/%d for confd_hkeypath_t "
                       "are too small, ConfD needs %d/%d",
                       MAXDEPTH, MAXKEYLEN, confd_maxdepth, confd_maxkeylen);
    }
    return confd_internal_error("%s(%d): Failed to decode data\n",
                                __FILE__, __LINE__);
}

int read_fill(int fd, unsigned char *buf, int len)
{
    int i;
    unsigned int got = 0;

    do {
        if ((i = read(fd, buf+got, len-got)) <= 0) {
            if (i == 0 || (i < 0 && errno == ECONNRESET)) {
                return ret_eof("EOF on socket to ConfD");
            }
            if (errno != EINTR) {
                return ret_err(CONFD_ERR_OS,
                               "Failed to read %d bytes from ConfD: %s",
                               len,strerror(errno));
            }
            i = 0;
        }
        got += i;
    } while (got < len);
    return (len);
}

int write_fill(int fd, const unsigned char *buf, int len)
{
    int i;
    unsigned int done = 0;

    do {
        if ((i = write(fd, (char *)(buf+done), len-done)) < 0) {
            if (errno == EPIPE || errno == ECONNRESET) {
                return ret_eof("Socket to ConfD is closed");
            }

#ifdef __APPLE__
            /*
              In Yosemite and later, there is an undocumented feature
              where if the socket is being taken down while you do a
              sendto, or write, it can return EPROTOTYPE. If you retry the
              sendto you will get the EPIPE.

              The bug report can be found at:
              http://openradar.appspot.com/19012087
            */
            if (errno == EPROTOTYPE) {
                return ret_eof("Socket to ConfD is closed");
            }
#endif

            if (errno != EINTR)
                return ret_err(CONFD_ERR_OS,
                               "Failed to write %d bytes to ConfD: %s",
                               len-done, strerror(errno));
            i = 0;
        }
        done += i;
    } while (done < len);
    return (len);
}

int confd_write(int sock, const unsigned char *buf, int len)
{
    int rval;

    CAPI_VERBOSE("Write %d bytes\n", len);

    if ((rval = write_fill(sock, buf, len)) != len)
        return rval;
    return CONFD_OK;
}

/* Print junk to stderr and die */
void confd_fatal(const char *fmt, ...)
{
    va_list args;

    if (strlen(fmt) > 0) {
        va_start(args, fmt);
        vfprintf(stderr,fmt,args);
        va_end(args);
    }
    exit(1);
}

int confd_internal_error(const char *fmt, ...)
{
    char buf[BUFSIZ];
    FILE *fp = confd_debug_stream;
    va_list args;

    if (strlen(fmt) > 0) {
        va_start(args, fmt);
        vsnprintf(buf, sizeof(buf), fmt, args);
        va_end(args);
        if (fp == NULL)
            fp = stderr;
        fprintf(fp, "INTERNAL ERROR: %s\n", buf);
        if (confd_lib_use_syslog)
            syslog(LOG_CRIT, "INTERNAL ERROR: %s", buf);
        if (confd_user_log_hook != NULL) {
            va_start(args, fmt);
            confd_user_log_hook(LOG_CRIT, fmt, args);
            va_end(args);
        }
        confd_set_lasterr("%s", buf);
    }
    confd_set_errno(CONFD_ERR_INTERNAL);
    return CONFD_ERR;
}

int ret_err(int ecode, const char *fmt, ...)
{
    va_list args;
    int saved_errno = errno;

    va_start(args, fmt);
    confd_vset_lasterr(fmt, args);
    va_end(args);

    va_start(args, fmt);
    v_confd_trace(LOG_ERR, CONFD_DEBUG, fmt, args);
    va_end(args);
    confd_set_errno(ecode);
    errno = saved_errno;
    return CONFD_ERR;
}


void *ret_null(const char *fmt, ...)
{
    va_list args;
    int saved_errno = errno;

    va_start(args, fmt);
    confd_vset_lasterr(fmt, args);
    va_end(args);

    va_start(args, fmt);
    v_confd_trace(LOG_ERR, CONFD_DEBUG, fmt, args);
    va_end(args);
    errno = saved_errno;
    return NULL;
}

static int ret_eof(const char *fmt, ...)
{
    va_list args;

    va_start(args, fmt);
    confd_vset_lasterr(fmt, args);
    va_end(args);

    va_start(args, fmt);
    v_confd_trace(LOG_ERR, CONFD_DEBUG, fmt, args);
    va_end(args);
    confd_set_errno(CONFD_ERR_EOF);
    return CONFD_EOF;
}

int op_write(int sock, int cdbop, int thandle)
{
    int len;
    unsigned char buf[12];
    int ret;

    if (thandle == -1) {
        put_int32(4, buf);
        put_int32(cdbop, buf+4);
        len = 8;
    } else {
        put_int32(8, buf);
        put_int32(cdbop, buf+4);
        put_int32(thandle, buf+8);
        len = 12;
    }

    BADTERM_IF(CAPI_VALIDATE_RAWBUF(capi_dir_send, capi_packet_opaque,
                                    buf+4, len-4,
                                    cdbop, thandle) != CONFD_OK);

    ret = confd_write(sock, buf, len);
    DO_RET_IF(ret != CONFD_OK);
    return ret;
}

/* writes OP + xlen bytes from xbuf */
int op_write_buf(int sock, int cdbop, const char *xbuf,
                 int xlen, int thandle)
{
    int hdrlen;
    int len;
    unsigned char buf[12+xlen];
    int ret;

    if (thandle == -1) {
        hdrlen = 4;
        len = 4 + hdrlen + xlen;
        put_int32(len-4, buf);
        put_int32(cdbop, buf+4);
    } else {
        hdrlen = 8;
        len = 4 + hdrlen + xlen;
        put_int32(len-4, buf);
        put_int32(cdbop, buf+4);
        put_int32(thandle, buf+8);
    }

    memcpy(buf+4+hdrlen, xbuf, xlen); /* BUGBUG: Can copy be avoided? */

    BADTERM_IF(CAPI_VALIDATE_RAWBUF(capi_dir_send, capi_packet_opaque,
                                    buf+4, len-4,
                                    cdbop, thandle) != CONFD_OK);

    ret = confd_write(sock, buf, len);
    DO_RET_IF(ret != CONFD_OK);
    return ret;
}

int term_write(int sock, const ETERM *term, int cdbop, int thandle)

{
    unsigned char *buf;
    unsigned char *encode_pos;
    int termlen = erl_term_len((ETERM*)term);
    int payload_len = termlen;
    int ret;

    if (cdbop == -1 && thandle == -1) {
        if ((buf = (unsigned char *) confd_malloc(payload_len+4)) == NULL)
            return CONFD_ERR;
        put_int32(payload_len, buf);
        encode_pos = buf+4;
    } else if (thandle == -1) { /* cdb or maapi call */
        if ((buf = (unsigned char *) confd_malloc(payload_len+8)) == NULL)
            return CONFD_ERR;
        payload_len += 4;
        put_int32(payload_len, buf);
        put_int32(cdbop, buf+4);
        encode_pos = buf+8;
    } else { /* maapi call containing tid */
        if ((buf = (unsigned char *) confd_malloc(payload_len+12)) == NULL)
            return CONFD_ERR;
        payload_len += 8;
        put_int32(payload_len, buf);
        put_int32(cdbop, buf+4);
        put_int32(thandle, buf+8);
        encode_pos = buf+12;
    }

    if (erl_encode((ETERM*)term, encode_pos) == 0) {
        free(buf);
        return confd_internal_error("%s(%d): failed to encode",
                                    __FILE__, __LINE__);
    }

    BADTERM_IF(CAPI_VALIDATE_RAWBUF(capi_dir_send, capi_packet_eterm,
                                    buf+4, payload_len,
                                    cdbop, thandle) != CONFD_OK);

    ret = confd_write(sock, buf, payload_len+4);
    free(buf);
    if (ret != CONFD_OK)
        return ret;
    if ((confd_debug_level == CONFD_PROTO_TRACE) &&
        (confd_debug_stream != NULL)) {
        print_proto_start(confd_debug_stream, "\n", sock, "SEND");
        if (cdbop != -1) {
            fprintf(confd_debug_stream, "op=%d isrel=%d th=%d ",
                    CDB_OP(cdbop), CDB_IS_REL(cdbop), thandle);
        }
        erl_print_term(confd_debug_stream, term);
        fprintf(confd_debug_stream, "\n");
    }
    return CONFD_OK;
}

int term_write_ei(int sock, const char *ebuf, int esize,
                  int cdbop, int thandle)
{
    unsigned char *buf;
    int ret;
    int offset;
    int payload_size = esize;
    int len_size = 4;
    int cdbop_size = 0;
    int thandle_size = 0;
    int blob_size;
    int buf_size;

    if (cdbop   != -1) cdbop_size = 4;   /* cdb or maapi call */
    if (thandle != -1) thandle_size = 4; /* maapi call containing tid */
    BADTERM_IF(cdbop_size == 0 && thandle_size != 0);

    blob_size = cdbop_size + thandle_size + payload_size;
    buf_size = len_size + blob_size;
    buf = (unsigned char *) confd_malloc(buf_size);
    BADTERM_IF(buf == NULL);

    /* len */
    offset = 0;
    put_int32(blob_size, buf+offset);
    offset += len_size;

    /* cdbop */
    if (cdbop_size != 0) {
        put_int32(cdbop, buf+offset);
        offset += cdbop_size;
    }

    /* thandle */
    if (thandle_size != 0) {
        put_int32(thandle, buf+offset);
        offset += thandle_size;
    }

    /* payload */
    memcpy(buf+offset, ebuf, payload_size);

    BADTERM_IF(CAPI_VALIDATE_RAWBUF(capi_dir_send, capi_packet_eterm,
                                    buf+4, buf_size-4,
                                    cdbop, thandle) != CONFD_OK);

    ret = confd_write(sock, buf, buf_size);
    free(buf);

    if (ret != CONFD_OK)
        return ret;
    if ((confd_debug_level == CONFD_PROTO_TRACE) &&
        (confd_debug_stream != NULL)) {
        int pindex;
        int eversion;
        print_proto_start(confd_debug_stream, "\n", sock, "SEND");
        if (cdbop != -1) {
            fprintf(confd_debug_stream, "op=%d isrel=%d th=%d ",
                    CDB_OP(cdbop), CDB_IS_REL(cdbop), thandle);
        }
        pindex = 0;
        BADTERM_IF(ei_decode_version(ebuf, &pindex, &eversion) != 0);
        BADTERM_IF(confd_print_term(confd_debug_stream, ebuf, &pindex) <= 0);
        fprintf(confd_debug_stream, "\n");
    }
    return CONFD_OK;
}

static int _confd_read(int sock, unsigned char **buf, int *len)
{
    unsigned char lb[4];
    unsigned char *readbuf = NULL;
    int readlen;
    int retlen;

    retlen = read_fill(sock, &lb[0], 4);
    if (retlen != 4) {
        return retlen;
    }

    readlen = get_int32(lb);
    readbuf = confd_malloc(readlen);
    if (readbuf ==  NULL) {
        return CONFD_ERR;
    }

    retlen = read_fill(sock, readbuf, readlen);
    if (retlen != readlen) {
        free(readbuf);
        return retlen;
    }

    *buf = readbuf;
    *len = readlen;

    CAPI_VERBOSE("Read %d bytes\n", readlen+4);

    return CONFD_OK;
}

/* Read an ETERM on a socket */
ETERM *term_read(int sock, int *ret, int cdbop)
{
    ETERM *res = NULL;
    unsigned char *buf;
    int len;
    confd_value_t tag;

    if ((*ret = _confd_read(sock, &buf, &len)) != CONFD_OK)
        return NULL;

    if (CAPI_VALIDATE_RAWBUF(capi_dir_recv, capi_packet_eterm,
                             buf, len,
                             cdbop, -1)  != CONFD_OK) {
        free(buf);
        *ret = CONFD_ERR;
        return NULL;
    }

    if (cdbop == -1) { /* call is ext db  */
        if ((res = erl_decode(buf)) == NULL) {
            free(buf);
            *ret = confd_internal_error("%s(%d): Failed to decode data",
                                        __FILE__, __LINE__);
            return NULL;
        }
    } else { /* call is from CDB or maapi */
        unsigned int recop = (unsigned int)get_int32(buf);
        if (recop == cdbop && len != 4) {
            if ((res = erl_decode(buf+4)) == NULL) {
                *ret = confd_internal_error("%s(%d): Failed to decode data\n",
                    __FILE__, __LINE__);
                free(buf);
                return NULL;
            }
        } else if (recop == cdbop) {
            *ret = CONFD_OK;
            free(buf);
            return NULL;
        } else {
            int ecode;

            if (CDB_REPLY_IS_ERROR(recop) && CDB_OP(recop) == cdbop) {
                confd_lasterr()[0] = 0;
                CONFD_SET_XMLTAG(&tag, 0, 0);
                *confd_last_error_apptag() = tag.val.xmltag;
                if (len == 8) { /* we got plain error */
                    *ret = CONFD_ERR;
                    ecode = get_int32(buf+4);
                    confd_set_errno(ecode);
                    confd_report_err(CONFD_DEBUG,"Op returned error\n");
                    free(buf);
                    return NULL;
                } else {
                    ecode = get_int32(buf+4);
                    confd_set_errno(ecode);
                    if ((res = erl_decode(buf+8)) == NULL) {
                        *ret = confd_internal_error(
                            "%s(%d): Failed to decode data\n",
                            __FILE__, __LINE__);
                        free(buf);
                        return NULL;
                    }
                    if (ERL_IS_BINARY(res)) {
                        confd_set_lasterr("%s", ERL_BIN_PTR(res));
                    }
                    else {
                        /* {Str::binary(), Tag::[integer()|integer()]} */
                        confd_set_lasterr("%s", ERL_BIN_PTR(TE(res, 0)));
                        if (eterm_to_val(TE(res, 1), &tag) != NULL
                            && tag.type == C_XMLTAG) {
                            *confd_last_error_apptag() = tag.val.xmltag;
                        }
                    }
                    confd_report_err(CONFD_DEBUG,"%s - %s",
                                     confd_strerror(ecode), confd_lasterr());
                    erl_free_compound(res);
                    free(buf);
                    *ret = CONFD_ERR;
                    return NULL;
                }
            } else {
                free(buf);
                *ret = confd_internal_error(
                    "%s(%d): Unexpected data on socket! %d %d\n",
                    __FILE__, __LINE__, cdbop, recop);
                return NULL;
            }
        }
    }
    if ((confd_debug_level >= CONFD_PROTO_TRACE) &&
        (confd_debug_stream != NULL)) {
        print_proto_start(confd_debug_stream, "", sock, "GOT");
        if (res) {
            erl_print_term(confd_debug_stream, res);
            fprintf(confd_debug_stream, "\n");
        }
        else {
            fprintf(confd_debug_stream, "NULL\n");
        }
    }

    *ret = CONFD_OK;
    free(buf);
    return res;
}

int decode_binary_ei(const char *ebuf, int *eindex,
                     char **bin, long *sz)
{
    int etype;
    int elen;
    char *tmpbin = NULL;
    long tmpsz = 0;
    int ret;

    SAFE_BADTERM_IF(ei_get_type(ebuf, eindex, &etype, &elen) != 0);
    SAFE_BADTERM_IF(etype != ERL_BINARY_EXT);
    tmpbin = confd_malloc(elen+1);
    SAFE_BADTERM_IF(tmpbin == NULL);
    SAFE_BADTERM_IF(ei_decode_binary(ebuf, eindex, tmpbin, &tmpsz) != 0);
    SAFE_BADTERM_IF(elen != tmpsz);
    tmpbin[elen] = '\0'; /* Make string null terminated */
    *bin = tmpbin;
    *sz = tmpsz;
    return CONFD_OK;

saferet:
    free(tmpbin);
    return ret;
}

int decode_atom_ei(const char *ebuf, int *eindex,
                   char **bin, long *sz)
{
    int etype;
    int elen;
    char *tmpbin = NULL;
    int ret;

    SAFE_BADTERM_IF(ei_get_type(ebuf, eindex, &etype, &elen) != 0);
    SAFE_BADTERM_IF(etype != ERL_ATOM_EXT);

    tmpbin = confd_malloc(elen+1);
    SAFE_BADTERM_IF(tmpbin == NULL);

    SAFE_BADTERM_IF(ei_decode_atom(ebuf, eindex, tmpbin) != 0);

    *bin = tmpbin;
    *sz = elen;
    return CONFD_OK;

saferet:
    free(tmpbin);
    return ret;
}

int decode_binary_to_buf_ei(const char *ebuf, int *eindex,
                            char *buf, long *sz, int buf_size)
{
    int etype;
    int elen;
    char *tmpbin = NULL;
    long tmpsz = 0;
    int ret;

    SAFE_BADTERM_IF(ei_get_type(ebuf, eindex, &etype, &elen) != 0);
    SAFE_BADTERM_IF(etype != ERL_BINARY_EXT);
    // buf_size doesn't have enough space so can't be used directly.
    // elen + 1 is needed to make the string null terminated.
    if(elen >= buf_size) {
        tmpbin = confd_malloc(elen+1);
    } else {
        tmpbin = buf;
    }
    SAFE_BADTERM_IF(tmpbin == NULL);
    SAFE_BADTERM_IF(ei_decode_binary(ebuf, eindex, tmpbin, &tmpsz) != 0);
    SAFE_BADTERM_IF(elen != tmpsz);
    tmpbin[elen] = '\0'; /* Make string null terminated */

    if(tmpbin != buf){
        // Decoded term didn't fit in the buffer so tmpbin was used
        int write_sz = buf_size - 1;
        memcpy(buf, tmpbin, write_sz);
        free(tmpbin);
        buf[write_sz] = '\0';
        *sz = write_sz;
    } else {
        *sz = tmpsz;
    }
    return CONFD_OK;

saferet:
    free(tmpbin);
    return ret;
}

int decode_binary_or_atom_ei(char *ybuf, int *yindex, char **bin, long *sz) {
    int etype;
    int elen;

    BADTERM_IF(ei_get_type(ybuf, yindex, &etype, &elen) != 0);
    if (etype ==  ERL_BINARY_EXT) {
        return decode_binary_ei(ybuf, yindex, bin, sz);
    } else if (IS_INTEGER_EXT(etype)) {
        long l;
        // It's necessary to decode so the yindex moves forward
        BADTERM_IF(ei_decode_long(ybuf, yindex, &l) != 0);
        *bin = NULL;
        return CONFD_OK;
    } else if(etype == ERL_ATOM_EXT) {
        if((*bin = confd_malloc(elen+1)) == NULL) {
            return CONFD_ERR;
        } else {
            if(ei_decode_atom(ybuf, yindex, *bin) != 0) {
                *sz = elen;
                return CONFD_OK;
            }
            free(*bin);
        }
    }
    return CONFD_ERR;
}

/* Read an EBUF from a socket                               */
/* Returns confd status code CONFD_OK, CONFD_ERR etc.       */
/* Sets ybuf to new buffer or NULL when no decode is needed */
/* Sets yindex to start index in new buffer                 */
int term_read_ei(int sock, char **ybuf, int *yindex, int cdbop)
{
    int ret = CONFD_ERR;
    int len;
    char *readbuf = NULL;
    int readbegin = 0;
    int pindex = 0;

    SAFE_BADTERM_IF(*ybuf != NULL);

    ret = _confd_read(sock, (unsigned char **)&readbuf, &len);
    DO_RET_IF(ret != CONFD_OK);

    if (CAPI_VALIDATE_RAWBUF(capi_dir_recv, capi_packet_eterm,
                             (unsigned char *)readbuf, len,
                             cdbop, -1) != CONFD_OK) {
        free(readbuf);
        *ybuf = NULL;
        *yindex = 0;
        return CONFD_ERR;
    }

    if (cdbop == -1) { /* call is ext db  */
        *ybuf = (char *)readbuf;
        *yindex = 0;
        ret = CONFD_OK;
        goto traceret;
    }

    /* call is from CDB or maapi */
    unsigned int recop = (unsigned)get_int32(readbuf);
    if (recop == cdbop && len != 4) {
        *ybuf = (char *)readbuf;
        *yindex = 4;
        ret = CONFD_OK;
        goto traceret;
    }

    if (recop == cdbop) {
        ret = CONFD_OK;
        goto saferet;
    }

    int ecode;
    confd_value_t tag;
    if (CDB_REPLY_IS_ERROR(recop) && CDB_OP(recop) == cdbop) {
        confd_lasterr()[0] = 0;
        CONFD_SET_XMLTAG(&tag, 0, 0);
        *confd_last_error_apptag() = tag.val.xmltag;
        if (len == 8) { /* we got plain error */
            ecode = get_int32(readbuf+4);
            confd_set_errno(ecode);
            confd_report_err(CONFD_DEBUG,"Op returned error\n");
            ret = CONFD_ERR;
            SAFE_RET();
        }

        int eversion;
        char *bin = NULL;
        long sz = 0;

        ecode = get_int32(readbuf+4);
        confd_set_errno(ecode);
        readbegin = 8;

        pindex = readbegin;
        SAFE_BADTERM_IF(
            ei_decode_version(readbuf, &pindex, &eversion) != 0);
        if (decode_binary_ei(readbuf, &pindex, &bin, &sz) == CONFD_OK) {
            confd_set_lasterr("%s", bin);
            free(bin);
        } else {
            /* {Str::binary(), Tag::[integer()|integer()]} */
            int arity;

            SAFE_BADTERM_IF(
                ei_decode_tuple_header(readbuf, &pindex, &arity) != 0);
            SAFE_BADTERM_IF(
                decode_binary_ei(readbuf, &pindex, &bin, &sz) != CONFD_OK);
            confd_set_lasterr("%s", bin);
            free(bin);
            ret = eterm_to_val_ei(readbuf, &pindex, &tag);
            if (ret != CONFD_OK && tag.type == C_XMLTAG) {
                *confd_last_error_apptag() = tag.val.xmltag;
            }
        }
        confd_report_err(CONFD_DEBUG,"%s - %s",
                         confd_strerror(ecode), confd_lasterr());
        confd_free_eterm_val(&tag); /* BUGBUG: free tag */
        ret = CONFD_ERR;
        SAFE_RET();
    }

    ret = confd_internal_error(
        "%s(%d): Unexpected data on socket! %d %d\n",
        __FILE__, __LINE__, cdbop, recop);
    SAFE_RET();

traceret:
    if ((confd_debug_level >= CONFD_PROTO_TRACE) &&
        (confd_debug_stream != NULL)) {
        print_proto_start(confd_debug_stream, "", sock, "GOT");
        if (readbuf) {
            int eversion;
            pindex = *yindex;
            SAFE_BADTERM_IF(
                ei_decode_version(*ybuf, &pindex, &eversion) != 0);
            SAFE_BADTERM_IF(confd_print_term(confd_debug_stream,
                                        *ybuf, &pindex) <= 0);
            fprintf(confd_debug_stream, "\n");
        }
        else {
            fprintf(confd_debug_stream, "NULL\n");
        }
    }
    return ret;

saferet:
    free(readbuf);
    *ybuf = NULL;
    *yindex = 0;
    return ret;
}

static char *ret2str(int ret)
{
    switch(ret) {
    case CONFD_OK: return "CONFD_OK";
    case CONFD_ERR: return "CONFD_ERR";
    case CONFD_EOF: return "CONFD_EOF";
    default: return "UNKNOWN";
    }
}

static void cdb_ret_trace(int ret, ETERM *val)
{
    if (confd_debug_level >= CONFD_TRACE)
        confd_trace_printf(" --> %s\n", ret2str(ret));
}

static void cdb_ret_trace_ei(int ret)
{
    if (confd_debug_level >= CONFD_TRACE)
        confd_trace_printf(" --> %s\n", ret2str(ret));
}

ETERM *confd_call(int sock, const ETERM *term, int *status)
{
    ETERM *reply;

    if ((*status = term_write(sock, term, -1, -1)) < 0)
        return NULL;
    if ((reply = term_read(sock, status, -1)) == NULL)
        return NULL;
    if (ERL_IS_TUPLE(reply) && (ERL_TUPLE_SIZE(reply) == 3) &&
        ERL_IS_ATOM(TE(reply, 0)) && bin_eq(TE(reply, 0), "error")) {
        /* {error, Code, Reason} */
        *status = ret_err(TINT(reply, 1), "%s",
                          (char *)ERL_BIN_PTR(TE(reply, 2)));
        erl_free_compound(reply);
        return NULL;
    }
    return reply;
}

int confd_call_ei(int sock, const char *qbuf, int qsize,
                  char **ybuf, int *yindex)
{
    int ret;
    int arity;
    int version;
    int pindex;

    if (*ybuf != NULL) return CONFD_ERR;

    ret = term_write_ei(sock, qbuf, qsize, -1, -1);
    DO_RET_IF(ret != CONFD_OK);

    ret = term_read_ei(sock, ybuf, yindex, -1);
    DO_RET_IF(ret != CONFD_OK);
    pindex = *yindex;
    SAFE_BADTERM_IF(ei_decode_version(*ybuf, &pindex, &version) != 0);
    if (ei_decode_tuple_header(*ybuf, &pindex, &arity) == 0  && arity == 3) {
        char tag[MAXATOMLEN+1];
        long code;
        char *reason = NULL;
        long sz;

        if (ei_decode_atom(*ybuf, &pindex, tag) == 0 &&
            strcmp(tag, "error") == 0) {
            /* {error, Code, Reason} */
            if (ei_decode_long(*ybuf, &pindex, &code) == 0) {
                if (decode_binary_ei(*ybuf, &pindex,
                                     &reason, &sz) == CONFD_OK) {
                    ret = ret_err((int)code, "%s", reason);
                    free(reason);
                    SAFE_RET();
                }
            }
        }
    }

    return ret;

saferet:
    free(*ybuf);
    *ybuf = NULL;
    *yindex = 0;
    return ret;
}

unsigned char *confd_memdup(const unsigned char *p, int n)
{
    unsigned char *r = (unsigned char *)confd_malloc(n+1);

    if (r) {
        r[n] = 0;
        return (unsigned char *)memcpy(r, p, (size_t)n);
    }
    return NULL;
}

/* BUGBUG: Return value is a mix of number of bytes and confd status code */
static int format_path_keys(ETERM *tuple, char *buf, int bufsiz)
{
    int n = 0;
    int i;

    for (i = 0; i < ERL_TUPLE_SIZE(tuple); i++) {
        ETERM *term = ERL_TUPLE_ELEMENT(tuple, i);
        INVALID_TERM_TEST(bufsiz < 2);
        if (i > 0) {
            buf[n++] = ' ';
            bufsiz--;
        }
        if (ERL_IS_BINARY(term)) {
            INVALID_TERM_TEST(bufsiz <= ERL_BIN_SIZE(term));
            memcpy(&buf[n], ERL_BIN_PTR(term), ERL_BIN_SIZE(term));
            n += ERL_BIN_SIZE(term);
            bufsiz -= ERL_BIN_SIZE(term);
        } else {
            /* this is a bit heavy... */
            confd_value_t v;
            int tmp;
            if (eterm_to_val(term, &v) == NULL) {
                return confd_internal_error(
                    "%s(%d): Unexpected term to format_path_keys()\n",
                    __FILE__, __LINE__);
            }
            tmp = confd_pp_value(&buf[n], bufsiz, &v);
            confd_free_eterm_val(&v);
            INVALID_TERM_TEST(tmp >= bufsiz);
            n += tmp;
            bufsiz -= tmp;
        }
        buf[n] = 0;
    }
    return n;
}

#define MAYBE_SLASH(buf, n, slash) if (slash) buf[n++] = '/';

/* BUGBUG: Return value is a mix of number of bytes and confd status code */
static int format_path_term(ETERM *term, int slash, char *buf, int bufsiz)
{
    int n = 0;

    if (ERL_IS_BINARY(term)) {
        n = confd_strncpy(buf, bufsiz, ERL_BIN_PTR(term), ERL_BIN_SIZE(term));
        INVALID_TERM_TEST(n < ERL_BIN_SIZE(term));
        return n;
    }

    /* the result of /foo[55] */
    if (ERL_IS_LIST(term) && ERL_IS_NIL(ERL_CONS_TAIL(term))) {
        n = confd_snprintf(buf, bufsiz, "[%d]",
                           ERL_INT_VALUE(ERL_CONS_HEAD(term)));
        INVALID_TERM_TEST(n >= bufsiz);
        return n;
    }

    /* [ns|tag] pair - atoms or integers */
    if (ERL_IS_LIST(term)) {
        ETERM *ns = ERL_CONS_HEAD(term);
        ETERM *tag = ERL_CONS_TAIL(term);
        if (ERL_IS_ATOM(ns)) {
            int isiz = ERL_ATOM_SIZE(ns) + ERL_ATOM_SIZE(tag) + slash
                + 2; /* +2 = ':' + <null> */
            INVALID_TERM_TEST(bufsiz < isiz);
            MAYBE_SLASH(buf, n, slash);
            memcpy(&buf[n], ERL_ATOM_PTR(ns), ERL_ATOM_SIZE(ns));
            n += ERL_ATOM_SIZE(ns);
            buf[n++] = ':';
            memcpy(&buf[n], ERL_ATOM_PTR(tag), ERL_ATOM_SIZE(tag));
            n += ERL_ATOM_SIZE(tag);
            buf[n] = 0;
        } else {
            char *s;
            INVALID_TERM_TEST(bufsiz < slash + 4); /* +4 = x:x<null> */
            MAYBE_SLASH(buf, n, slash);
            if ((s = confd_ns2prefix(ERL_INT_UVALUE(ns))) != NULL) {
                n += confd_snprintf(&buf[n], bufsiz - n, "%s:", s);
            } else {
                n += confd_snprintf(&buf[n], bufsiz - n, "<%u>:",
                                    ERL_INT_UVALUE(ns));
            }
            INVALID_TERM_TEST(n >= bufsiz);
            if ((s = confd_hash2str(ERL_INT_UVALUE(tag))) != NULL) {
                n += confd_snprintf(&buf[n], bufsiz - n, "%s", s);
            } else {
                n += confd_snprintf(&buf[n], bufsiz - n, "<%u>",
                                    ERL_INT_UVALUE(tag));
            }
            INVALID_TERM_TEST(n >= bufsiz);
        }
        return n;
    }

    if (ERL_IS_ATOM(term)) {
        int isiz = ERL_ATOM_SIZE(term) + slash + 1; /* +1 = NULL */
        INVALID_TERM_TEST(isiz > bufsiz);
        MAYBE_SLASH(buf, n, slash);
        n += confd_strncpy(&buf[n], bufsiz - n, ERL_ATOM_PTR(term),
                           ERL_ATOM_SIZE(term));
        return n;
    }

    if (IS_INTEGER_OR_UNSIGNED_INTEGER(term)) {
        char *s;
        INVALID_TERM_TEST(bufsiz < 2 + slash);
        MAYBE_SLASH(buf, n, slash);
        if ((s = confd_hash2str(ERL_INT_UVALUE(term))) != NULL) {
            n += confd_snprintf(&buf[n], bufsiz - n, "%s", s);
        } else {
            n += confd_snprintf(&buf[n], bufsiz - n, "<%u>",
                                ERL_INT_UVALUE(term));
        }
        INVALID_TERM_TEST(n >= bufsiz);
        return n;
    }

    if (ERL_IS_TUPLE(term)) {
        int tmp;
        INVALID_TERM_TEST(bufsiz < 3);
        buf[n++] = '{';
        if ((tmp = format_path_keys(term, &buf[n], bufsiz - n)) == CONFD_ERR) {
            return CONFD_ERR;
        }
        n += tmp;
        INVALID_TERM_TEST(bufsiz - n < 2);
        buf[n++] = '}';
        buf[n] = 0;
        return n;
    }

    return confd_internal_error("%s(%d): Unexpected term to format_path()\n",
                                __FILE__, __LINE__);
}

char *format_path(int isrel, const ETERM *path)
{
    static char buf[BUFSIZ]; /* FIXME not thread safe */
    int n = 0;
    int tmp;
    int slash = 0;
    ETERM *hd;

    buf[0] = 0;
    if (!isrel)
        buf[n++] = '/';
    if (path == NULL) return "";
    if (! ERL_IS_LIST(path)) return "";
    while (! ERL_IS_EMPTY_LIST(path)) {
        hd = ERL_CONS_HEAD(path);
        if ((tmp = format_path_term(hd, slash, &buf[n], sizeof(buf) - n)) ==
            CONFD_ERR) {
            return NULL;
        }
        path = ERL_CONS_TAIL(path);
        slash = 1;
        n += tmp;
    }
    return &buf[0];
}

/* BUGBUG: Return value is a mix of number of bytes and confd status code */
static int format_path_keys_ei(const char *ebuf, int *eindex,
                               char *buf, int bufsiz)
{
    int n = 0;
    int i;
    int arity;
    int etype;
    int elen;

    INVALID_TERM_TEST(ei_decode_tuple_header(ebuf, eindex, &arity) != 0);

    for (i = 0; i < arity; i++) {
        INVALID_TERM_TEST(bufsiz < 2);
        if (i > 0) {
            buf[n++] = ' ';
            bufsiz--;
        }
        INVALID_TERM_TEST(ei_get_type(ebuf, eindex, &etype, &elen) != 0);
        if (etype == ERL_BINARY_EXT) {
            char bin[elen+1];
            long sz = 0;

            INVALID_TERM_TEST(ei_decode_binary(ebuf, eindex, bin, &sz) != 0);
            INVALID_TERM_TEST(bufsiz <= sz);
            /* BUGBUG: Double copy? */
            memcpy(&buf[n], &bin, sz);
            n += sz;
            bufsiz -= sz;
        } else {
            /* this is a bit heavy... */
            confd_value_t v;
            int tmp;
            if (eterm_to_val_ei(ebuf, eindex, &v) != CONFD_OK) {
                return confd_internal_error(
                    "%s(%d): Unexpected term to format_path_keys()\n",
                    __FILE__, __LINE__);
            }
            tmp = confd_pp_value(&buf[n], bufsiz, &v);
            confd_free_eterm_val(&v);
            INVALID_TERM_TEST(tmp >= bufsiz);
            n += tmp;
            bufsiz -= tmp;
        }
        buf[n] = 0;
    }
    return n;
}

static int format_path_term_ei(const char *ebuf, int *eindex,
                               int slash, char *buf, int bufsiz)
{
    int n = 0;
    int etype;
    int elen;

    INVALID_TERM_TEST(ei_get_type(ebuf, eindex, &etype, &elen) != 0);

    switch (etype) {
    case ERL_BINARY_EXT: {
        long sz = 0;

        INVALID_TERM_TEST(bufsiz < elen);
        INVALID_TERM_TEST(ei_decode_binary(ebuf, eindex, buf, &sz) != 0);
        return sz;
    }

    case ERL_LIST_EXT: {
        /* Assume list with arity 1 */
        int arity;

        INVALID_TERM_TEST(ei_decode_list_header(ebuf, eindex, &arity) != 0);
        INVALID_TERM_TEST(arity != 1);
        INVALID_TERM_TEST(ei_get_type(ebuf, eindex, &etype, &elen) != 0);

        switch (etype) {
        case ERL_ATOM_EXT: {
            /* Assume improper list - [ns|tag] pair of atoms */
            char ns[MAXATOMLEN+1];
            char tag[MAXATOMLEN+1];
            int nslen = elen;;
            int taglen;
            int isiz;

            INVALID_TERM_TEST(ei_decode_atom(ebuf, eindex, ns) != 0);
            ei_get_type(ebuf, eindex, &etype, &taglen);
            INVALID_TERM_TEST(ei_decode_atom(ebuf, eindex, tag) != 0);
            isiz = nslen + taglen + slash + 2; /* +2 = ':' + <null> */
            INVALID_TERM_TEST(bufsiz < isiz);
            MAYBE_SLASH(buf, n, slash);
            memcpy(&buf[n], &ns, nslen);
            n += nslen;
            buf[n++] = ':';
            memcpy(&buf[n], &tag, taglen);
            n += taglen;
            buf[n] = 0;
            return n;
        }
        case ERL_SMALL_INTEGER_EXT:
        case ERL_INTEGER_EXT:
        case ERL_SMALL_BIG_EXT:
        case ERL_LARGE_BIG_EXT: {
            char *s;
            unsigned long uval;
            INVALID_TERM_TEST(ei_decode_ulong(ebuf, eindex, &uval) != 0);
            INVALID_TERM_TEST(ei_get_type(ebuf, eindex, &etype, &elen) != 0);

            if (etype == ERL_NIL_EXT) {
                /* the result of /foo[55] */
                n = confd_snprintf(buf, bufsiz, "[%ld]", (long)uval);
                INVALID_TERM_TEST(n >= bufsiz);
                return n;
            }
            else {
                /* Assume improper list - [ns|tag] pair of integers */
                unsigned long nsval = uval;
                unsigned long tagval;
                INVALID_TERM_TEST(ei_decode_ulong(ebuf, eindex, &tagval) != 0);
                INVALID_TERM_TEST(bufsiz < slash + 4); /* +4 = x:x<null> */
                MAYBE_SLASH(buf, n, slash);
                if ((s = confd_ns2prefix(nsval)) != NULL) {
                    n += confd_snprintf(&buf[n], bufsiz - n, "%s:", s);
                } else {
                    n += confd_snprintf(&buf[n], bufsiz - n, "<%lu>:", nsval);
                }
                INVALID_TERM_TEST(n >= bufsiz);
                if ((s = confd_hash2str(tagval)) != NULL) {
                    n += confd_snprintf(&buf[n], bufsiz - n, "%s", s);
                } else {
                    n += confd_snprintf(&buf[n], bufsiz - n, "<%lu>", tagval);
                }
                INVALID_TERM_TEST(n >= bufsiz);
                return n;
            }
        }
        default:
            INVALID_TERM_RET();
        }
    }
    case ERL_ATOM_EXT: {
        int isiz;
        char node[MAXATOMLEN+1];

        INVALID_TERM_TEST(ei_decode_atom(ebuf, eindex, node) != 0);

        isiz = elen + slash + 1; /* +1 = NULL */
        INVALID_TERM_TEST(isiz > bufsiz);
        MAYBE_SLASH(buf, n, slash);
        n += confd_strncpy(&buf[n], bufsiz - n, &node, elen);
        return n;
    }
    case ERL_SMALL_INTEGER_EXT:
    case ERL_INTEGER_EXT:
    case ERL_SMALL_BIG_EXT:
    case ERL_LARGE_BIG_EXT: {
        char *s;
        unsigned long val;

        INVALID_TERM_TEST(bufsiz < 2 + slash);
        MAYBE_SLASH(buf, n, slash);

        INVALID_TERM_TEST(ei_decode_ulong(ebuf, eindex, &val) != 0);

        if ((s = confd_hash2str(val)) != NULL) {
            n += confd_snprintf(&buf[n], bufsiz - n, "%s", s);
        } else {
            n += confd_snprintf(&buf[n], bufsiz - n, "<%lu>", val);
        }
        INVALID_TERM_TEST(n >= bufsiz);
        return n;
    }

    case ERL_SMALL_TUPLE_EXT:
    case ERL_LARGE_TUPLE_EXT: {
        int tmp;

        INVALID_TERM_TEST(bufsiz < 3);
        buf[n++] = '{';
        tmp = format_path_keys_ei(ebuf, eindex, &buf[n], bufsiz - n);
        if (tmp == CONFD_ERR) {
            return CONFD_ERR;
        }
        n += tmp;
        INVALID_TERM_TEST(bufsiz - n < 2);
        buf[n++] = '}';
        buf[n] = 0;
        return n;
    }
    default:
        return confd_internal_error(
            "%s(%d): Unexpected term to format_path()\n",
            __FILE__, __LINE__);
    }
}

char *format_path_ei(int isrel, const char *ebuf, const int *eindex)
{
    static char buf[BUFSIZ]; /* FIXME not thread safe */
    int n = 0;
    int tmp;
    int slash = 0;
    int pindex = *eindex;
    int arity;
    int i;

    if (ebuf == NULL) return "INTERNAL ERROR ebuf == NULL";

    if (ei_decode_list_header(ebuf, &pindex, &arity) != 0) {
        return "";
    }

    buf[0] = 0;
    if (!isrel)
        buf[n++] = '/';

    for (i=0; i < arity; i++) {
        tmp = format_path_term_ei(ebuf, &pindex,
                                  slash, &buf[n], sizeof(buf) - n);
        if (tmp == CONFD_ERR) {
            return NULL;
        }
        slash = 1;
        n += tmp;
    }
    return &buf[0];
}

#if 0 /* not needed w new parse_path() - remove later */
static char *tok(const char **s)
{
    int n = 0;
    char buf[BUFSIZ];
    const char *ptr = *s;
    if (*ptr == '}')
        return NULL;
    while (1) {
        if (*ptr == ' ') {
            while (*ptr == ' ')
                ptr++;
            *s = ptr;
            buf[n] = 0;
            return strdup(buf);
        }
        else if (*ptr == '"') {
            buf[n++] = *ptr++;
            while (*ptr != '"') {
                if (*ptr == '\\')
                    buf[n++] = *ptr++;
                if (*ptr == '\0') {
                    *s = ptr;
                    return NULL;
                }
                buf[n++] = *ptr++;
            }
            buf[n++] = *ptr++;
        }
        else if (*ptr == '}') {
            buf[n] = 0;
            *s = ptr;
            return strdup(buf);
        }
        else if (*ptr == '\0') {
            *s = ptr;
            return NULL;
        }
        else {
            buf[n++] = *ptr++;
        }
    }
}
#endif

static int get_leaf_list_type(struct confd_cs_node *node,
                              struct confd_type **type_ret)
{
    *type_ret = NULL;

    if (! (node->info.flags & CS_NODE_IS_LEAF_LIST)) {
        return CONFD_ERR_PROTOUSAGE;
    }

    struct confd_type *type;
    for (type = node->info.type; type != NULL; type = type->parent) {
        if (type->validate == confd_list_validate) {
            struct confd_type_list *l = type->opaque;
            *type_ret = l->type;
            return CONFD_OK;
        }
    }
    return CONFD_ERR_UNAVAILABLE;
}

struct confd_type *confd_get_leaf_list_type(struct confd_cs_node *node)
{
    int err;
    struct confd_type *type;

    err = get_leaf_list_type(node, &type);
    if (err == CONFD_ERR_UNAVAILABLE) {
        ret_err(CONFD_ERR_UNAVAILABLE, "Type information not loaded");
    } else if (err == CONFD_ERR_PROTOUSAGE) {
        ret_err(CONFD_ERR_PROTOUSAGE, "Not a leaf-list");
    } else if (err != CONFD_OK) {
        ret_err(err, "Unknown error");
    }
    return type;
}

int pp_keyval(char *buf, int n, const confd_value_t *v, int ns)
{
    char *s;
    int len;
    int nquot, nesc, qlen;
    int i, j;

    switch (v->type) {
    case C_STR:
        s = v->val.s;
        len = strlen(s);
        break;
    case C_BUF:
        s = (char *)CONFD_GET_BUFPTR(v);
        len = CONFD_GET_BUFSIZE(v);
        break;
    default:
        return confd_pp_value(buf, n, v);
    }

    /* need quoting if it's a null string, or if there are
       spaces, right-braces, quotes, or backslashes - if quoting,
       need to backslash-escape quotes and backslashes */
    if (len == 0) {
        qlen = 2;
    } else {
        for (i = 0, nquot = 0, nesc = 0; i < len; i++) {
            switch (s[i]) {
            case ' ': case '}': case '\t': case '\r':
            case '\n': case '\f': case '\v': case '\b':
                nquot++; break;
            case '"': case '\\':
                nesc++; break;
            }
        }
        if (nquot + nesc == 0)
            qlen = len;
        else
            qlen = len + 2 + nesc;
    }
    if (qlen == len) {
        confd_strncpy(buf, n, s, len);
        return len;
    }
    i = j = 0;
    if (j < n - 1)
        buf[j++] = '"';
    while (i < len && j < n - 1) {
        if (s[i] == '"' || s[i] == '\\')
            buf[j++] = '\\';
        if (j < n - 1)
            buf[j++] = s[i++];
    }
    if (j < n - 1)
        buf[j++] = '"';
    if (j < n)
        buf[j] = '\0';
    return qlen;
}


static int format_ip4(char *buf, int dstsz, struct in_addr *ip)
{
    char tmp[INET_ADDRSTRLEN];
    memset(tmp, 0, INET_ADDRSTRLEN);
    inet_ntop(AF_INET, ip, &tmp[0], INET_ADDRSTRLEN);
    return confd_snprintf(buf, dstsz, "%s", tmp);
}


static int format_ip6(char *buf, int dstsz, struct in6_addr *ip)
{
    char dst[INET6_ADDRSTRLEN];
    inet_ntop(AF_INET6, ip, &dst[0], INET6_ADDRSTRLEN);
    return confd_snprintf(buf, dstsz, "%s", dst);
}

static int format_x(char *buf, int dstsz, confd_value_t *vv, int inbraces)
{
    if (inbraces)
        return pp_keyval(buf, dstsz, vv, 0);
    else
        return confd_pp_value(buf, dstsz, vv);
}


#define W() do {                                \
        if (wmode) {*dst++ = *src++; dstsz--;}  \
        else {src++; dst++; dstsz--;}           \
    } while (0)

int substitute_percent(const char *src, char *dst, int dstsz, va_list args,
                       int skip_keys)
{
    int wmode = 1;   /* are we writing */
    int n;
    int inbracks = 0;
    int inbraces = 0;
    char *orig_dst = dst;
    while (1) {
        char c = *src;
        if (dstsz <= 1) {
            wmode = 0;
            if (dstsz == 1) {
                *dst = 0; /* add final 0 before bailing out */
            }
        }
        switch (c) {
        case '[':
            inbracks = 1;
            W();
            break;
        case ']':
            inbracks = 0;
            W();
            break;
        case '{':
            inbraces = 1;
            W();
            break;
        case '}':
            inbraces = 0;
            W();
            break;
        case 0:
            *dst = 0;
            return (dst - orig_dst);
        case '%':
            if (inbracks && *(src+1) == 'd') {
                int i = va_arg(args, int);
                src += 2;
                inbracks = 0;
                if (!skip_keys) {
                    n = confd_snprintf(dst, dstsz, "%d", i);
                    dst += n;
                    dstsz -= n;
                }
            }
            else if (inbracks) {
                return 0;
            }
            else if (*(src+1) == 's') {
                char *s = va_arg(args, char *);
                src += 2;
                if (!skip_keys || !inbraces) {
                    n = confd_snprintf(dst, dstsz, "%s", s);
                    dst += n;
                    dstsz -= n;
                }
            }
            else if (*(src+1) == 'd') {
                int i = va_arg(args, int);
                src += 2;
                if (!skip_keys || !inbraces) {
                    n = confd_snprintf(dst, dstsz, "%d", i);
                    dst += n;
                    dstsz -= n;
                }
            }
            else if (*(src+1) == 'u') {
                n = confd_snprintf(dst, dstsz, "%u", va_arg(args,unsigned int));
                dst += n;
                src += 2;
                dstsz -= n;
            }
            else if (*(src+1) == 'x') {
                confd_value_t *v = va_arg(args, confd_value_t*);
                src += 2;
                if (!skip_keys || !inbraces) {
                    n = format_x(dst, dstsz, v, inbraces);
                    dst += n;
                    dstsz -= n;
                }
            }
            else if (*(src+1) == '*' && *(src+2) == 'x') {
                int i, nvals = va_arg(args, int);
                confd_value_t *v = va_arg(args, confd_value_t*);
                src += 3;
                if (!skip_keys || !inbraces) {
                    for (i = 0; i < nvals; i++) {
                        if (i > 0) {
                            n = confd_snprintf(dst, dstsz, " ");
                            dst += n;
                            dstsz -= n;
                        }
                        n = format_x(dst, dstsz, v, inbraces);
                        dst += n;
                        dstsz -= n;
                    }
                }
            }
            else if (dst == orig_dst && *(src+1) == 'h') {
                confd_hkeypath_t *kp = va_arg(args, confd_hkeypath_t*);
                src += 2;
                if (!skip_keys || !inbraces) {
                    n = confd_pp_kpath(dst, dstsz, kp);
                    dst += n;
                    dstsz -= n;
                }
            }
            else if (dst == orig_dst && *(src+1) == '*' && *(src+2) == 'h') {
                int len = va_arg(args, int);
                confd_hkeypath_t *kp = va_arg(args, confd_hkeypath_t*);
                src += 3;
                if (!skip_keys || !inbraces) {
                    n = confd_pp_kpath_len(dst, dstsz, kp, len);
                    dst += n;
                    dstsz -= n;
                }
            }
            else if (strncmp(src, "%ip4", 4) == 0) {
                struct in_addr *ip = va_arg(args, struct in_addr*);
                src += 4;
                if (!skip_keys || !inbraces) {
                    n = format_ip4(dst, dstsz, ip);
                    dst += n;
                    dstsz -= n;
                }
            }
            else if (strncmp(src, "%ip6", 4) == 0) {
                struct in6_addr *ip6 = va_arg(args, struct in6_addr*);
                src += 4;
                if (!skip_keys || !inbraces) {
                    n = format_ip6(dst, dstsz, ip6);
                    dst += n;
                    dstsz -= n;
                }
            }
            else {
                W();
            }
            break;
        default:
            W();
        }
    }
}

#undef W


static ETERM *mk_tag_elem(ETERM *ns, const char *tagstr, int taglen)
{
    ETERM *tag;

    tag = erl_mk_eatom(tagstr, taglen);
    if (ns == NULL)
        return tag;
    return erl_cons(ns, tag);
}

ETERM *mk_tag_elem2(const char *tagstr)
{
    char *p = strchr(tagstr, ':');
    ETERM *ns, *tag;

    if (p != NULL) {
        ns =  erl_mk_eatom(tagstr, p - tagstr);
        tag = erl_mk_atom(++p);
        return erl_cons(ns, tag);
    } else {
        tag = erl_mk_atom(tagstr);
        return tag;
    }
}

ETERM *mk_str_key(char *beg, char *end)
{
    char *bp = beg;
    char *ep = end;

    while (bp < end && isspace(*bp)) bp++;
    while (ep > bp && isspace(*(ep-1))) ep--;
    if (bp == ep)
        return NULL;
    return erl_mk_binary(bp, ep-bp);
}

static int hkeypath_to_eterm_arr(confd_hkeypath_t *hkp, ETERM **arr,
                                 int len, int reverse);


typedef enum {
    COPY,
    SUBST_INT,
    SUBST_UINT,
    SUBST_STRING,
    SUBST_IP4,
    SUBST_IP6,
    SUBST_VALUE_ARR,
    SUBST_HKEY,
    SUBST_VALUE_ARR_LEN,
    SUBST_HKEY_LEN
} exp_cmd;

typedef struct {
    exp_cmd action;
    unsigned int len;
} exp_action;

void determine_action(const char **fp, char **dp,
                      char dst[], exp_action *action) {

#define ACTION(cmd, inc) action->action = cmd; *fp += inc
#define STEP(inc) dp += inc; dstsz -= inc;

        unsigned char current = **fp;

        /* Determine action, i.e., expand or copy */

        /* %[*]h is only allowed at start of fmt string */
        if (*dp == dst && current == '%'
            && (*(*fp+1) == 'h' || (*(*fp+1) == '*' && *(*fp+2) == 'h'))) {
            if (*(*fp+1) == 'h') {
                action->len = 0;
                ACTION(SUBST_HKEY, 2);
            } else {
                //action.len = va_arg(args, int);
                ACTION(SUBST_HKEY_LEN, 3);
            }
        } else
            switch (current) {
            case '%': {
                switch (*(*fp+1)) {
                case 'd':
                    ACTION(SUBST_INT, 2);
                    break;
                case 'u':
                    ACTION(SUBST_UINT, 2);
                    break;
                case 's':
                    ACTION(SUBST_STRING, 2);
                    break;
                case 'i':
                    if (strncmp(*fp+1, "ip4", 3) == 0) {
                        ACTION(SUBST_IP4, 4);
                    } else if (strncmp(*fp+1, "ip6", 3) == 0) {
                        ACTION(SUBST_IP6, 4);
                    } else {
                        ACTION(COPY, 1);
                    }
                    break;
                case '*':
                    if (*(*fp+2) == 'x') {
                        ACTION(SUBST_VALUE_ARR_LEN, 3);
                        //action.len = va_arg(args, int);
                    } else {
                        ACTION(COPY, 1);
                    }
                    break;
                case 'x':
                    ACTION(SUBST_VALUE_ARR, 2);
                    action->len = 1;
                    break;
                }
                break;
            }
            default:
                ACTION(COPY, 1);
                break;
            }
}

typedef enum {
    NO_PP_ERROR,
    NO_PREFIX,
    DEST_OVERFLOW,
    BAD_VALUE,
    BAD_HKEY,
    KEYLEN_OVERFLOW,
    NO_KEYS,
    KEY_UNTERM,
    INDEX_JUNK,
    INDEX_TOO_LONG,
    KEY_IN_KEY
} parse_path_error;

typedef enum {
    STRKEY,
    VALUE_PTR
} keytype;

typedef struct {
    keytype type;
    union {
        struct {
            char *beg;
            long len;
        } keystr;
        confd_value_t *vp;
    } data;
} keypart;

typedef enum {
    NO_QUOTE,
    IN_QUOTE,
    BS_QUOTE
} quote_state;

typedef enum {
    E_KEY,
    E_TAG,
    EH_TAG,                     /* hashed tag */
    E_INDEX,
    PATH_PART
} elem_type;

typedef struct {
    char *chars;
    int len;
} atomptr;

typedef struct {
    elem_type type;
    union {
        struct {
            int keylen;
            keypart keyparts[MAXKEYLEN+2];
        } key;
        struct {
            atomptr ns;
            atomptr tag;
        } tag;
        struct {
            unsigned int hns;
            unsigned int htag;
        } htag;
        int index;
    } val;
} path_elem;

/* New, refactored implementation of parse_path */
int parse_path_aux(bool *isrel, const char *fmt, va_list args,
                    path_elem elems[], int *npelem, char dst[], int dstsz,
                    char hk_keybuf[], int keybufsz)
{
    int n;
    int rel = -1;
    /* char hk_keybuf[2048]; */
    char *keybuf = hk_keybuf;

    keypart keyparts[MAXKEYLEN+2];
    int nkeys = 0;
    const char *fp = fmt;       /* ptr into fmt */
    /* destination where new string is constructed */
    //char dst[BUFSIZ];
    /* ptr into dst, where we add new stuff  */
    char *dp = dst;
    //int dstsz = sizeof(dst);
    char *s = dst;
    char *beg = dst;
    atomptr nsptr = {NULL, 0};
    char *lbrack = NULL;
    char *keybeg = NULL;
    int got_key = 0;
    quote_state in_quote = NO_QUOTE;
    confd_value_t *vp;
    confd_hkeypath_t *kp;
    parse_path_error error = NO_PP_ERROR;


    /* Trim leading spaces. */
    while (isspace(*fp)) fp++;

    while (*fp != '\0') {
        unsigned char current = *fp;
        exp_action action = {.action = COPY, .len = 0};

        determine_action(&fp, &dp, dst, &action);

        switch (action.action) {
        case SUBST_HKEY_LEN:
            action.len = va_arg(args, int);
            action.action = SUBST_HKEY;
            break;
        case SUBST_VALUE_ARR_LEN:
            action.len = va_arg(args, int);
            action.action = SUBST_VALUE_ARR;
            break;
        default:
            break;
        }

        /* Now we know what to do and have advanced fp appropriately */
        /* Perform action, i.e., expand or copy */
        switch (action.action) {
        case COPY:
            *dp = current;
            STEP(1);
            break;
        case SUBST_INT:
            n = confd_snprintf(dp, dstsz, "%d", va_arg(args, int));
            STEP(n);
            break;
        case SUBST_UINT:
            n = confd_snprintf(dp, dstsz, "%u", va_arg(args, unsigned int));
            STEP(n);
            break;
        case SUBST_STRING:
            n = confd_snprintf(dp, dstsz, "%s", va_arg(args, char *));
            STEP(n);
            break;
        case SUBST_IP4:
            n = format_ip4(dp, dstsz, va_arg(args, struct in_addr *));
            STEP(n);
            break;
        case SUBST_IP6:
            n = format_ip6(dp, dstsz, va_arg(args, struct in6_addr *));
            STEP(n);
            break;
        case SUBST_VALUE_ARR: {
            int nxkeys = action.len;
            vp = va_arg(args, confd_value_t *);
            for (int i = 0; i < nxkeys; i++, vp++) {
                /* string type keys must always be sent in string form */
                if (keybeg != NULL &&
                    vp->type != C_BUF && vp->type != C_STR) {
                    /* add string-form key(s) to tuple before value-key */
                    /* Trim space from both ends */
                    char *bp = keybeg+1;
                    char *ep = dp;

                    while (bp < dp && isspace(*bp)) bp++;
                    while (ep > bp && isspace(*(ep-1))) ep--;
                    if (bp != ep) {
                        keyparts[nkeys].type = STRKEY;
                        keyparts[nkeys].data.keystr.beg = bp;
                        keyparts[nkeys].data.keystr.len = ep-bp;
                        nkeys++;
                    }
                    keybeg = dp - 1;
                    keyparts[nkeys].type = VALUE_PTR;
                    keyparts[nkeys].data.vp = vp;
                    nkeys++;
                    if (nkeys >= MAXKEYLEN) {
                        error = KEYLEN_OVERFLOW;
                        SAFE_RET2(badret);
                    }
                } else {
                    if (i > 0) {
                        n = confd_snprintf(dp, dstsz, " ");
                        STEP(n);
                    }
                    n = format_x(dp, dstsz, vp, keybeg != NULL);
                    STEP(n);
                }
            }
            break;
        }
        case SUBST_HKEY: {
            rel = 0;
            kp = va_arg(args, confd_hkeypath_t *);
            int len = kp->len;
            int kplen = (action.len == 0 ? len : action.len);

            /* This is unrolled from hkeypath_to_eterm_arr */
            u_int32_t hns = 0, newns;
            for (int i = len-1; i >= len - kplen; i--) {
                confd_value_t *vptr = &kp->v[i][0];
                if (vptr->type == C_XMLTAG) {
                    newns = CONFD_GET_XMLTAG_NS(vptr);
                    if (newns != 0 && newns != hns) {
                        hns = newns;
                        elems[*npelem].type = EH_TAG;
                        elems[*npelem].val.htag.hns = hns;
                        elems[*npelem].val.htag.htag = CONFD_GET_XMLTAG(vptr);
                        (*npelem)++;
                    } else {
                        elems[*npelem].type = EH_TAG;
                        elems[*npelem].val.htag.hns = 0;
                        elems[*npelem].val.htag.htag = CONFD_GET_XMLTAG(vptr);
                        (*npelem)++;
                    }
                }
                else {          /* It's a key */
                    int klen = 0;
                    while (kp->v[i][klen].type != C_NOEXISTS)
                        klen++;

                    elems[*npelem].type = E_KEY;
                    elems[*npelem].val.key.keylen = klen;

                    for (int j = 0; j < klen; j++) {
                        confd_value_t *vp = &kp->v[i][j];
                        if (vp->type == C_BUF || vp->type == C_STR) {
                            int sz = pp_keyval(keybuf, keybufsz, vp, hns);
                            /* FIXME Add error checking */
                            /* char buf[256], *bp = buf; */
                            /* int sz = pp_keyval(bp, sizeof(buf), vp, hns); */
                            /* if (sz >= sizeof(buf)) { */
                            /*     if ((bp = confd_malloc(sz+1)) == NULL) */
                            /*         return NULL; */
                            /*     pp_keyval(bp, sz+1, vp, hns); */
                            /* } */
                            /* if (bp != buf) */
                            /*     free(bp); */
                            elems[*npelem].val.key.keyparts[j].type = STRKEY;
                            elems[*npelem].val.key.keyparts[j].data.keystr.beg
                                = keybuf;
                            elems[*npelem].val.key.keyparts[j].data.keystr.len
                                = sz;
                            keybuf += sz;
                        } else {
                            elems[*npelem].val.key.keyparts[j].type = VALUE_PTR;
                            elems[*npelem].val.key.keyparts[j].data.vp = vp;
                            /* FIXME error check needed here? */
                            /* if ((ktup[klen] = val_to_term(vp))==NULL) */
                            /*     return -1; */
                        }
                    }
                    (*npelem)++;
                }
            }

            if (elems[*npelem-1].type == E_KEY)
                /* Register that expanded path ended with key */
                got_key = 2;
            break;
        }
        default:
            // Just to cover case for SUBST_HKEY_LEN and
            // SUBST_VALUE_ARR_LEN which will never happen.
            break;
        }

        if (dstsz <= 0) {
            /* Overflow! */
            error = DEST_OVERFLOW;
            SAFE_RET2(badret);
        }

        /* Set rel to reflect whether the first character is '/'.  We
         * possibly shouldn't need to this for every chunk, but it can
         * actually change during parsing as well. */
        if (rel == -1) {
            if (*s == '/') {
                rel = 0;
                s++;
                beg = s;
            } else {
                rel = 1;
            }
        }

        /* Parse the result produced so far */

        while (s < dp) {
            if (got_key == 2) {
                /* slash after [N] or {key(s)} is (required and) consumed */
                if (*s != '/')
                    SAFE_RET2(badret);
                got_key = 1;
                s++;
                beg = s;
                continue;
            }
            else if (lbrack != NULL) {
                /* Inside [..] -- advance until we see closing ']' */
                /* collecting [N] */
                if (*s == ']') {
                    char *p;
                    char ibuf[64];
                    int ibufsz = 0;

                    p = lbrack + 1;

                    /* Skip space */
                    while (isspace(*p)) p++;
                    if (!isdigit(*p)) {
                        error = INDEX_JUNK;
                        SAFE_RET2(badret);
                    }

                    while (isdigit(*p)) {
                        if (ibufsz >= sizeof(ibuf) - 1) {
                            error = INDEX_TOO_LONG;
                            SAFE_RET2(badret);
                        }
                        ibuf[ibufsz++] = *p++;
                    }
                    ibuf[ibufsz] = 0;
                    elems[*npelem].type = E_INDEX;
                    elems[*npelem].val.index = atoi(ibuf);
                    (*npelem)++;
                    /* Only space allowed after digits */
                    while (p < s) {
                        if (!isspace(*p)) {
                            error = INDEX_JUNK;
                            SAFE_RET2(badret);
                        }
                        p++;
                    }
                    lbrack = NULL;
                    got_key = 2;
                }
                s++;
                continue;
            }
            else if (keybeg != NULL) {
                /* Inside {..} - advance until we see closing '}' */
                /* collecting {key(s)} */
                switch (in_quote) {
                case NO_QUOTE: /* no quote - look for '}' or double quote */
                    switch (*s) {
                    case '}': {
                        /* Trim space from both ends */
                        char *bp = keybeg+1;
                        char *ep = s;

                        while (bp < s && isspace(*bp)) bp++;
                        while (ep > bp && isspace(*(ep-1))) ep--;
                        if (bp != ep) {
                            keyparts[nkeys].type = STRKEY;
                            keyparts[nkeys].data.keystr.beg = bp;
                            keyparts[nkeys].data.keystr.len = ep-bp;
                            nkeys++;
                        }
                        if (nkeys >= MAXKEYLEN)
                            SAFE_RET2(badret);
                        keybeg = NULL;
                        if (nkeys == 0) /* no keys */
                            SAFE_RET2(badret);
                        /* Now, make the key values */
                        elems[*npelem].type = E_KEY;
                        elems[*npelem].val.key.keylen = nkeys;
                        for (int i = 0; i < nkeys; i++) {
                            elems[*npelem].val.key.keyparts[i] = keyparts[i];
                        }
                        (*npelem)++;
                        nkeys = 0;
                        got_key = 2;
                        break;
                    }
                    case '"':
                        in_quote = IN_QUOTE;
                        break;
                    }
                    break;
                case IN_QUOTE: /* in double quote - look for end or backslash */
                    switch (*s) {
                    case '"':
                        in_quote = NO_QUOTE;
                        break;
                    case '\\':
                        in_quote = BS_QUOTE;
                        break;
                    }
                    break;
                case BS_QUOTE:  /* in backslash quote - don't look */
                    in_quote = IN_QUOTE;
                    break;
                }
                s++;
                continue;
            }
            else {
                /* parsing elems */
                switch (*s) {
                case ':':
                    if (beg != NULL) {
                        if (s == beg) /* empty prefix */
                            SAFE_RET2(badret);
                        nsptr.chars = beg;
                        nsptr.len = s - beg;
                    }
                    beg = s + 1;
                    break;
                case '/':
                    if (beg != NULL) {
                        if (s == beg && nsptr.chars != NULL)
                            /* prefix w/o elem */
                            SAFE_RET2(badret);
                        if (s > beg) {
                            elems[*npelem].type = E_TAG;
                            elems[*npelem].val.tag.ns = nsptr;
                            elems[*npelem].val.tag.tag.chars = beg;
                            elems[*npelem].val.tag.tag.len = s - beg;
                            (*npelem)++;
                        }
                    }
                    nsptr.chars = NULL;
                    nsptr.len = 0;
                    beg = s + 1;
                    break;
                case '[':
                    if (got_key)
                        SAFE_RET2(badret);
                    if (beg != NULL) {
                        if (s == beg && nsptr.chars != NULL)
                            /* prefix w/o elem */
                            SAFE_RET2(badret);
                        if (s > beg) {
                            elems[*npelem].type = E_TAG;
                            elems[*npelem].val.tag.ns = nsptr;
                            elems[*npelem].val.tag.tag.chars = beg;
                            elems[*npelem].val.tag.tag.len = s - beg;
                            (*npelem)++;
                        }
                    }
                    nsptr.chars = NULL;
                    nsptr.len = 0;
                    beg = NULL;
                    lbrack = s;
                    break;
                case '{':
                    if (got_key)
                        SAFE_RET2(badret);
                    if (beg != NULL) {
                        if (s == beg && nsptr.chars != NULL) {
                            /* prefix w/o elem */
                            error = NO_PREFIX;
                            SAFE_RET2(badret);
                        }
                        if (s > beg) {
                            elems[*npelem].type = E_TAG;
                            elems[*npelem].val.tag.ns = nsptr;
                            elems[*npelem].val.tag.tag.chars = beg;
                            elems[*npelem].val.tag.tag.len = s - beg;
                            (*npelem)++;
                        }
                    }
                    nsptr.chars = NULL;
                    nsptr.len = 0;
                    beg = NULL;
                    keybeg = s;
                    break;
                }
                got_key = 0;
                s++;
                continue;
            }

        }

    }

    /* Parse error, since we an unterminated index or key. */
    if (lbrack != NULL || keybeg != NULL) {
            /* premature end */
            error = KEY_UNTERM;
            SAFE_RET2(badret);
        }

    if (beg != NULL && s - beg > 0) {
        elems[*npelem].type = E_TAG;
        elems[*npelem].val.tag.ns = nsptr;
        elems[*npelem].val.tag.tag.chars = beg;
        elems[*npelem].val.tag.tag.len = s - beg;
        (*npelem)++;
    } else if (nsptr.chars != NULL) {
        /* trailing prefix - formally an error, but ignore for now
           must be freed since it isn't included in the path though */
        /* FIXME Is there anything to free? */
    }

   *isrel = rel > 0;
   return CONFD_OK;

badret:
   /* This is bogus, just to make error used */
   if (error != 0)
       confd_set_errno(error);
    confd_set_errno(CONFD_ERR_BADPATH);
    return CONFD_ERR;
    // FIXME We need to return error code here
    //return NULL;
}

/* New, refactored implementation of parse_path */
ETERM *parse_path(int *i_isrel, const char *fmt, va_list args)
{
    path_elem elems[256];
    int npelem = 0;
    ETERM *xresult[256];
    ETERM *keytup[MAXKEYLEN+2];
    char dst[BUFSIZ];
    int dstsz = sizeof(dst);
    char hk_keybuf[2048];
    int keybufsz = sizeof(hk_keybuf);
    int ekeys = 0;
    int eelems = 0;
    bool isrel;

    /* Initial special case */
    if ((fmt == NULL) || (*fmt == '\000')) {
        *i_isrel = 1;
        xresult[0] = erl_mk_atom(".");
        return erl_mk_list(xresult, 1);
    }

    if (parse_path_aux(
            &isrel, fmt, args, elems, &npelem,
            dst, dstsz, hk_keybuf, keybufsz) != CONFD_OK)
        return NULL;
    *i_isrel = isrel ? 1 : 0;

    /* if (nelem != npelem) */
    /*   printf("ERR: nelem!=npelem: %i!=%i\n", nelem, npelem); */

    /* Now construct list from elems */
    for (int i = 0; i < npelem; i++) {
        switch (elems[i].type) {
        case E_KEY: {
            int nkeys = elems[i].val.key.keylen;
            for (int j = 0; j < nkeys; j++) {
                keytype type = elems[i].val.key.keyparts[j].type;
                keytup[j] =
                    (type == STRKEY
                     ? erl_mk_binary(
                         elems[i].val.key.keyparts[j].data.keystr.beg,
                         //keyparts[i].data.keystr.beg +
                         elems[i].val.key.keyparts[j].data.keystr.len)
                     : type == VALUE_PTR
                     ? val_to_term(elems[i].val.key.keyparts[j].data.vp)
                     : NULL);
                if (keytup[j] == NULL) {
                    ekeys = j;
                    eelems = i;
                    xresult[i] = NULL;
                    goto badret;
                }
            }
            xresult[i] = erl_mk_tuple(keytup, nkeys);
            break;
        }
        case E_TAG: {
            ETERM *tag = erl_mk_eatom(elems[i].val.tag.tag.chars,
                                      elems[i].val.tag.tag.len);
            xresult[i] =
                elems[i].val.tag.ns.chars == NULL ? tag
                : erl_cons(erl_mk_eatom(elems[i].val.tag.ns.chars,
                                        elems[i].val.tag.ns.len),
                           tag);
            break;
        }
        case EH_TAG: {
            ETERM *tag = erl_mk_uint(elems[i].val.htag.htag);
            xresult[i] =
                elems[i].val.htag.hns == 0 ? tag
                : erl_cons(erl_mk_uint(elems[i].val.htag.hns), tag);
            break;
        }
        case E_INDEX: {
            ETERM *dlist[1];
            dlist[0] = erl_mk_int(elems[i].val.index);
            xresult[i] = erl_mk_list(dlist, 1);
            break;
        }
        default:
            printf("unhandled type: %i\n", elems[i].type);
            xresult[i] = NULL;
            goto badret;
        }
    }
    return erl_mk_list(xresult, npelem);

 badret:
    for(int i = 0; i < ekeys; i++)
      erl_free_compound(keytup[i]);
    for(int i = 0; i < eelems; i++)
      erl_free_compound(xresult[i]);
    return NULL;
}

int parse_path_ei(ei_x_buff *exbuf, bool *isrel, const char *fmt, va_list args)
{
    path_elem elems[256];
    int npelem = 0;
    char dst[BUFSIZ];
    int dstsz = sizeof(dst);
    char hk_keybuf[2048];
    int keybufsz = sizeof(hk_keybuf);
    int ret;

    /* Initial special case */
    if ((fmt == NULL) || (*fmt == '\000')) {
        *isrel = true;
        BADTERM_IF(ei_x_encode_list_header(exbuf, 1) != 0);
        BADTERM_IF(ei_x_encode_atom(exbuf, ".") != 0);
        BADTERM_IF(ei_x_encode_empty_list(exbuf) != 0);
        ret = CONFD_OK;
        SAFE_RET();
    }

    ret = parse_path_aux(isrel, fmt, args, elems, &npelem,
                         dst, dstsz, hk_keybuf, keybufsz);
    SAFE_RET_IF(ret != CONFD_OK);

    if (npelem == 0) goto emptylist;

    /* Now construct list from elems */
    BADTERM_IF(ei_x_encode_list_header(exbuf, npelem) != 0);

    for (int i = 0; i < npelem; i++) {
        switch (elems[i].type) {
        case E_KEY: {
            int nkeys = elems[i].val.key.keylen;
            BADTERM_IF(ei_x_encode_tuple_header(exbuf, nkeys) != 0);
            for (int j = 0; j < nkeys; j++) {
                keytype type = elems[i].val.key.keyparts[j].type;
                switch (type) {
                case STRKEY:
                    BADTERM_IF(
                        ei_x_encode_binary(
                            exbuf,
                            elems[i].val.key.keyparts[j].data.keystr.beg,
                            elems[i].val.key.keyparts[j].data.keystr.len) != 0);
                    break;
                case VALUE_PTR:
                    BADTERM_IF(val_to_term_ei(
                                   exbuf,
                                   elems[i].val.key.keyparts[j].data.vp) != 0);
                    break;
                default:
                    /* error */
                    BADTERM();
                    break;
                }
            }
            break;
        }
        case E_TAG: {
            if (elems[i].val.tag.ns.chars == NULL) {
                BADTERM_IF(ei_x_encode_atom_len(exbuf,
                                                elems[i].val.tag.tag.chars,
                                                elems[i].val.tag.tag.len) != 0);
            } else {
                BADTERM_IF(ei_x_encode_list_header(exbuf, 1) != 0);
                BADTERM_IF(ei_x_encode_atom_len(exbuf,
                                                elems[i].val.tag.ns.chars,
                                                elems[i].val.tag.ns.len) != 0);
                BADTERM_IF(ei_x_encode_atom_len(exbuf,
                                                elems[i].val.tag.tag.chars,
                                                elems[i].val.tag.tag.len) != 0);
            }
            break;
        }
        case EH_TAG: {
            unsigned long tag = elems[i].val.htag.htag;
            if (elems[i].val.htag.hns == 0) {
                BADTERM_IF(ei_x_encode_ulong(exbuf, tag) != 0);
            } else {
                BADTERM_IF(ei_x_encode_list_header(exbuf, 1) != 0);
                BADTERM_IF(
                    ei_x_encode_ulong(exbuf, elems[i].val.htag.hns) != 0);
                BADTERM_IF(ei_x_encode_ulong(exbuf, tag) != 0);
            }
            break;
        }
        case E_INDEX: {
            BADTERM_IF(ei_x_encode_list_header(exbuf, 1) != 0);
            BADTERM_IF(ei_x_encode_long(exbuf, elems[i].val.index) != 0);
            BADTERM_IF(ei_x_encode_empty_list(exbuf) != 0);
            break;
        }
        default:
            printf("unhandled type: %i\n", elems[i].type);
            BADTERM();
            break;
        }
    }

emptylist:
    BADTERM_IF(ei_x_encode_empty_list(exbuf) != 0);
    ret = CONFD_OK;

saferet:
    return ret;
}

ETERM *parse_path_old(int *isrel, const char *fmt, va_list args)
{
    int n;
    int rel = -1;
    ETERM *result[256];
    int nelem = 0;
    ETERM *keytup[MAXKEYLEN+2];
    int nkeys = 0;
    const char *fp = fmt;
    char dst[BUFSIZ];
    char *dp = dst;
    int dstsz = sizeof(dst);
    char *s = dst;
    char *beg = dst;
    ETERM *ns = NULL;
    char *lbrack = NULL;
    char *keybeg = NULL;
    int got_key = 0;
    int in_quote = 0;
    confd_value_t *vp;
    confd_hkeypath_t *kp;

    if ((fp == NULL) || (*fp == '\000')) {
        *isrel = 1;
        result[0] = erl_mk_atom(".");
        return erl_mk_list(result, 1);
    }

    while (isspace(*fp)) fp++;

    while (*fp != '\0') {

        /* expand % substition or copy one char from fmt */

        if (*fp == '%') {

            if (*(fp+1) == 'd') {
                fp += 2;
                n = confd_snprintf(dp, dstsz, "%d", va_arg(args, int));
                dp += n;
                dstsz -= n;
            }
            else if (*(fp+1) == 'u') {
                fp += 2;
                n = confd_snprintf(dp, dstsz, "%u", va_arg(args, unsigned int));
                dp += n;
                dstsz -= n;
            }
            else if (*(fp+1) == 's') {
                fp += 2;
                n = confd_snprintf(dp, dstsz, "%s", va_arg(args, char *));
                dp += n;
                dstsz -= n;
            }
            else if (strncmp(fp, "%ip4", 4) == 0) {
                fp += 4;
                n = format_ip4(dp, dstsz, va_arg(args, struct in_addr *));
                dp += n;
                dstsz -= n;
            }
            else if (strncmp(fp, "%ip6", 4) == 0) {
                fp += 4;
                n = format_ip6(dp, dstsz, va_arg(args, struct in6_addr *));
                dp += n;
                dstsz -= n;
            }
            else if (*(fp+1) == 'x' || strncmp(fp, "%*x", 3) == 0) {
                int nxkeys, i;
                if (*(fp+1) == 'x') {
                    fp += 2;
                    nxkeys = 1;
                } else {
                    fp += 3;
                    nxkeys = va_arg(args, int);
                }
                vp = va_arg(args, confd_value_t *);
                for (i = 0; i < nxkeys; i++, vp++) {
                    /* string type keys must always be sent in string form */
                    if (keybeg != NULL &&
                        vp->type != C_BUF && vp->type != C_STR) {
                        /* add string-form key(s) to tuple before value-key */
                        if ((keytup[nkeys] = mk_str_key(keybeg+1, dp)) != NULL)
                            nkeys++;
                        keybeg = dp - 1;
                        if ((keytup[nkeys] = val_to_term(vp)) == NULL)
                            goto badret;
                        nkeys++;
                        if (nkeys >= MAXKEYLEN)
                            goto badret;
                    } else {
                        if (i > 0) {
                            n = confd_snprintf(dp, dstsz, " ");
                            dp += n;
                            dstsz -= n;
                        }
                        n = format_x(dp, dstsz, vp, keybeg != NULL);
                        dp += n;
                        dstsz -= n;
                    }
                }
            }
            else if (dp == dst && *(fp+1) == 'h') {
                fp += 2;
                rel = 0;
                kp = va_arg(args, confd_hkeypath_t *);
                if (hkeypath_to_eterm_arr(kp, &result[nelem], kp->len, 1) !=
                    kp->len)
                    goto badret;
                nelem += kp->len;
                if (ERL_IS_TUPLE(result[nelem-1]))
                    got_key = 2;
            }
            else if (dp == dst && strncmp(fp, "%*h", 3) == 0) {
                int kp_len = va_arg(args, int);
                fp += 3;
                rel = 0;
                kp = va_arg(args, confd_hkeypath_t *);
                if (hkeypath_to_eterm_arr(kp, &result[nelem], kp_len, 1) !=
                    kp_len)
                    goto badret;
                nelem += kp_len;
                if (ERL_IS_TUPLE(result[nelem-1]))
                    got_key = 2;
            }
            else {
                *dp++ = *fp++;
                dstsz--;
            }

        } else {

            *dp++ = *fp++;
            dstsz--;

        }

        if (dstsz <= 0)
            goto badret;

        if (rel == -1) {
            if (*s == '/') {
                rel = 0;
                s++;
                beg = s;
            } else {
                rel = 1;
            }
        }

        /* parse the result produced so far */

        while (s < dp) {
            if (got_key == 2) {
                /* slash after [N] or {key(s)} is (required and) consumed */
                if (*s != '/')
                    goto badret;
                got_key = 1;
                s++;
                beg = s;
                continue;
            }
            else if (lbrack != NULL) {
                /* collecting [N] */
                if (*s == ']') {
                    char *p;
                    char ibuf[64];
                    int ibufsz = 0;
                    ETERM *dlist[1];

                    p = lbrack + 1;
                    while (isspace(*p)) p++;
                    if (!isdigit(*p))
                        goto badret;

                    while (isdigit(*p)) {
                        if (ibufsz >= sizeof(ibuf) - 1)
                            goto badret;
                        ibuf[ibufsz++] = *p++;
                    }
                    ibuf[ibufsz] = 0;
                    dlist[0] = erl_mk_int(atoi(ibuf));
                    result[nelem++] = erl_mk_list(dlist, 1);
                    while (p < s) {
                        if (!isspace(*p))
                            goto badret;
                        p++;
                    }
                    lbrack = NULL;
                    got_key = 2;
                }
                s++;
                continue;
            }
            else if (keybeg != NULL) {
                /* collecting {key(s)} */
                switch (in_quote) {
                case 0:       /* no quote - look for '}' or double quote */
                    switch (*s) {
                    case '}':
                        if ((keytup[nkeys] = mk_str_key(keybeg+1, s)) != NULL)
                            nkeys++;
                        if (nkeys >= MAXKEYLEN)
                            goto badret;
                        keybeg = NULL;
                        if (nkeys == 0) /* no keys */
                            goto badret;
                        result[nelem++] = erl_mk_tuple(keytup, nkeys);
                        nkeys = 0;
                        got_key = 2;
                        break;
                    case '"':
                        in_quote = 1;
                        break;
                    }
                    break;
                case 1:       /* in double quote - look for end or backslash */
                    switch (*s) {
                    case '"':
                        in_quote = 0;
                        break;
                    case '\\':
                        in_quote = 2;
                        break;
                    }
                    break;
                case 2:       /* in backslash quote - don't look */
                    in_quote = 1;
                    break;
                }
                s++;
                continue;
            }
            else {
                /* parsing elems */
                switch (*s) {
                case ':':
                    if (beg != NULL) {
                        if (s == beg) /* empty prefix */
                            goto badret;
                        ns = erl_mk_eatom(beg, s - beg);
                    }
                    beg = s + 1;
                    break;
                case '/':
                    if (beg != NULL) {
                        if (s == beg && ns != NULL) /* prefix w/o elem */
                            goto badret;
                        if (s > beg)
                            result[nelem++] = mk_tag_elem(ns, beg, s - beg);
                    }
                    ns = NULL;
                    beg = s + 1;
                    break;
                case '[':
                    if (got_key)
                        goto badret;
                    if (beg != NULL) {
                        if (s == beg && ns != NULL) /* prefix w/o elem */
                            goto badret;
                        if (s > beg)
                            result[nelem++] = mk_tag_elem(ns, beg, s - beg);
                    }
                    ns = NULL;
                    beg = NULL;
                    lbrack = s;
                    break;
                case '{':
                    if (got_key)
                        goto badret;
                    if (beg != NULL) {
                        if (s == beg && ns != NULL) /* prefix w/o elem */
                            goto badret;
                        if (s > beg)
                            result[nelem++] = mk_tag_elem(ns, beg, s - beg);
                    }
                    ns = NULL;
                    beg = NULL;
                    keybeg = s;
                    break;
                }
                got_key = 0;
                s++;
                continue;
            }

        }

    }

    if (lbrack != NULL || keybeg != NULL) /* premature end */
        goto badret;

    if (beg != NULL && s - beg > 0) {
        result[nelem++] = mk_tag_elem(ns, beg, s - beg);
    } else if (ns != NULL) {
        /* trailing prefix - formally an error, but ignore for now
           must be freed since it isn't included in the path though */
        erl_free_compound(ns);
    }
    *isrel = rel;
    return erl_mk_list(result, nelem);

badret:
    for (nkeys--; nkeys >= 0; nkeys--) {
        if (keytup[nkeys] != NULL)
            erl_free_compound(keytup[nkeys]);
    }
    if (ns != NULL)
        erl_free_compound(ns);
    for (nelem--; nelem >= 0; nelem--)
        erl_free_compound(result[nelem]);
    confd_set_errno(CONFD_ERR_BADPATH);
    return NULL;
}

ETERM *_confd_parse_choice_path(const char *path)
{
    const char *p = path, *q, *r;
    ETERM *list[256], *ns, *res;
    int i = 0;

    if (*p == '/') {
        ret_err(CONFD_ERR_BADPATH, "Choice path cannot start with '/'");
        return NULL;
    }
    do {
        if ((q = strchr(p, '/')) == NULL)
            q = strchr(p, '\0');
        if ((r = strchr(p, ':')) != NULL && r < q) {
            if ((ns = erl_mk_eatom(p, r - p)) == NULL)
                goto bad;
            p = r + 1;
        } else {
            ns = NULL;
        }
        if ((list[i] = mk_tag_elem(ns, p, q - p)) == NULL)
            goto bad;
        i++;
        p = q + 1;
    } while (i < 256 && *q != '\0');
    if ((res = erl_mk_list(list, i)) == NULL)
        goto bad;
    return res;

bad:
    while (i > 0) {
        erl_free_compound(list[i]);
        i--;
    }
    ret_err(CONFD_ERR_MALLOC, "Cannot allocate");
    return NULL;
}

/* FIXME merge with pp_keyval to avoid code duplication */
int keyval2str(struct confd_type *type, const confd_value_t *v,
               char *buf, int n)
{
    int len = CONFD_ERR;
    char *s = buf;
    struct confd_type_ctx ctx = {NULL, 0, NULL};
    int nquot, nesc, qlen;
    int i, j;

    /* Don't try to convert C_BUF or C_STR values, causes bogus error with
       STRINGSONLY - return CONFD_ERR to make caller fall back to pp_keyval() */
    /* Use type->val_to_str() directly to avoid error msg from confd_val2str()
       if schema not loaded or user-defined type not registered */
    if (v->type != C_BUF && v->type != C_STR)
        len = type->val_to_str(type, &ctx, v, buf, n < 0 ? 0 : n, NULL);
    if (len < 0)
        return len;

    {
        char tmpbuf[len+1];

        if (len >= n) {
            /* need the full string to determine quoted length */
            confd_val2str(type, v, tmpbuf, sizeof(tmpbuf));
            s = tmpbuf;
        }

        /* need quoting if it's a null string, or if there is
           whitespace, right-braces, quotes, or backslashes - if quoting,
           need to backslash-escape quotes and backslashes */
        if (len == 0) {
            qlen = 2;
        } else {
            for (i = 0, nquot = 0, nesc = 0; i < len; i++) {
                switch (s[i]) {
                case ' ': case '}': case '\t': case '\r':
                case '\n': case '\f': case '\v': case '\b':
                    nquot++; break;
                case '"': case '\\':
                    nesc++; break;
                }
            }
            if (nquot + nesc == 0)
                qlen = len;
            else
                qlen = len + 2 + nesc;
        }
        /* normal case */
        if (qlen == len)
            return len;

        if (s != tmpbuf) {
            /* need a copy since we will write to buf */
            memcpy(tmpbuf, buf, len);
        }
        i = j = 0;
        if (j < n - 1)
            buf[j++] = '"';
        while (i < len && j < n - 1) {
            if (tmpbuf[i] == '"' || tmpbuf[i] == '\\')
                buf[j++] = '\\';
            if (j < n - 1)
                buf[j++] = tmpbuf[i++];
        }
        if (j < n - 1)
            buf[j++] = '"';
        if (j < n)
            buf[j] = '\0';
    }

    return qlen;
}

/* pretty-print the initial 'len' elements of a hkeypath to buf */
/* returns int as snprinf() */
int confd_pp_kpath_len(char *buf, int n, const confd_hkeypath_t *hkeypath,
                       int kp_len)
{
    int tmplen = 0;
    int pos;
    int ns = -1;
    int len = 0;
    const confd_value_t *v;

    if (n < 0)
        n = 0;

    if (kp_len == 0)
        return confd_snprintf(buf, n, "/");

    /* Find the ns for the hkeypath */
    for (pos=hkeypath->len-1 ; pos >= 0 ; pos--) {
        v = &(hkeypath->v[pos][0]);
        if (v->type == C_XMLTAG && v->val.xmltag.ns != 0 ) {
            ns = v->val.xmltag.ns;
            break;
        }
    }

    for (pos=hkeypath->len-1; pos >= hkeypath->len - kp_len ; pos--) {
        const confd_value_t *v = &(hkeypath->v[pos][0]);
        if (v->type == C_XMLTAG) {
            if (v->val.xmltag.ns != 0 && v->val.xmltag.ns != ns)
                ns = v->val.xmltag.ns;
            tmplen = confd_snprintf(buf, n, "/");
            len += tmplen;
            buf += tmplen;
            n -= tmplen;
            tmplen = confd_pp_value(buf, n, v);
            len += tmplen;
            buf += tmplen;
            n -= tmplen;
        }
        else if (v->type == C_NOEXISTS) {
            /* empty key value (for chk_data_access() callback) */
            tmplen = confd_snprintf(buf, n, "{}");
            len += tmplen;
            buf += tmplen;
            n -= tmplen;
        }
        else {
            /* it's a key value */
            int i = 0;
            struct confd_cs_node *node;
            struct confd_cs_node *key = NULL;

            tmplen = confd_snprintf(buf, n, "{");
            len += tmplen;
            buf += tmplen;
            n -= tmplen;
            node = confd_find_cs_node(hkeypath, hkeypath->len - pos);

            if (node != NULL && node->info.keys != NULL)
                key = node->children;
            while (1) {
                tmplen = -1;
                if (key != NULL) {
                    if (key->info.type != NULL) {
                        tmplen = keyval2str(key->info.type, v, buf, n);
                    }
                    key = key->next;
                } else if (node != NULL &&
                           node->info.flags & CS_NODE_IS_LEAF_LIST) {
                    struct confd_type *type;
                    get_leaf_list_type(node, &type);
                    if (type != NULL) {
                        tmplen = keyval2str(type, v, buf, n);
                    }
                }

                /* fall back to non-schema-aware method */
                if (tmplen < 0) {
                    tmplen = pp_keyval(buf, n, v, ns);
                }

                len += tmplen;
                buf += tmplen;
                n -= tmplen;

                v = &(hkeypath->v[pos][++i]);
                if (v->type == C_NOEXISTS)
                    break;
                tmplen = confd_snprintf(buf, n, " ");
                len += tmplen;
                buf += tmplen;
                n -= tmplen;

            }
            tmplen = confd_snprintf(buf, n, "}");
            len += tmplen;
            buf += tmplen;
            n -= tmplen;
        }
    }
    return len;
}

static int xpath_keyval2str(struct confd_type *type, const confd_value_t *v,
                            char *buf, int n)
{
    int len, tmplen;
    char *s, *start_q = n > 0 ? buf : NULL;

    /* start quote, replace with ' if value contains " */
    confd_snprintf(buf, n, "\"");
    buf += 1; n -= 1;

    if (v->type == C_STR) {
        s = v->val.s;
        len = strlen(s);
        confd_strncpy(buf, n, v->val.s, len);
    } else if (v->type == C_BUF) {
        s = (char *)CONFD_GET_BUFPTR(v);
        len = CONFD_GET_BUFSIZE(v);
        confd_strncpy(buf, n, s, len);
    } else {
        s = buf;
        struct confd_type_ctx ctx = {NULL, 0, NULL};
        if (type == NULL) {
            /* fall back to non-schema-aware method */
            len = confd_pp_value(buf, n, v);
        } else {
            len = type->val_to_str(type, &ctx, v, buf, n < 0 ? 0 : n, NULL);
            if (len < 0) {
                /* fall back to non-schema-aware method */
                len = confd_pp_value(buf, n, v);
            }
        }
    }
    tmplen = n > len ? len : n;
    buf += len; n -= len;

    if (tmplen < 0 || memchr(s, '"', tmplen) == NULL) {
        confd_snprintf(buf, n, "\"");
    } else {
        if (start_q != NULL) {
            *start_q = '\'';
        }
        confd_snprintf(buf, n, "'");
    }

    return len + 2;
}

/* returns int as snprinf() */
int confd_xpath_pp_kpath(char *obuf, int n, u_int32_t ns,
                         const confd_hkeypath_t *hkeypath)
{
    char *buf = obuf;
    int tmplen = 0;
    int pos;
    int newns, oldns = 0;
    char *prefix;
    int j = 1;

    if (n < 0)
        n = 0;

    /* Find the ns for the hkeypath if not given */
    if (ns == 0) {
        const confd_value_t *v;
        for (pos=hkeypath->len-1; pos >= 0 && n > 0; pos--) {
            v = &(hkeypath->v[pos][0]);
            if (v->type == C_XMLTAG && v->val.xmltag.ns != 0 ) {
                ns = v->val.xmltag.ns;
                break;
            }
        }
    }

    /* traverse the keypath backwards */
    for (pos=hkeypath->len-1; pos >= 0; pos--, j++) {
        const confd_value_t *v = &(hkeypath->v[pos][0]);
        if (v->type == C_XMLTAG) {
            /* print ns prefix if (possibly) needed */
            if ((newns = CONFD_GET_XMLTAG_NS(v)) != 0) {
                if (newns != oldns && (prefix = confd_ns2prefix(newns)) != NULL)
                    tmplen = confd_snprintf(buf, n, "/%s:", prefix);
                else
                    tmplen = confd_snprintf(buf, n, "/");
                ns = oldns = newns;
            } else {
                tmplen = confd_snprintf(buf, n, "/");
            }
            buf += tmplen; n -= tmplen;
            tmplen = confd_pp_value(buf, n, v);
            buf += tmplen; n -= tmplen;
        }
        else if (v->type != C_NOEXISTS) { /* skip empty key elem */
            /* it's maybe a key value, we need to figure out the */
            /* name of the xml elem */
            int i = 0;
            uint32_t *keys;
            struct confd_cs_node *p;
            struct confd_cs_node *key = NULL;

            if ((p = confd_find_cs_node(hkeypath, j)) == NULL) {
                /* No such namespace schema loaded" */
                tmplen = confd_snprintf(buf, n, "[NONAMESPACELOADED]");
                buf += tmplen; n -= tmplen;
                continue;
            }

            tmplen = confd_snprintf(buf, n,
                                    (p->info.flags & CS_NODE_IS_LEAF_LIST)
                                    ? "[.=" : "[");
            buf += tmplen; n -= tmplen;

            keys = p->info.keys;
            if (keys == NULL) {
                if (p->info.flags & CS_NODE_IS_LEAF_LIST) {
                    struct confd_type *type;
                    get_leaf_list_type(p, &type);
                    tmplen = xpath_keyval2str(type, v, buf, n);
                } else {
                    /* assume keyless oper list (should have C_INT64 key) */
                    tmplen = confd_pp_value(buf, n, v);
                }
                buf += tmplen; n -= tmplen;
            } else {
                key = p->children;
                while (1) {
                    struct confd_type *type =
                        key == NULL ? NULL : key->info.type;
                    char *elemname = confd_hash2str(*keys++);
                    tmplen = confd_snprintf(buf, n, "%s=", elemname);
                    buf += tmplen; n -= tmplen;
                    tmplen = xpath_keyval2str(type, v, buf, n);
                    buf += tmplen; n -= tmplen;
                    if (key != NULL)
                        key = key->next;
                    v = &(hkeypath->v[pos][++i]);
                    if (v->type == C_NOEXISTS)
                        break;
                    tmplen = confd_snprintf(buf, n, "][");
                    buf += tmplen; n -= tmplen;
                }
            }

            tmplen = confd_snprintf(buf, n, "]");
            buf += tmplen; n -= tmplen;
        }
    }
    return (buf - obuf);
}


#define W() do {                                \
        if (wmode) {*dp++ = *fp++; dstsz--;}    \
        else {dp++; fp++; dstsz--;}             \
    } while (0)

#define CD() do {                                                       \
        if (beg != NULL && s > beg && (*beg == '/' || node != NULL)) {  \
            char c = *s;                                                \
            *s = '\0';                                                  \
            node = confd_cs_node_cd(node, beg);                         \
            *s = c;                                                     \
        }                                                               \
    } while (0)

/* like substitute_percent, but do proper val2str() on keys if possible */
int confd_vformat_keypath(char *buf, int bufsiz, const char *fmt, va_list args)
{
    int wmode = 1;   /* are we writing */
    int n;
    const char *fp = fmt;
    char *dp = buf;
    int dstsz = bufsiz;
    char *s = buf;
    char *beg = buf;
    char *lbrack = NULL;
    char *keybeg = NULL;
    int in_key = 0;
    int in_quote = 0;
    confd_value_t *vp;
    confd_hkeypath_t *kp;
    struct confd_cs_node *node = NULL, *key = NULL;

    if ((fp == NULL) || (*fp == '\0')) {
        if (dstsz > 0) {
            *dp = '\0';
        }
        return 0;
    }

    while (*fp != '\0') {

        if (dstsz <= 1) {
            wmode = 0;
            if (dstsz == 1) {
                *dp = '\0'; /* add final '\0' before bailing out */
            }
        }

        /* expand % substition or copy one char from fmt */

        if (*fp == '%') {

            if (*(fp+1) == 'd') {
                fp += 2;
                n = confd_snprintf(dp, dstsz, "%d", va_arg(args, int));
                dp += n;
                dstsz -= n;
            }
            else if (*(fp+1) == 'u') {
                fp += 2;
                n = confd_snprintf(dp, dstsz, "%u", va_arg(args, unsigned int));
                dp += n;
                dstsz -= n;
            }
            else if (*(fp+1) == 's') {
                fp += 2;
                n = confd_snprintf(dp, dstsz, "%s", va_arg(args, char *));
                dp += n;
                dstsz -= n;
            }
            else if (strncmp(fp, "%ip4", 4) == 0) {
                fp += 4;
                n = format_ip4(dp, dstsz, va_arg(args, struct in_addr *));
                dp += n;
                dstsz -= n;
            }
            else if (strncmp(fp, "%ip6", 4) == 0) {
                fp += 4;
                n = format_ip6(dp, dstsz, va_arg(args, struct in6_addr *));
                dp += n;
                dstsz -= n;
            }
            else if (*(fp+1) == 'x' || strncmp(fp, "%*x", 3) == 0) {
                int nxkeys, i;
                if (*(fp+1) == 'x') {
                    fp += 2;
                    nxkeys = 1;
                } else {
                    fp += 3;
                    nxkeys = va_arg(args, int);
                }
                vp = va_arg(args, confd_value_t *);
                for (i = 0; i < nxkeys; i++, vp++) {
                    n = -1;
                    if (key != NULL) {
                        if (key->info.type != NULL) {
                            n = keyval2str(key->info.type, vp, dp, dstsz);
                        }
                        key = key->next;
                    } else if (node != NULL &&
                               node->info.flags & CS_NODE_IS_LEAF_LIST) {
                        struct confd_type *type;
                        get_leaf_list_type(node, &type);
                        n = keyval2str(type, vp, dp, dstsz);
                    }

                    /* fall back to non-schema-aware method */
                    if (n < 0) {
                        n = pp_keyval(dp, dstsz, vp, 0);
                    }
                    dp += n;
                    dstsz -= n;
                    if (i < nxkeys - 1) {
                        n = confd_snprintf(dp, dstsz, " ");
                        dp += n;
                        dstsz -= n;
                    }
                }
                in_key = 0;
                s = dp;
            }
            else if (fp == fmt && *(fp+1) == 'h') {
                fp += 2;
                kp = va_arg(args, confd_hkeypath_t *);
                n = confd_pp_kpath(dp, dstsz, kp);
                node = confd_find_cs_node(kp, kp->len);
                dp += n;
                dstsz -= n;
                in_key = 0;
                beg = NULL;
                s = dp;
            }
            else if (fp == fmt && strncmp(fp, "%*h", 3) == 0) {
                int kp_len = va_arg(args, int);
                fp += 3;
                kp = va_arg(args, confd_hkeypath_t *);
                n = confd_pp_kpath_len(dp, dstsz, kp, kp_len);
                node = confd_find_cs_node(kp, kp_len);
                dp += n;
                dstsz -= n;
                in_key = 0;
                beg = NULL;
                s = dp;
            }
            else {
                W();
            }

        } else {

            W();

        }

        if (dstsz <= 0) {
            continue;
        }

        if (s == buf && *s == '/')
            s++;

        /* parse the result produced so far */

        while (s < dp) {

            if (lbrack != NULL) {
                /* collecting [N] */
                if (*s == ']') {
                    lbrack = NULL;
                }
                s++;
                continue;
            }
            else if (keybeg != NULL) {
                /* collecting {key(s)} */
                switch (in_quote) {
                case 0:         /* no quote - look for anything */
                    switch (*s) {
                    case ' ':
                        if (in_key && key != NULL) {
                            key = key->next;
                        }
                        in_key = 0;
                        break;
                    case '}':
                        keybeg = NULL;
                        key = NULL;
                        in_key = 0;
                        break;
                    case '"':
                        in_key = 1;
                        in_quote = 1;
                        break;
                    default:
                        in_key = 1;
                        break;
                    }
                    break;
                case 1:       /* in double quote - look for end or backslash */
                    switch (*s) {
                    case '"':
                        in_quote = 0;
                        break;
                    case '\\':
                        in_quote = 2;
                        break;
                    }
                    break;
                case 2:       /* in backslash quote - don't look */
                    in_quote = 1;
                    break;
                }
                s++;
                continue;
            }
            else {
                /* parsing elems */
                switch (*s) {
                case '/':
                    if (beg != NULL && s - beg == 1 && *beg == '/') {
                        /* repeated leading '/' */
                        beg = s;
                    } else {
                        CD();
                        beg = s + 1;
                    }
                    break;
                case '[':
                    CD();
                    beg = NULL;
                    lbrack = s;
                    break;
                case '{':
                    CD();
                    beg = NULL;
                    keybeg = s;
                    if (node != NULL && node->info.keys != NULL) {
                        key = node->children;
                    }
                    break;
                }
                s++;
                continue;
            }

        }

    }

    if (dstsz > 0) {
        *dp = '\0';
    }
    return dp - buf;

}

#undef W
#undef CD



static void cdb_trace(int isrel, int op, const ETERM *arg) {
    if (confd_debug_level >= CONFD_TRACE) {
        const ETERM *path = NULL;
        char *argstr = NULL;
        switch (op) {

            /* path in tuple elem 0 */
        case MAAPI_MOVE:
        case MAAPI_MOVE_ORDERED:
        case MAAPI_CLEAR_OPCACHE:
        case CDB_OP_GET_OBJECTS:
            path = TE(arg,0);
            break;

            /* path in tuple elem 1 */
        case MAAPI_GET_NEXT:
        case MAAPI_SET_ELEM:
        case MAAPI_SET_ELEM2:
        case MAAPI_GET_CASE:
        case MAAPI_SET_OBJECT:
        case MAAPI_GET_ATTRS:
        case MAAPI_SET_ATTR:
        case MAAPI_REQUEST_ACTION:
        case MAAPI_REQUEST_ACTION_TH:
        case MAAPI_AAA_RELOAD_PATH:
        case MAAPI_COPY_PATH:
        case CDB_OP_SET_ELEM:
        case CDB_OP_SET_ELEM2:
        case CDB_OP_SET_OBJECT:
        case CDB_OP_SET_VALUES:
        case CDB_OP_GET_VALUES:
        case CDB_OP_OPER_SUBSCRIBE:
        case CDB_OP_GET_CASE:
        case CDB_OP_SET_CASE:
            path = TE(arg,1);
            break;

            /* path in tuple elem 2 */
        case CDB_OP_SUBSCRIBE:
            path = TE(arg,2);
            break;

            /* no path but list arg */
        case MAAPI_START_USER_SESSION:
        case CDB_OP_TRIGGER_SUBS:
            path = NULL;
            break;

        case CDB_OP_SYNC_SUB:
            switch (ERL_IS_TUPLE(arg) ?
                    ERL_INT_VALUE(ERL_TUPLE_ELEMENT(arg,0)) :
                    ERL_INT_VALUE(arg)) {
            case CDB_DONE_PRIORITY: argstr = "CDB_DONE_PRIORITY"; break;
            case CDB_DONE_SOCKET: argstr = "CDB_DONE_SOCKET"; break;
            case CDB_DONE_TRANSACTION: argstr = "CDB_DONE_TRANSACTION"; break;
            case CDB_DONE_OPERATIONAL: argstr = "CDB_DONE_OPERATIONAL"; break;
            case 5: argstr = "CDB_ABORT"; break;
            default: argstr = "?"; break;
            }
            break;

        default:
            if (arg != NULL && !ERL_IS_LIST(arg))
                /* not a path */
                path = NULL;
            else
                /* arg is a path or NULL */
                path = arg;
        }
        confd_trace_printf("TRACE %s %s", _confd_op2str(op),
                           (path ? format_path(isrel, path) :
                            (argstr ? argstr : "")));
    }
}

ETERM  *op_request_term2(int sock, int op, int thandle, int isrel,
                         const ETERM *arg, int *status, int clr_err)
{
    unsigned int op2 = op;
    ETERM *ret;
    if (clr_err) {
        clr_confd_err();
    }
    if (isrel)
        op2 |= CDB_REL_FLAG_MASK;
    cdb_trace(isrel, op, arg);
    if (arg == NULL) {
        if ((*status = op_write(sock, op2, thandle)) != CONFD_OK) {
            cdb_ret_trace(*status, NULL);
            return NULL;
        }
    } else {
        if ((*status = term_write(sock, arg, op2, thandle)) != CONFD_OK) {
            cdb_ret_trace(*status, NULL);
            return NULL;
        }
    }
    ret = term_read(sock, status, op);
    if (ret != NULL && *status == CONFD_ERR) {
        unsigned char *estr = ERL_BIN_PTR(ret);
        cdb_ret_trace(CONFD_ERR, ret);
        confd_report_err(CONFD_DEBUG, "error: %s\n", estr);
        erl_free_compound(ret);
        return NULL;
    }
    cdb_ret_trace(*status, ret);
    return ret;
}


/* Assume beginning of tuple header. Skip n fields. */
int skip_n_terms_ei(const char *ebuf, int *eindex, int n)
{
    int arity;
    int i;

    if (ebuf == NULL) {
        *eindex = -1;
        return CONFD_ERR;
    }
    if (ei_decode_tuple_header(ebuf, eindex, &arity) != 0) {
        *eindex = -1;
        return CONFD_ERR;
    }
    if (n >= arity) {
        *eindex = -1;
        return CONFD_ERR;
    }
    for (i=0; i < n; i++) {
        if (ei_skip_term(ebuf, eindex) != 0) {
            *eindex = -1;
            return CONFD_ERR;
        }
    }
    return CONFD_OK;
}

static void cdb_trace_ei(int isrel, int op, const char *ebuf, int esize) {
    if (confd_debug_level >= CONFD_TRACE) {
        int pindex = 0;
        char *argstr = NULL;
        int etype;
        int elen;

        switch (op) {

            /* path in tuple elem 0 */
        case MAAPI_MOVE:
        case MAAPI_MOVE_ORDERED:
        case MAAPI_CLEAR_OPCACHE:
        case CDB_OP_GET_OBJECTS:
            skip_n_terms_ei(ebuf, &pindex, 0);
            break;

            /* path in tuple elem 1 */
        case MAAPI_GET_NEXT:
        case MAAPI_SET_ELEM:
        case MAAPI_SET_ELEM2:
        case MAAPI_GET_CASE:
        case MAAPI_SET_OBJECT:
        case MAAPI_GET_ATTRS:
        case MAAPI_SET_ATTR:
        case MAAPI_REQUEST_ACTION:
        case MAAPI_REQUEST_ACTION_TH:
        case MAAPI_AAA_RELOAD_PATH:
        case MAAPI_COPY_PATH:
        case CDB_OP_SET_ELEM:
        case CDB_OP_SET_ELEM2:
        case CDB_OP_SET_OBJECT:
        case CDB_OP_SET_VALUES:
        case CDB_OP_GET_VALUES:
        case CDB_OP_OPER_SUBSCRIBE:
        case CDB_OP_GET_CASE:
        case CDB_OP_SET_CASE:
            skip_n_terms_ei(ebuf, &pindex, 1);
            break;

            /* path in tuple elem 2 */
        case CDB_OP_SUBSCRIBE:
            skip_n_terms_ei(ebuf, &pindex, 2);
            break;

            /* no path but list arg */
        case MAAPI_START_USER_SESSION:
        case CDB_OP_TRIGGER_SUBS:
            pindex = -1;
            break;

        case CDB_OP_SYNC_SUB:
            if (ebuf != NULL) {
                ei_get_type(ebuf, &pindex, &etype, &elen);

                if (etype == ERL_SMALL_TUPLE_EXT ||
                    etype == ERL_LARGE_TUPLE_EXT) {
                    skip_n_terms_ei(ebuf, &pindex, 0);
                }
                long cdb_done;

                ei_decode_long(ebuf, &pindex, &cdb_done);
                switch (cdb_done) {
                case CDB_DONE_PRIORITY:   argstr = "CDB_DONE_PRIORITY";   break;
                case CDB_DONE_SOCKET:     argstr = "CDB_DONE_SOCKET";     break;
                case CDB_DONE_TRANSACTION:argstr = "CDB_DONE_TRANSACTION";break;
                case CDB_DONE_OPERATIONAL:argstr = "CDB_DONE_OPERATIONAL";break;
                case 5:                   argstr = "CDB_ABORT";           break;
                default:                  argstr = "?";                   break;
                }
            } else {
                argstr = "?";
            }
            break;
        default:
            if (ebuf != NULL) {
                ei_get_type(ebuf, &pindex, &etype, &elen);
                if (etype == ERL_LIST_EXT ||
                    etype == ERL_NIL_EXT) {
                    /* Keep pindex setting */
                } else {
                    pindex = -1;
                }
            } else {
                pindex = -1;
            }
        }
        confd_trace_printf("TRACE %s %s", _confd_op2str(op),
                           ((pindex != -1)
                            ? format_path_ei(isrel, ebuf, &pindex)
                            : (argstr ? argstr : "")));
    }
}

int op_request_term2_ei_ei(int sock, int op, int thandle, bool isrel,
                           const char *qbuf, int qsize,
                           char **ybuf, int *yindex,
                           int clr_err)
{
    unsigned int op2 = op;
    int ret;
    char *bin = NULL;

    BADTERM_IF(*ybuf != NULL);
    *yindex = 0;

    if (clr_err) clr_confd_err();
    if (isrel) op2 |= CDB_REL_FLAG_MASK;

    cdb_trace_ei(isrel, op, qbuf, qsize);

    if (qbuf == NULL || qsize == 0) {
        ret = op_write(sock, op2, thandle);
        SAFE_RET_IF2(traceret, ret != CONFD_OK);
    } else {
        ret = term_write_ei(sock, qbuf, qsize, op2, thandle);
        SAFE_RET_IF2(traceret, ret != CONFD_OK);
    }
    ret = term_read_ei(sock, ybuf, yindex, op);
    if (*ybuf != NULL && ret == CONFD_ERR) {
        /* FIXME Why go to the trouble of deconstructing ybuf when
         * there is an error? */
        int eversion;
        int pindex = 0;
        long sz = 0;

        SAFE_BADTERM_IF(ei_decode_version(*ybuf, &pindex, &eversion) != 0);
        SAFE_BADTERM_IF(
            decode_binary_ei(*ybuf, &pindex, &bin, &sz) != CONFD_OK);

        /* BUGBUG: Missing trailing NULL? */
        confd_report_err(CONFD_DEBUG, "error: %s\n", bin);
    }

    SAFE_RET_IF(ret != CONFD_OK);
    goto traceret;

saferet:
    free(bin);
    free(*ybuf);
    *ybuf = NULL;

traceret:
    cdb_ret_trace_ei(ret);
    return ret;
}

/* Convert initial 'len' elements of a hkeypath to Erlang terms
   in 'arr'. 'format_h' is for use with %h/%*h in CDB/MAAPI paths:
   elements in 'arr' should be in "forward order" and string type
   keys must be converted to string form (to get the right quoting) */
static int hkeypath_to_eterm_arr(confd_hkeypath_t *hkp, ETERM **arr,
                                 int len, int format_h)
{
    int j;
    confd_value_t *vptr;
    u_int32_t ns = 0, newns;

    /* traverse the keypath backwards */
    for(int i=hkp->len-1; i>=hkp->len-len; i--) {
        j = format_h ? hkp->len - i - 1 : i;
        vptr = &hkp->v[i][0];
        if (vptr->type == C_XMLTAG) {
            newns = CONFD_GET_XMLTAG_NS(vptr);
            if (newns != 0 && newns != ns) {
                ns = newns;
                arr[j] = erl_cons(
                    erl_mk_uint(ns),
                    erl_mk_uint(CONFD_GET_XMLTAG(vptr)));
            } else {
                arr[j] = erl_mk_uint(CONFD_GET_XMLTAG(vptr));
            }
        }
        else { /* its a key */
            int klen = 0;
            while (hkp->v[i][klen].type != C_NOEXISTS)
                klen++;
            {
                ETERM *ktup[klen];
                klen = 0;
                while (hkp->v[i][klen].type != C_NOEXISTS) {
                    confd_value_t *vp = &hkp->v[i][klen];
                    if (format_h && (vp->type == C_BUF || vp->type == C_STR)) {
                        char buf[256], *bp = buf;
                        int sz = pp_keyval(bp, sizeof(buf), vp, ns);
                        if (sz >= sizeof(buf)) {
                            if ((bp = confd_malloc(sz+1)) == NULL)
                                return -1;
                            pp_keyval(bp, sz+1, vp, ns);
                        }
                        ktup[klen] = erl_mk_binary(bp, sz);
                        if (bp != buf)
                            free(bp);
                    } else {
                        if ((ktup[klen] = val_to_term(vp))==NULL)
                            return -1;
                    }
                    klen++;
                }
                arr[j] = erl_mk_tuple(ktup, klen);
            }
        }
    }
    return len;
}

ETERM *hkeypath_to_eterm(confd_hkeypath_t *hkp)
{
    ETERM *hlist[hkp->len];

    if (hkeypath_to_eterm_arr(hkp, hlist, hkp->len, 0) != hkp->len)
        return NULL;
    return erl_mk_list(hlist, hkp->len);
}

/* Convert initial 'len' elements of a hkeypath to Erlang terms
   in 'arr'. 'format_h' is for use with %h/%*h in CDB/MAAPI paths:
   elements in 'arr' should be in "forward order" and string type
   keys must be converted to string form (to get the right quoting) */
static int hkeypath_to_eterm_arr_ei(ei_x_buff *exbuf,
                                    confd_hkeypath_t *hkp,
                                    int len, int format_h)
{
    confd_value_t *vptr;
    u_int32_t ns = 0, newns;

    /* traverse the keypath backwards */
    for(int i=hkp->len-1; i>=hkp->len-len; i--) {
        vptr = &hkp->v[i][0];
        if (vptr->type == C_XMLTAG) {
            newns = CONFD_GET_XMLTAG_NS(vptr);
            if (newns != 0 && newns != ns) {
                ns = newns;
                BADTERM_IF(ei_x_encode_list_header(exbuf, 1) != 0);
                BADTERM_IF(ei_x_encode_ulong(exbuf, ns) != 0);
                BADTERM_IF(
                    ei_x_encode_ulong(exbuf,
                                      CONFD_GET_XMLTAG(vptr)) != 0);
            } else {
                BADTERM_IF(
                    ei_x_encode_ulong(exbuf,
                                      CONFD_GET_XMLTAG(vptr)) != 0);
            }
        }
        else { /* its a key */
            int klen = 0;
            while (hkp->v[i][klen].type != C_NOEXISTS) {
                klen++;
            }
            BADTERM_IF(ei_x_encode_tuple_header(exbuf, klen) != 0);
            klen = 0;
            while (hkp->v[i][klen].type != C_NOEXISTS) {
                confd_value_t *vp = &hkp->v[i][klen];
                if (format_h && (vp->type == C_BUF || vp->type == C_STR)) {
                    char buf[256], *bp = buf;
                    int sz = pp_keyval(bp, sizeof(buf), vp, ns);
                    if (sz >= sizeof(buf)) {
                        if ((bp = confd_malloc(sz+1)) == NULL)
                            return CONFD_ERR;
                        pp_keyval(bp, sz+1, vp, ns);
                    }
                    BADTERM_IF(ei_x_encode_binary(exbuf, bp, sz) != 0);
                    if (bp != buf)
                        free(bp);
                } else {
                    BADTERM_IF(val_to_term_ei(exbuf, vp) != 0);
                }
                klen++;
            }
        }
    }
    return CONFD_OK;
}

int hkeypath_to_eterm_ei(ei_x_buff *exbuf, confd_hkeypath_t *hkp)
{
    BADTERM_IF(ei_x_encode_list_header(exbuf, hkp->len) != 0);
    return hkeypath_to_eterm_arr_ei(exbuf, hkp, hkp->len, 0);
}

/* Internal dup */
int confd_dup_value(confd_value_t *v)
{
    int i, sz=0;
    unsigned char *ptmp;
    switch (v->type) {
    case C_BUF:
    case C_BINARY:
    case C_HEXSTR:
    case C_BITBIG: {
        ptmp = confd_memdup(v->val.buf.ptr, sz = v->val.buf.size + 1);
        if (ptmp == NULL) goto noalloc;
        v->val.buf.ptr = ptmp;
        break;
    }
    case C_QNAME: {
        unsigned char *ntmp = NULL;
        ptmp = NULL;
        if (v->val.qname.prefix.size > 0) {
            ptmp = confd_memdup(v->val.qname.prefix.ptr,
                                sz = v->val.qname.prefix.size+1);
            if (ptmp == NULL) goto noalloc;
        }
        ntmp = confd_memdup(v->val.qname.name.ptr, sz=v->val.qname.name.size+1);
        if (ntmp == NULL) {
            if (ptmp) free(ptmp);
            goto noalloc;
        }
        v->val.qname.prefix.ptr = ptmp;
        v->val.qname.name.ptr = ntmp;
        break;
    }
    case C_LIST: {
        for (i=0; i<v->val.list.size; i++) {
            confd_value_t *vp = &v->val.list.ptr[i];
            if (confd_dup_value(vp) == CONFD_ERR)
                return CONFD_ERR;
        }
        break;
    }
    case C_OBJECTREF: {
        confd_hkeypath_t *hkp = v->val.hkp;  /* already allocated !!*/
        for (i=0; i<hkp->len; i++) {
            int j = 0;
            confd_value_t *vp = &hkp->v[i][j];
            while (vp->type != C_NOEXISTS) {
                if (confd_dup_value(vp) == CONFD_ERR)
                    return CONFD_ERR;
                j++;
                vp = &hkp->v[i][j];
            }
        }
        break;
    }
    default:
        break;
    }
    return CONFD_OK;

noalloc:
    confd_report_err(CONFD_DEBUG,
                     "failed to malloc() %d bytes", sz);
    return CONFD_ERR;
}



void arg_request(int sock, unsigned int op, int thandle, int *status,
                 int isrel, confd_value_t *v, const ETERM *arg)
{

    ETERM *result;
    result = op_request_term(sock, op, thandle, isrel, arg, status);
    if (arg != NULL) {
        erl_free_compound((ETERM*)arg);
    }
    if (result == NULL) {
        return;
    }
    if (eterm_to_val(result, v) == NULL) {
        erl_free_compound(result);
        *status = CONFD_ERR;
        return;
    }
    if (confd_dup_value(v) == CONFD_ERR) {
        erl_free_compound(result);
        *status = CONFD_ERR;
        return;
    }
    erl_free_compound(result);
    return;
}



void request_v(int sock, unsigned int op, int thandle,
               int *status, confd_value_t *v, const char *fmt, va_list args)
{
    int isrel;
    ETERM *epath;
    clr_confd_err();
    epath = parse_path(&isrel, fmt, args);
    if (epath == NULL) {
        *status = CONFD_ERR;
        ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmt);
        return;
    }
    arg_request(sock, op, thandle, status, isrel, v, epath);
}



int fmt_request(int sock, unsigned int op, int thandle,
                const char *fmt, va_list args)
{
    int status;
    confd_value_t v;
    request_v(sock, op, thandle, &status, &v, fmt, args);
    return status;
}

int request_int(int sock, unsigned int op, int thandle,
                const char *fmt, va_list args)
{
    int status;
    confd_value_t v;

    request_v(sock, op, thandle, &status, &v, fmt, args);
    if (status == CONFD_OK)
        return CONFD_GET_INT32(&v);
    return status;
}

/* copy a binary|atom to a char* and NUL terminate */
/* n is the maxsize of buf */
int bin_copy(char *buf, int n, const ETERM *b)
{
    int sz;
    void *ptr;

    assert(n > 0);

    if (ERL_IS_BINARY(b)) {
        sz =  ERL_BIN_SIZE(b);
        ptr = ERL_BIN_PTR(b);
    } else if (ERL_IS_ATOM(b)) {
        sz = ERL_ATOM_SIZE(b);
        ptr = ERL_ATOM_PTR(b);
    } else {
        sz = 0;
        ptr = NULL;
    }

    int write_sz = sz >= n ? n - 1 : sz;
    memcpy(buf, ptr, write_sz);
    buf[write_sz] = 0;

    return write_sz;
}


/* compare a binary|atom to a NUL-terminated char* */
/* return 1 if equal, 0 if not */
int bin_eq(const ETERM *b, char *s2)
{
    int i, sz;
    char *s1;

    if (ERL_IS_BINARY(b)) {
        sz = ERL_BIN_SIZE(b);
        s1 = (char *)ERL_BIN_PTR(b);
    } else if (ERL_IS_ATOM(b)) {
        sz = ERL_ATOM_SIZE(b);
        s1 = (char *)ERL_ATOM_PTR(b);
    } else {
        return 0;
    }

    for (i = 0; i < sz; i++) {
        if (*s1++ != *s2++)
            return 0;
    }
    if (*s2 == '\0')
        return 1;
    return 0;
}

/* copy a binary|atom to an allocated NUL-terminated string */
char *bin_dup(const ETERM *b)
{
    int sz = 0;
    void *ptr;
    char *buf;

    if (ERL_IS_BINARY(b)) {
        sz =  ERL_BIN_SIZE(b);
        ptr = ERL_BIN_PTR(b);
    }
    else if (ERL_IS_ATOM(b)) {
        sz = ERL_ATOM_SIZE(b);
        ptr = ERL_ATOM_PTR(b);
    } else {
        return NULL;
    }

    if ((buf = confd_malloc(sz + 1)) == NULL)
        return NULL;
    memcpy(buf, ptr, sz);
    buf[sz] = 0;
    return buf;
}

int _confd_iterate_send_reply(int sock, enum confd_iter_ret uret)
{
    int ret;
    unsigned char buf[8];

    put_int32(4, buf);
    switch (uret) {
    case ITER_STOP:
    case ITER_RECURSE:
    case ITER_CONTINUE:
    case ITER_UP:
        put_int32(uret, buf+4);

        BADTERM_IF(CAPI_VALIDATE_RAWBUF(capi_dir_send, capi_packet_opaque,
                                        buf+4, 4,
                                        -1, -1) != CONFD_OK);

        if ((ret = confd_write(sock, buf, 8)) != CONFD_OK)
            return ret;
        break;
    default:
        put_int32(ITER_STOP, buf+4);

        BADTERM_IF(CAPI_VALIDATE_RAWBUF(capi_dir_send, capi_packet_opaque,
                                        buf+4, 4,
                                        -1, -1) != CONFD_OK);

        if ((ret = confd_write(sock, buf, 8)) != CONFD_OK)
            return ret;
        confd_report_err(CONFD_DEBUG, "Bad return value: %d\n", uret);
        confd_set_errno(CONFD_ERR_PROTOUSAGE);
        return CONFD_ERR;
    }
    return CONFD_OK;
}

/* before calling you must have issued the op to ConfD */
int _confd_iterate(int sock, void *iter_function, void *initstate)
{
    while (1) {
        ETERM *e; int ret;
        ETERM *ekp;
        confd_hkeypath_t kp;
        int uret;

        if ((e = term_read(sock, &ret, -1)) == NULL)
            return ret;
        ekp = TE(e, 0);
        if (ERL_IS_ATOM(ekp)  &&
            (strncmp("return", (char *)ERL_ATOM_PTR(ekp), 6) == 0)) {
            erl_free_compound(e);
            return CONFD_OK;
        }
        if (ERL_IS_ATOM(ekp)  &&
            (strncmp("error", (char *)ERL_ATOM_PTR(ekp), 5) == 0)) {
            if (ERL_TUPLE_SIZE(e) == 2)
                confd_set_lasterr("%s", ERL_BIN_PTR(TE(e, 1)));
            erl_free_compound(e);
            confd_set_errno(CONFD_ERR_NOEXISTS);
            return CONFD_ERR;
        }
        if (ERL_IS_ATOM(ekp)  &&
            (strncmp("badstate", (char *)ERL_ATOM_PTR(ekp), 8) == 0)) {
            if (ERL_TUPLE_SIZE(e) == 2)
                confd_set_lasterr("%s", ERL_BIN_PTR(TE(e, 1)));
            erl_free_compound(e);
            confd_set_errno(CONFD_ERR_BADSTATE);
            return CONFD_ERR;
        }

        if (!populate_keypath(ekp, &kp))
            return CONFD_ERR;

        if (ERL_TUPLE_SIZE(e) >= 4) {
            /* diff_iterate */
            ETERM *ovalue, *nvalue;
            int op;
            confd_value_t oldv, *oldvp = NULL;
            confd_value_t newv, *newvp = NULL;
            int vlen = 0;

            op = TINT(e, 1);
            ovalue = TE(e, 2);
            nvalue = TE(e, 3);

            if (!bin_eq(ovalue, "undefined")) {
                if (eterm_to_val(ovalue, &oldv) == NULL)
                    return CONFD_ERR;
                oldvp = &oldv;
            }

            if (!bin_eq(nvalue, "undefined")) {
                if (op == MOP_MOVED_AFTER || op == MOP_ATTR_SET) {
                    /* nvalue is a tuple, handled below to avoid malloc */
                    vlen = ERL_TUPLE_SIZE(nvalue);
                } else {
                    /* nvalue is a single value */
                    if (eterm_to_val(nvalue, &newv) == NULL)
                        return CONFD_ERR;
                    newvp = &newv;
                }
            }

            {
                confd_value_t vals[vlen+1];
                int i;

                if (vlen > 0) {
                    if (op == MOP_MOVED_AFTER) {
                        /* key tuple */
                        for (i = 0; i < vlen; i++) {
                            if (eterm_to_val(TE(nvalue, i), &vals[i]) == NULL)
                                return CONFD_ERR;
                        }
                        CONFD_SET_NOEXISTS(&vals[vlen]);
                    } else {
                        /* MOP_ATTR_SET - {attr, value} */
                        CONFD_SET_UINT32(&vals[0], TUINT(nvalue, 0));
                        if (eterm_to_val(TE(nvalue, 1), &vals[1]) == NULL)
                            return CONFD_ERR;
                    }
                    newvp = &vals[0];
                }
                {
                    confd_diff_iter_function_t *iter = iter_function;
                    uret = iter(&kp, (enum confd_iter_op) op,
                                oldvp, newvp, initstate);
                }
                if (oldvp != NULL)
                    confd_free_eterm_val(oldvp);
                if (newvp != NULL) {
                    if (vlen > 0) {
                        if (op == MOP_MOVED_AFTER) {
                            for (i = 0; i < vlen; i++)
                                confd_free_eterm_val(&vals[i]);
                        } else {
                            confd_free_eterm_val(&vals[1]);
                        }
                    } else {
                        confd_free_eterm_val(newvp);
                    }
                }
            }

        } else {
            /* iterate */
            ETERM *value, *attrl;
            confd_value_t v, *vp = NULL;
            confd_attr_value_t *avp = NULL;
            int num_attr_vals = 0;
            confd_iter_function_t *iter = iter_function;

            value = TE(e, 1);
            attrl = TE(e, 2);

            if (!bin_eq(value, "undefined")) {
                if (eterm_to_val(value, &v) == NULL)
                    return CONFD_ERR;
                vp = &v;
            }

            if (!bin_eq(attrl, "undefined")) {
                /* attrl is a list of tuples, handled below to avoid malloc */
                num_attr_vals = erl_length(attrl);
            }

            {
                confd_attr_value_t attr_vals[num_attr_vals+1];
                int i;

                if (num_attr_vals > 0) {
                    for (i = 0; i < num_attr_vals; i++) {
                        ETERM *attr = ERL_CONS_HEAD(attrl);
                        attr_vals[i].attr = ERL_INT_UVALUE(TE(attr, 0));
                        if (eterm_to_val(TE(attr, 1), &attr_vals[i].v) == NULL)
                            return CONFD_ERR;
                        attrl = ERL_CONS_TAIL(attrl);
                    }
                    avp = &attr_vals[0];
                }
                uret = iter(&kp, vp, avp, num_attr_vals, initstate);
                if (vp != NULL)
                    confd_free_eterm_val(vp);
                for (i = 0; i < num_attr_vals; i++)
                    confd_free_eterm_val(&attr_vals[i].v);
            }

        }

        confd_free_eterm_keypath(&kp);
        erl_free_compound(e);
        if (uret == ITER_SUSPEND) {
            return CONFD_OK;
        }
        if ((ret = _confd_iterate_send_reply(sock, uret)) != CONFD_OK) {
            return ret;
        }
        if (uret == ITER_STOP)
            return CONFD_OK;
    }
    /* never reach */
    return CONFD_OK;
}

int _confd_iterate_resume(int sock, enum confd_iter_ret reply,
                          void *iter_function, void *resumestate,
                          char *trace)
{
    int ret;

    if (reply == ITER_SUSPEND) {
        return CONFD_OK;
    }

    ret = _confd_iterate_send_reply(sock, reply);

    if (confd_debug_level >= CONFD_TRACE) {
        confd_trace_printf("TRACE %s\n", trace);
    }

    if ((ret == CONFD_OK) && (reply != ITER_STOP)) {
        return _confd_iterate(sock, iter_function, resumestate);
    } else {
        return ret;
    }
}


/* from INA - move to confd_lib.c and export? */
int confd_val_num_cmp(const confd_value_t *v1, const confd_value_t *v2)
{
    switch (v1->type) {
#define CMP(E) (v1->val.E < v2->val.E) ? -1 : !(v1->val.E == v2->val.E)
    case C_INT8:
        return CMP(i8);
    case C_INT16:
        return CMP(i16);
    case C_INT32:
        return CMP(i32);
    case C_INT64:
        return CMP(i64);
    case C_UINT8:
        return CMP(u8);
    case C_UINT16:
        return CMP(u16);
    case C_UINT32:
        return CMP(u32);
    case C_UINT64:
        return CMP(u64);
    case C_DOUBLE:
        return CMP(d);
    case C_DECIMAL64:
        return CMP(d64.value);
    default:
        return 0;
#undef CMP
    }
}
