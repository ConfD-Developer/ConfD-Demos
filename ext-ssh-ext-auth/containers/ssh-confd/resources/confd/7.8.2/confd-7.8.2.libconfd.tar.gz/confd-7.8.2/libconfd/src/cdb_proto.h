/* Automatically generated from ../../../cdb/include/cdb_api.hrl */
/* DO NOT EDIT */

#define CDB_OP_MASK  0x7fffffff
#define CDB_OP_CLIENT_NAME    0
#define CDB_OP_NEW_SESSION    1
#define CDB_OP_END_SESSION    2
#define CDB_OP_SET_NAMESPACE  3
#define CDB_OP_GET            4
#define CDB_OP_CD             5
#define CDB_OP_PUSHD          6
#define CDB_OP_POPD           7
#define CDB_OP_EXISTS         8
#define CDB_OP_NUM_INSTANCES  9
#define CDB_OP_GETCWD        10
#define CDB_OP_GET2          11
#define CDB_OP_GET_OBJECT    12
#define CDB_OP_GET_OBJECTS   13
#define CDB_OP_GET_VALUES    14
#define CDB_OP_KEY_INDEX     15
#define CDB_OP_NXT_INDEX     16
#define CDB_OP_GET_CASE      17
#define CDB_OP_IS_DEFAULT    18
#define CDB_OP_CLIENT_INFO    19
#define CDB_OP_SUBSCRIBE       32
#define CDB_OP_SUB_EVENT       33
#define CDB_OP_SYNC_SUB        34
#define CDB_OP_UNSUBSCRIBE     35
#define CDB_OP_SUB_ITERATE     36
#define CDB_OP_SUBSCRIBE_DONE  37
#define CDB_OP_OPER_SUBSCRIBE  38
#define CDB_OP_SUB_PROGRESS    39
#define CDB_OP_GET_MODIFICATIONS  40
#define CDB_OP_GET_CLI         41
#define CDB_OP_SET_ELEM       48
#define CDB_OP_SET_ELEM2      49
#define CDB_OP_CREATE         50
#define CDB_OP_DELETE         51
#define CDB_OP_SET_OBJECT     52
#define CDB_OP_SET_VALUES     53
#define CDB_OP_SET_CASE       54
#define CDB_OP_WAIT_START     64
#define CDB_OP_GET_PHASE      65
#define CDB_OP_GET_TXID       66
#define CDB_OP_GET_USER_SESSION  67
#define CDB_OP_TRIGGER_SUBS   68
#define CDB_OP_GET_TRANS_TID  70
#define CDB_OP_REPLAY_SUBS    71
#define CDB_OP_GET_REPLAY_TXID  72
#define CDB_OP_SET_TIMEOUT    73
#define CDB_OP_MANDATORY_SUBSCRIBER    74
#define CDB_OP_TRIGGER_OPER_SUBS  75
#define CDB_OP_INITIATE_COMPACTION  76
#define CDB_OP_GET_MOUNT_ID   78
#define CDB_OP_GET_ATTRS  79
#define CDB_OP_SET_ATTR  80
#define CDB_REL_FLAG_MASK   0x80000000
#define CDB_ERROR_FLAG_MASK  CDB_REL_FLAG_MASK
#define CDB_OP(I)  ((I) & CDB_OP_MASK)
#define CDB_IS_REL(I)  (((I) & CDB_REL_FLAG_MASK) == CDB_REL_FLAG_MASK)
#define CDB_IS_WOP(O)  ((OP(O) >= CDB_OP_SET_ELEM) and (OP(O) =< CDB_OP_SET_VALUES))
#define CDB_REPLY_IS_ERROR(I)  (((I) & CDB_ERROR_FLAG_MASK) == CDB_ERROR_FLAG_MASK)
