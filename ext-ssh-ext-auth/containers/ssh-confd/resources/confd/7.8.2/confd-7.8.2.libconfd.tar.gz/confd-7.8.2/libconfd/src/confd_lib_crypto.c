/*
 * Copyright 2005-2007 Tail-F Systems AB
 */

#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

/* These are needed for confd_internal.h */
#include "erl_interface.h"
#include "ei.h"

#include "confd_lib.h"
#include "confd_internal.h"

#ifdef DISABLE_CRYPTO

int confd_decrypt(const char *ciphertext, int len, char *output)
{
    return ret_err(CONFD_ERR_UNAVAILABLE,
                   "Crypto support is not present in this build");
}

#else

#include <openssl/evp.h>


static int d64[] = {
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,62,-1,-1,-1,63,
    52,53,54,55,56,57,58,59,60,61,-1,-1,-1,255,-1,-1,
    -1,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,
    15,16,17,18,19,20,21,22,23,24,25,-1,-1,-1,-1,-1,
    -1,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,
    41,42,43,44,45,46,47,48,49,50,51,-1,-1,-1,-1,-1,
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1
};


static int base64_decode(const char *src, int slen, char *dst, int dlen)
{
    const char *sp = src;
    char *dp = dst;
    int n = 0;
    int d;
    unsigned int acc = 0;

    while (sp < src + slen) {
        d = d64[(unsigned char)*sp++];
        if (d < 0)
            continue;           /* non-b64 - ignore */
        if (d == 255) {         /* pad => end of input */
            if (n == 2 || n == 3) /* 2 or 3 bytes seen before pad */
                return dp - dst;
            else
                return -1;      /* malformed */
        }
        if (dp >= dst + dlen)
            return -1;          /* overflow */
        acc = (acc << 6) | d;
        switch (n) {
        case 1:                 /* 1 byte + 4 bits */
            *dp++ = acc >> 4;
            break;
        case 2:                 /* 2 bytes + 2 bits */
            *dp++ = acc >> 2;
            break;
        case 3:                 /* 3 bytes */
            *dp++ = acc;
            break;
        }
        n++; n %= 4;
    }
    if (n == 0)
        return dp - dst;        /* multiple of 3 bytes */
    return -1;                  /* truncated input */
}


/* len is the length of input; output MUST be of same length (or longer)
 * If encrypt is 1, input is encrypted into output.
 * If encrypt is 0, input is decrypted into output.
 */
static void des_encrypt(char key1[8], char key2[8], char key3[8], char ivec[8],
                 char *input, char *output, int len,
                 int encrypt)
{
    EVP_CIPHER_CTX *ctx;
    int outlen;
    unsigned char des_key[24], des_ivec[8];

    memcpy(&des_key[0], key1, 8);
    memcpy(&des_key[8], key2, 8);
    memcpy(&des_key[16], key3, 8);
    memcpy(&des_ivec, ivec, 8);

    ctx = EVP_CIPHER_CTX_new();
    EVP_CipherInit_ex(ctx, EVP_des_ede3_cbc(), NULL, des_key, des_ivec,
                      encrypt);
    EVP_CipherUpdate(ctx, (unsigned char *)output, &outlen,
                     (unsigned char*)input, len);
    EVP_CipherFinal_ex(ctx, (unsigned char *)output, &outlen);
    EVP_CIPHER_CTX_free(ctx);
}



static void aes_encrypt(char key[16], char ivec[16],
                 char *input, char *output, int len,
                 int encrypt)
{
    EVP_CIPHER_CTX *ctx;
    int outlen;

    unsigned char foo[16];
    unsigned char bar[16];

    memcpy(foo, key, 16);  /* Don't understand this */
    memcpy(bar, ivec, 16);

    ctx = EVP_CIPHER_CTX_new();
    EVP_CipherInit_ex(ctx, EVP_aes_128_cfb128(), NULL, foo, bar, encrypt);
    EVP_CipherUpdate(ctx, (unsigned char *)output, &outlen,
                           (unsigned char *)input, len);
    EVP_CipherFinal_ex(ctx, (unsigned char *)output, &outlen);
    EVP_CIPHER_CTX_free(ctx);
}

static void aes256_encrypt(char key[32], char ivec[16],
                           char *input, char *output, int len,
                           int encrypt)
{
    EVP_CIPHER_CTX *ctx;
    int outlen;

    unsigned char foo[32];
    unsigned char bar[16];

    memcpy(foo, key, 32);  /* Don't understand this */
    memcpy(bar, ivec, 16);

    ctx = EVP_CIPHER_CTX_new();
    EVP_CipherInit_ex(ctx, EVP_aes_256_cfb128(), NULL, foo, bar, encrypt);
    EVP_CipherUpdate(ctx, (unsigned char *)output, &outlen,
                           (unsigned char *)input, len);
    EVP_CipherFinal_ex(ctx, (unsigned char *)output, &outlen);
    EVP_CIPHER_CTX_free(ctx);
}


/* len includes the extra $3$, $4$ etc chars at the beginning */
/* reserve 1 extra char in output for NUL termination */

int confd_decrypt(const char *ciphertext, int len, char *output)
{
    const char *cptr = ciphertext+3;
    char *base;
    int rlen;

    if (ciphertext[0] != '$' || ciphertext[2] != '$') {
        return ret_err(CONFD_ERR_PROTOUSAGE, "Bad ciphertext format");
    }
    if ((base = confd_malloc(len)) == NULL) {
        return CONFD_ERR;
    }

    if ((rlen = base64_decode(cptr, len-3, base, len)) < 0) {
        free(base);
        return ret_err(CONFD_ERR_PROTOUSAGE, "Invalid base64 encoding");
    }
    if (ciphertext[1] == '7') {
        if (!confd_crypto_keys.des3_keys_initialized) {
            free(base);
            return ret_err(CONFD_ERR_NOEXISTS, "No DES3 keys installed");
        }
        /* ivec is first 8 bytes of value */
        rlen -= 8;
        des_encrypt(confd_crypto_keys.des3_key1,
                    confd_crypto_keys.des3_key2,
                    confd_crypto_keys.des3_key3,
                    base,
                    &base[8], output, rlen, 0);
        output[rlen] = 0;
        free(base);
    }
    else if (ciphertext[1] == '8') {
        if (!confd_crypto_keys.aes_keys_initialized) {
            free(base);
            return ret_err(CONFD_ERR_NOEXISTS, "No AES key installed");
        }
        /* ivec is first 16 bytes of value */
        rlen -= 16;
        aes_encrypt(confd_crypto_keys.aes_key,
                    base,
                    &base[16], output, rlen, 0);
        output[rlen] = 0;
        free(base);
    }
    else if (ciphertext[1] == '9') {
        if (!confd_crypto_keys.aes256_keys_initialized) {
            free(base);
            return ret_err(CONFD_ERR_NOEXISTS, "No AES256 key installed");
        }
        /* ivec is first 16 bytes of value */
        rlen -= 16;
        aes256_encrypt(confd_crypto_keys.aes256_key,
                       base,
                       &base[16], output, rlen, 0);
        output[rlen] = 0;
        free(base);
    }
    else if (ciphertext[1] == '3') {
        /* old-style with fixed ivec, "shouldn't happen" */
        if (!confd_crypto_keys.des3_keys_initialized) {
            free(base);
            return ret_err(CONFD_ERR_NOEXISTS, "No DES3 keys installed");
        }
        des_encrypt(confd_crypto_keys.des3_key1,
                    confd_crypto_keys.des3_key2,
                    confd_crypto_keys.des3_key3,
                    confd_crypto_keys.des3_ivec,
                    base, output, rlen, 0);
        output[rlen] = 0;
        free(base);
    }
    else if (ciphertext[1] == '4') {
        /* old-style with fixed ivec, "shouldn't happen" */
        if (!confd_crypto_keys.aes_keys_initialized) {
            free(base);
            return ret_err(CONFD_ERR_NOEXISTS, "No AES key installed");
        }
        aes_encrypt(confd_crypto_keys.aes_key,
                    confd_crypto_keys.aes_ivec,
                    base, output, rlen, 0);
        output[rlen] = 0;
        free(base);
    }
    else {
        free(base);
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Unknown cipher type %c", ciphertext[1]);
    }
    return CONFD_OK;
}

#endif  /* DISABLE_CRYPTO */
