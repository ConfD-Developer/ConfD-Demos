#!/usr/bin/env python

'''This configures devices for nso.

./add_device.py -u username -p password -n name -a address 

    -u : username for test device
    -p : password for test device
    -n : name of test device
    -a : network address of test device
    -s : network port of test device

Example:

        ./add_device.py -u admin -p DMidmi1! -n cat9k-22 -a 172.27.255.22

'''

from __future__ import print_function
from __future__ import absolute_import
import os, sys, time, getopt
import signal, fcntl, termios, struct
import pexpect
import pdb

def exit_with_usage():

    print(globals()['__doc__'])
    os._exit(1)

def main():

    ######################################################################
    # Parse the options, arguments, get ready, etc.
    ######################################################################
    try:
        optlist, args = getopt.getopt(sys.argv[1:], 'h?u:p:n:a:s:', ['help','h','?'])
    except Exception as e:
        print(str(e))
        exit_with_usage()
    options = dict(optlist)
    if len(optlist) < 4:
        exit_with_usage()

    if [elem for elem in options if elem in ['-h','--h','-?','--?','--help']]:
        print("Help:")
        exit_with_usage()

    if '-u' in options:
        username = options['-u']
    else:
        exit_with_usage()

    if '-p' in options:
        password = options['-p']
    else:
        exit_with_usage()

    if '-n' in options:
        devname = options['-n']
    else:
        exit_with_usage()

    if '-a' in options:
        address = options['-a']
    else:
        exit_with_usage()

    if '-s' in options:
        port = options['-s']
    else:
        port = "830"

    # pdb.set_trace()
    ######################################################################
    # Start the nso interactive session
    ######################################################################
    p = pexpect.spawn('ncs_cli -C -u admin')
    p.expect_exact('admin@ncs#')
    p.sendline('config')
    p.expect_exact("admin@ncs(config)#")
    authstr = "devices authgroups group nyat default-map remote-name %s remote-password \"%s\"" % (username, password)
    p.sendline(authstr)
    p.expect_exact('admin@ncs(config-group-nyat)#')
    p.sendline('commit')
    p.expect_exact('admin@ncs(config-group-nyat)#')
    p.sendline('exit')
    p.expect_exact('admin@ncs(config)#')
    devstr = "devices device \"%s\" device-type netconf ned-id netconf" % (devname)
    p.sendline(devstr)
    p.expect_exact('admin@ncs(config-device-')
    addstr = "address %s port %s authgroup nyat" % (address, port)
    p.sendline(addstr)
    p.expect_exact('admin@ncs(config-device-')
    p.sendline('state admin-state unlocked')
    p.expect_exact('admin@ncs(config-device-')
    p.sendline('trace raw')
    p.expect_exact('admin@ncs(config-device-')
    p.sendline('commit')
    p.expect_exact('admin@ncs(config-device-')
    p.sendline('ssh fetch-host-keys')
    p.expect_exact('admin@ncs(config-device-')
    p.sendline('exit')
    p.expect_exact('admin@ncs(config)#')
    p.sendline('drned-xmnr xmnr-directory /home/ncs-run/ncs-logs')
    p.expect_exact('admin@ncs(config)#')
    p.sendline('drned-xmnr log-detail cli all')
    p.expect_exact('admin@ncs(config)#')
    p.sendline('python-vm logging level level-debug')
    p.expect_exact('admin@ncs(config)#')
    p.sendline('commit')
    p.expect_exact('admin@ncs(config)#')
    p.sendline('devices device {}'.format(devname))
    p.expect_exact('admin@ncs(config-device-')
    p.sendline('drned-xmnr setup setup-xmnr overwrite true')
    p.expect_exact('admin@ncs(config-device-')
    p.sendline('end')
    p.expect_exact('admin@ncs#')
    p.sendline("exit")
    print("Device %s added" % (devname))
    return 0

if __name__ == "__main__":
    main()
